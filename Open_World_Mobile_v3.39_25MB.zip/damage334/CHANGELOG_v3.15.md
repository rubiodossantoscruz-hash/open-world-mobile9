# Open World Mobile v3.15 — Vice City inspired

- Visual direction inspired by tropical 1980s coastal cities: ocean, irregular coast contour, sand, palm trees and pastel beachfront facades.
- Main character appearance changed to a CJ-inspired green shirt, blue jeans and darker skin tone.
- Vehicle damage stages now alter body scale/pose; damage 100 disables the vehicle and triggers an explosion effect.
- Smoke appears more often at high damage. Repair restores the vehicle state through the existing repair interaction.

This is a prototype using procedural Three.js geometry. It does not include official GTA assets or a complete GTA V feature set. Verify in browser/Android WebView before treating gameplay behavior as fully tested.
