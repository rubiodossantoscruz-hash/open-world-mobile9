'use strict';
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const PORT = Number(process.env.PORT || 8080);
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ game: 'Open World Mobile', multiplayer: true, status: 'online' }));
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocketServer({ server, maxPayload: 2048 });
const clients = new Map();
const rooms = new Map();
let nextId = 1;
function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function roomPlayers(room) { return [...(rooms.get(room) || [])].map(ws => clients.get(ws)).filter(Boolean); }
function broadcastRoom(room) {
  const players = roomPlayers(room).map(p => ({ id: p.id, name: p.name, x: p.x, y: p.y, z: p.z, r: p.r, vehicle: p.vehicle }));
  for (const ws of rooms.get(room) || []) send(ws, { type: 'state', players });
}
wss.on('connection', ws => {
  const client = { id: String(nextId++), name: 'Jogador', room: 'alta-vista', x: 0, y: 0, z: 8, r: 0, vehicle: false, lastMove: 0 };
  clients.set(ws, client);
  ws.on('message', raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return send(ws, { type: 'error', message: 'Mensagem inválida.' }); }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      const room = String(msg.room || 'alta-vista').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 'alta-vista';
      if (client.room && rooms.has(client.room)) { rooms.get(client.room).delete(ws); broadcastRoom(client.room); }
      client.room = room;
      client.name = String(msg.name || 'Jogador').replace(/[<>\r\n]/g, '').trim().slice(0, 18) || 'Jogador';
      if (!rooms.has(room)) rooms.set(room, new Set());
      rooms.get(room).add(ws);
      send(ws, { type: 'welcome', id: client.id, room });
      broadcastRoom(room);
      return;
    }
    if (msg.type === 'move') {
      const now = Date.now(); if (now - client.lastMove < 45) return; client.lastMove = now;
      const num = (v, fallback) => Number.isFinite(Number(v)) ? Math.max(-800, Math.min(800, Number(v))) : fallback;
      client.x = num(msg.x, client.x); client.y = Math.max(0, Math.min(100, num(msg.y, client.y))); client.z = num(msg.z, client.z); client.r = num(msg.r, client.r); client.vehicle = !!msg.vehicle;
    }
  });
  ws.on('close', () => { const c = clients.get(ws); clients.delete(ws); if (c && rooms.has(c.room)) { rooms.get(c.room).delete(ws); if (!rooms.get(c.room).size) rooms.delete(c.room); else broadcastRoom(c.room); } });
  ws.on('error', () => {});
});
const interval = setInterval(() => { for (const room of rooms.keys()) broadcastRoom(room); }, 100);
server.listen(PORT, '0.0.0.0', () => console.log(`Open World Mobile multiplayer listening on ${PORT}`));
function shutdown() { clearInterval(interval); server.close(() => process.exit(0)); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
