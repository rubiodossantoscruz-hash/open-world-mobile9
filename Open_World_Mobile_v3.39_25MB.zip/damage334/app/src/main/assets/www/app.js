const THREE = window.THREE;
const IS_MOBILE_DEVICE = window.innerWidth < 900 || /Android|iPhone|iPad/i.test(navigator.userAgent);
window.addEventListener('error', function(ev) {
  const box = document.getElementById('startup-error') || document.createElement('div');
  box.id = 'startup-error';
  box.style.cssText = 'position:fixed;z-index:99999;left:8px;right:8px;top:8px;padding:12px;background:#300;color:#fff;font:14px Arial;border:1px solid #f66;border-radius:8px;white-space:pre-wrap';
  box.textContent = 'Erro ao iniciar o jogo: ' + (ev.message || 'falha de JavaScript') + '\\nRecarregue a página e confira se a internet está ativa.';
  document.body.appendChild(box);
});
'use strict';

/* =========================================================
   OPEN WORLD MASTER BUILD
   Unificado e otimizado para celulares modestos
   ========================================================= */

let scene,camera,renderer,directionalLight;
let player,vehicle;
let inVehicle=false;
let speed=0,steering=0,fuel=100,carDamage=0,vehicleDestroyed=false,damageStage=0;
let vehicleSpeedLimit=22;
const VEHICLE_SPEED_PRESETS={low:14,medium:22,high:32,extreme:42};
// Global so both engine initialization and graphics-menu callbacks can access it.
const RENDER_DISTANCE_PRESETS={low:300,medium:450,high:650};
let activeRenderDistance=RENDER_DISTANCE_PRESETS.medium;
let carVelocity=new THREE.Vector3(),carBody=null,wheelMeshes=[];
let buildingColliders=[],cityLocations=[];
let asphaltTexture,sidewalkTexture,facadeTexture,facadeTextures=[],grassTexture,parkGrassTexture;
let activeFacadeIndex=0;
const CITY_LIMIT=785;
const CITY_EDGE=750;
let lastLocationUpdate=0,lastNearbyLocation=-1;
let cameraAngleY=0, cameraPitch=0.28;
let isAiming=false;
let money=0,playerHealth=100,ammoCount=50;
let playerVerticalVelocity=0,playerIsJumping=false,reloadTimer=0,policeAttackCooldown=0,saveCooldown=0;
let gameTime=12,timeSpeed=.002;
let isGamePaused=false,gameStarted=false,gameOver=false;
let keys={forward:false,backward:false,left:false,right:false};
let pedestrians=[],npcVehicles=[],parkedVehicles=[],policeCars=[],bullets=[],smokeParticles=[];
let hiddenPackages=[],collectedPackagesCount=0;
let streetLights=[],neonSigns=[],ambientAircrafts=[],streetLampMaterial=null;
let ambientDustParticles=null,rainParticles=null,minimapCtx=null;
let currentMission=null,missionMarker=null,gpsTarget=null;
let storyMissionIndex=0,storyIntroShown=false,storyDialogIndex=0;
let wantedLevel=0,currentWeaponIndex=0,currentWeapon="Pistola 9mm",wantedSearchTimer=0;
let weaponAmmo=[50,120,90,30];
let isRaining=false,cameraMode=0;
let isRacing=false,raceTimer=0,currentCheckpoint=0;
let unlockedAchievements=[],storedGarageVehicles=[];
let audioCtx=null,engineOscillator=null,engineGain=null;
let radioPlaying=false,currentStation=0,radioInterval=null;
let lastFrame=performance.now(),lastHudUpdate=0,lastAIUpdate=0;
const clock=new THREE.Clock();

const weaponsList=[
 {name:"Pistola 9mm",damage:25,range:55,fireDelay:.25,projectiles:1,spread:.012,velocity:2.7,color:0xffdf55},
 {name:"Submetralhadora SMG",damage:12,range:42,fireDelay:.085,projectiles:1,spread:.055,velocity:2.5,color:0xffa83a},
 {name:"Fuzil de Assalto M4",damage:38,range:90,fireDelay:.15,projectiles:1,spread:.018,velocity:3.2,color:0xfff18a},
 {name:"Escopeta 12",damage:14,range:24,fireDelay:.58,projectiles:7,spread:.22,velocity:2.25,color:0xff7250}
];

const raceCheckpoints=[
 {x:50,z:50},{x:120,z:-80},{x:-60,z:-150},{x:-140,z:80}
];

function $(id){return document.getElementById(id)}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function playerPos(){return inVehicle&&vehicle?vehicle.position:player.position}
function updateNearbyLocation(){
 const pos=playerPos();let nearest=-1,best=105*105;
 for(let i=0;i<cityLocations.length;i++){const place=cityLocations[i],dx=pos.x-place.x,dz=pos.z-place.z,d=dx*dx+dz*dz;if(d<best){best=d;nearest=i}}
 if(nearest!==lastNearbyLocation){lastNearbyLocation=nearest;const label=$("location-name");if(label)label.innerText=nearest>=0?cityLocations[nearest].name:"Explorando Alta Vista"}
}
function makeSurfaceBump(seed){
 // Mapa de relevo procedural: adiciona poros, pequenas fissuras e variação
 // de rugosidade sem baixar arquivos extras nem depender de rede.
 const canvas=document.createElement('canvas');canvas.width=128;canvas.height=128;
 const ctx=canvas.getContext('2d',{alpha:false});
 let state=(seed>>>0)||123456789;
 const rand=()=>{state=(state*1664525+1013904223)>>>0;return state/4294967296};
 const image=ctx.createImageData(128,128);
 for(let i=0;i<image.data.length;i+=4){const v=90+Math.floor(rand()*100);image.data[i]=image.data[i+1]=image.data[i+2]=v;image.data[i+3]=255}
 ctx.putImageData(image,0,0);
 // Riscos finos como microfissuras e marcas de uso.
 for(let i=0;i<46;i++){ctx.strokeStyle=`rgba(${rand()<.5?25:245},${rand()<.5?25:245},${rand()<.5?25:245},${.08+rand()*.18})`;ctx.lineWidth=.4+rand()*1.2;ctx.beginPath();let x=rand()*128,y=rand()*128;ctx.moveTo(x,y);ctx.lineTo(x+(rand()-.5)*25,y+(rand()-.5)*18);ctx.stroke()}
 const map=new THREE.CanvasTexture(canvas);map.wrapS=map.wrapT=THREE.RepeatWrapping;map.repeat.set(2,2);map.needsUpdate=true;return map;
}
function loadTiledTexture(path,repeatX,repeatY){
 const texture=new THREE.TextureLoader().load(path,undefined,undefined,()=>console.warn('Textura não carregada:',path));
 texture.wrapS=texture.wrapT=THREE.RepeatWrapping;
 texture.repeat.set(repeatX,repeatY);
 texture.encoding=THREE.sRGBEncoding;
 texture.anisotropy=Math.min(4,renderer ? renderer.capabilities.getMaxAnisotropy() : 1);
 texture.userData=texture.userData||{};
 texture.userData.surfaceBump=makeSurfaceBump(path.split('').reduce((a,c)=>a+c.charCodeAt(0),0));
 return texture;
}

/* ---------- SKY CLOUDS V3.32: nuvens leves, sem texturas externas ---------- */
const skyClouds=[];
function createSkyClouds(){
 if(!scene || skyClouds.length) return;
 const puffGeo=new THREE.SphereGeometry(1,8,6);
 const puffMat=new THREE.MeshBasicMaterial({color:0xf7fbff,transparent:true,opacity:.88,depthWrite:false,fog:false});
 // Grupos de nuvens com geometria simples para manter o custo baixo em celulares.
 for(let i=0;i<14;i++){
  const cloud=new THREE.Group();
  const angle=(i/14)*Math.PI*2 + Math.random()*.22;
  const radius=105+Math.random()*125;
  cloud.position.set(Math.cos(angle)*radius,48+Math.random()*34,Math.sin(angle)*radius);
  cloud.userData.drift=.45+Math.random()*.45;
  const puffs=3+(i%3);
  for(let j=0;j<puffs;j++){
   const puff=new THREE.Mesh(puffGeo,puffMat);
   puff.position.set((j-(puffs-1)/2)*(2.7+Math.random()),Math.random()*1.4,(Math.random()-.5)*3.5);
   puff.scale.set(3.5+Math.random()*3.5,1.35+Math.random()*1.1,2.6+Math.random()*2.8);
   puff.rotation.y=Math.random()*Math.PI;
   cloud.add(puff);
  }
  scene.add(cloud);skyClouds.push(cloud);
 }
}
function updateSkyClouds(dt){
 if(!skyClouds.length)return;
 for(const cloud of skyClouds){
  cloud.position.x+=cloud.userData.drift*dt;
  if(cloud.position.x>260)cloud.position.x=-260;
 }
}

/* ---------- CORE ---------- */
function initEngine(){
 asphaltTexture=loadTiledTexture("img/asphalt-texture.png",60,5);
 sidewalkTexture=loadTiledTexture("img/sidewalk-texture.png",90,1.5);
 facadeTextures=[
  loadTiledTexture("img/facade-texture.png",2,3),
  loadTiledTexture("img/facade-brick.png",2,3),
  loadTiledTexture("img/facade-glass.png",2,3),
  loadTiledTexture("img/facade-stone.png",2,3),
  loadTiledTexture("img/facade-stucco.png",2,3)
 ];
 facadeTexture=facadeTextures[0];
 grassTexture=loadTiledTexture("img/park-grass-texture.png",100,100);
 parkGrassTexture=loadTiledTexture("img/park-grass-texture.png",6,6);
 scene=new THREE.Scene();
 scene.background=new THREE.Color(0x66b8dc);
 scene.fog=new THREE.FogExp2(0x9abdc2,.00135);
 createSkyClouds();
// Render distance is configurable from the pause menu; camera.far culls distant geometry.
 camera=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.1,activeRenderDistance);
 camera.position.set(0,4,8);

 renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:"high-performance"});
 renderer.setSize(innerWidth,innerHeight);
 renderer.setPixelRatio(Math.min(devicePixelRatio||1, IS_MOBILE_DEVICE ? .75 : 1.1));
 renderer.shadowMap.enabled=!IS_MOBILE_DEVICE;
 renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 renderer.info.autoReset=true;
 renderer.domElement.style.touchAction='none';
 renderer.outputEncoding=THREE.sRGBEncoding;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;
 renderer.toneMappingExposure=1.12;
 document.body.appendChild(renderer.domElement);

 const ambient=new THREE.HemisphereLight(0xe8f7ff,0x526a48,1.08);
 scene.add(ambient);

 directionalLight=new THREE.DirectionalLight(0xfff0cf,1.65);
 directionalLight.position.set(50,100,50);
 directionalLight.castShadow=true;
 const shadowResolution=IS_MOBILE_DEVICE?768:1024;
 directionalLight.shadow.mapSize.width=shadowResolution;directionalLight.shadow.mapSize.height=shadowResolution;
 directionalLight.shadow.camera.left=-180;directionalLight.shadow.camera.right=180;directionalLight.shadow.camera.top=180;directionalLight.shadow.camera.bottom=-180;
 directionalLight.shadow.bias=-0.00025;
 scene.add(directionalLight);

 // Oceano tropical e costa irregular para quebrar a aparência de plataforma quadrada.
 const ocean=new THREE.Mesh(new THREE.PlaneGeometry(2600,2600),new THREE.MeshStandardMaterial({color:0x168db8,roughness:.38,metalness:.08}));
 ocean.rotation.x=-Math.PI/2;ocean.position.y=-.42;scene.add(ocean);
 // Terra firme em formato de ilha irregular (malha radial), não uma plataforma quadrada.
 const landGeo=makeIslandLandGeometry(790,735,96,18);
 const floor=new THREE.Mesh(landGeo,new THREE.MeshStandardMaterial({color:0x829a60,map:grassTexture,roughness:1,side:THREE.DoubleSide}));
 floor.receiveShadow=false;scene.add(floor);
 createIslandCoast();
 createSmallCoastalIslands();
 createViceCityAtmosphere();

 createRoads();
 createFuelStations();
 createPlayer();
 createVehicle();
 createBuildings();
 createNaturalDistricts();
 createStreetLife();
 addParkingLots();
 relocateSpawnPoints();
 createPedestrians((window.innerWidth < 900 || /Android|iPhone|iPad/i.test(navigator.userAgent)) ? 42 : 70);
}


function makeIslandLandGeometry(rx,rz,segments,rings){
 const positions=[],uv=[],indices=[];
 for(let ring=0;ring<=rings;ring++){
  const t=ring/rings;
  for(let i=0;i<segments;i++){
   const a=i/segments*Math.PI*2;
   const noise=1+.075*Math.sin(a*3+.7)+.038*Math.sin(a*7+1.3)+.022*Math.cos(a*11-.4);
   // Estreita no norte, alarga no centro e forma uma península ao sul.
   const peninsula=1-.17*Math.max(0,-Math.sin(a))+.09*Math.max(0,Math.sin(a*2+.5));
   const r=t*noise*peninsula;
   positions.push(Math.cos(a)*rx*r + Math.sin(a*2)*18*t, -.02+Math.sin(t*Math.PI)*.018, Math.sin(a)*rz*r);
   uv.push(.5+Math.cos(a)*t*.5,.5+Math.sin(a)*t*.5);
  }
 }
 for(let ring=0;ring<rings;ring++)for(let i=0;i<segments;i++){
  const a=ring*segments+i,b=ring*segments+(i+1)%segments,c=(ring+1)*segments+i,d=(ring+1)*segments+(i+1)%segments;
  indices.push(a,c,b,b,c,d);
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
}
function createSmallCoastalIslands(){
 const landMat=new THREE.MeshStandardMaterial({color:0x7e9c5c,map:grassTexture,roughness:1,side:THREE.DoubleSide});
 const sandMat=new THREE.MeshStandardMaterial({color:0xd9c28e,roughness:1,side:THREE.DoubleSide});
 const specs=[[-900,300,78,52],[-880,410,54,35],[880,-250,58,42],[920,-180,42,31],[180,825,85,44],[-240,820,55,38]];
 function islandGeo(rx,rz,seed,scale){const pos=[],idx=[],seg=40,rings=5;for(let ring=0;ring<=rings;ring++){const t=ring/rings;for(let i=0;i<seg;i++){const a=i/seg*Math.PI*2;const noise=1+.11*Math.sin(a*3+seed)+.055*Math.sin(a*7+seed*.7)+.025*Math.cos(a*11);pos.push(Math.cos(a)*rx*t*noise, .02+Math.sin(t*Math.PI)*.12*scale,Math.sin(a)*rz*t*noise)}}for(let r=0;r<rings;r++)for(let i=0;i<seg;i++){const a=r*seg+i,b=r*seg+(i+1)%seg,c=(r+1)*seg+i,d=(r+1)*seg+(i+1)%seg;idx.push(a,c,b,b,c,d)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();return g}
 specs.forEach(([x,z,rx,rz],i)=>{const sand=new THREE.Mesh(islandGeo(rx*1.13,rz*1.13,i,.2),sandMat);sand.position.set(x,-.01,z);scene.add(sand);const land=new THREE.Mesh(islandGeo(rx,rz,i+2,1),landMat);land.position.set(x,.015,z);scene.add(land);});
 // Pontes com cabeceiras e pilares para ligar as ilhas menores à ilha principal.
 const bridgeMat=new THREE.MeshStandardMaterial({color:0x85827a,roughness:.9}),railMat=new THREE.MeshStandardMaterial({color:0xb6b4ad,roughness:.8}),pillarMat=new THREE.MeshStandardMaterial({color:0x666b70,roughness:.9});
 for(const b of [{x:-840,z:360,w:125,rot:-.22},{x:850,z:-220,w:100,rot:.28},{x:140,z:790,w:95,rot:1.45}]){const deck=new THREE.Mesh(new THREE.BoxGeometry(10,.5,b.w),bridgeMat);deck.position.set(b.x,.25,b.z);deck.rotation.y=b.rot;scene.add(deck);for(let i=-2;i<=2;i++){const rail=new THREE.Mesh(new THREE.BoxGeometry(.18,.7,b.w/5),railMat);rail.position.set(b.x+Math.cos(b.rot)*i*2.4,.65,b.z-Math.sin(b.rot)*i*2.4);rail.rotation.y=b.rot;scene.add(rail)}for(let i=-1;i<=1;i++){const pier=new THREE.Mesh(new THREE.BoxGeometry(.7,2,.7),pillarMat);pier.position.set(b.x+Math.cos(b.rot)*i*b.w*.3,-.65,b.z-Math.sin(b.rot)*i*b.w*.3);scene.add(pier)}}
}

function createIslandCoast(){
 // Praia clara e contorno orgânico em segmentos de costa; a água permanece visível ao redor.
 const sandMat=new THREE.MeshStandardMaterial({color:0xd8c28b,roughness:1});
 const coastPoints=[];
 for(let i=0;i<96;i++){
  const a=i/96*Math.PI*2;
  const wobble=1+Math.sin(a*3+.7)*.055+Math.sin(a*7+1.3)*.025;
  coastPoints.push(new THREE.Vector3(Math.cos(a)*790*wobble,.035,Math.sin(a)*735*wobble));
 }
 const coastGeo=new THREE.BufferGeometry().setFromPoints(coastPoints);const coast=new THREE.LineLoop(coastGeo,new THREE.LineBasicMaterial({color:0xe8d9a8}));scene.add(coast);
 for(let i=0;i<96;i+=2){const a=i/96*Math.PI*2;const r=760*(1+Math.sin(a*3+.7)*.055);const patch=new THREE.Mesh(new THREE.CircleGeometry(19,12),sandMat);patch.rotation.x=-Math.PI/2;patch.position.set(Math.cos(a)*r,.012,Math.sin(a)*r*.93);patch.scale.set(1,.85,1);scene.add(patch)}
 // Faixas de areia orgânicas e rochas pequenas dão profundidade à linha costeira.
 const duneMat=new THREE.MeshStandardMaterial({color:0xc7b47f,roughness:1});
 const rockMat=new THREE.MeshStandardMaterial({color:0x777c70,roughness:1});
 for(let i=0;i<44;i++){
  const a=i*2.39996,r=665+(i%7)*13,x=Math.cos(a)*r,z=Math.sin(a)*r*.92;
  const dune=new THREE.Mesh(new THREE.CircleGeometry(10+(i%4)*2,9),duneMat);dune.rotation.x=-Math.PI/2;dune.position.set(x,.018,z);dune.scale.set(1.8,.7,1);scene.add(dune);
  if(i%3===0){const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(1.1+(i%2)*.6,0),rockMat);rock.position.set(x+Math.cos(a)*7,.45,z+Math.sin(a)*7);rock.scale.y=.55;scene.add(rock)}
 }
}
function createViceCityAtmosphere(){
 // Palmeiras, hotéis pastel e letreiros neon em pontos costeiros, sem carregar modelos externos.
 const trunk=new THREE.MeshStandardMaterial({color:0x765034,roughness:1});
 const fronds=[0x2d8c55,0x3fa765,0x24774c].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:.9}));
 for(let i=0;i<72;i++){
  const a=i*2.39996,r=390+(i%9)*34,x=Math.cos(a)*r,z=Math.sin(a)*r*.86;
  const t=new THREE.Mesh(new THREE.CylinderGeometry(.13,.22,3.8,7),trunk);t.position.set(x,1.9,z);scene.add(t);
  for(let k=0;k<6;k++){const f=new THREE.Mesh(new THREE.ConeGeometry(.16,2.3,5),fronds[(i+k)%fronds.length]);f.position.set(x+Math.cos(k*Math.PI/3)*.85,3.65+Math.sin(k*1.7)*.18,z+Math.sin(k*Math.PI/3)*.85);f.rotation.z=Math.cos(k*Math.PI/3)*.75;f.rotation.x=Math.sin(k*Math.PI/3)*.75;scene.add(f)}
 }
 // Fachadas pastel próximas à orla para uma silhueta art déco reconhecível.
 const pastel=[0xf0a8a2,0xf1d49b,0x8bcbd0,0xf0d9dc,0x9cb7e7];
 for(let i=0;i<12;i++){
  const x=-460+i*84,z=-620+(i%3)*18,h=15+(i%4)*4,w=25+(i%3)*5;
  const mat=new THREE.MeshStandardMaterial({color:pastel[i%pastel.length],roughness:.82});
  const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,18),mat);b.position.set(x,h/2,z);scene.add(b);
  for(let y=2;y<h-1;y+=3)for(let xx=-w/2+3;xx<w/2-1;xx+=5){const win=new THREE.Mesh(new THREE.PlaneGeometry(1.8,1.7),new THREE.MeshStandardMaterial({color:0x23475b,emissive:0x10232c,roughness:.25}));win.position.set(x+xx,y,z-9.12);scene.add(win)}
 }
}

function createRoads(){
 const roadMat=new THREE.MeshStandardMaterial({color:0x777777,map:asphaltTexture,bumpMap:asphaltTexture.userData.surfaceBump,bumpScale:.075,roughness:.96});
 const sidewalkMat=new THREE.MeshStandardMaterial({color:0xc7c3b8,map:sidewalkTexture,bumpMap:sidewalkTexture.userData.surfaceBump,bumpScale:.035,roughness:.96});
 const curbMat=new THREE.MeshStandardMaterial({color:0xd8d5cc,roughness:.9});
 const paint=new THREE.MeshBasicMaterial({color:0xe8dfb5});
 const edge=new THREE.MeshBasicMaterial({color:0xd5d2c8});
 const dashHorizontal=[],dashVertical=[];
 const dummy=new THREE.Object3D();
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  const roadX=new THREE.Mesh(new THREE.PlaneGeometry(CITY_EDGE*2,18),roadMat);
  roadX.rotation.x=-Math.PI/2;roadX.position.set(0,.025,street);scene.add(roadX);
  const roadZ=new THREE.Mesh(new THREE.PlaneGeometry(18,CITY_EDGE*2),roadMat);
  roadZ.rotation.x=-Math.PI/2;roadZ.position.set(street,.03,0);scene.add(roadZ);
  for(const side of [-1,1]){
   const walkX=new THREE.Mesh(new THREE.PlaneGeometry(CITY_EDGE*2,7.5),sidewalkMat);
   walkX.rotation.x=-Math.PI/2;walkX.position.set(0,.04,street+side*13.1);scene.add(walkX);
   const walkZ=new THREE.Mesh(new THREE.PlaneGeometry(6,CITY_EDGE*2),sidewalkMat);
   walkZ.rotation.x=-Math.PI/2;walkZ.position.set(street+side*13.1,.045,0);scene.add(walkZ);
   const curbX=new THREE.Mesh(new THREE.BoxGeometry(CITY_EDGE*2,.22,.3),curbMat);
   curbX.position.set(0,.14,street+side*9.35);scene.add(curbX);
   const curbZ=new THREE.Mesh(new THREE.BoxGeometry(.3,.22,CITY_EDGE*2),curbMat);
   curbZ.position.set(street+side*9.35,.14,0);scene.add(curbZ);
   // Juntas visíveis no passeio: deixam a calçada clara e reconhecível em celulares.
   const jointMat=new THREE.MeshBasicMaterial({color:0xaaa69d});
   for(let along=-CITY_EDGE;along<=CITY_EDGE;along+=8){
    const jointX=new THREE.Mesh(new THREE.PlaneGeometry(.055,7.2),jointMat);
    jointX.rotation.x=-Math.PI/2;jointX.position.set(along,.052,street+side*13.1);scene.add(jointX);
    const jointZ=new THREE.Mesh(new THREE.PlaneGeometry(7.2,.055),jointMat);
    jointZ.rotation.x=-Math.PI/2;jointZ.position.set(street+side*13.1,.053,along);scene.add(jointZ);
   }
   const edgeX=new THREE.Mesh(new THREE.BoxGeometry(CITY_EDGE*2,.035,.12),edge);
   edgeX.position.set(0,.052,street+side*8.2);scene.add(edgeX);
   const edgeZ=new THREE.Mesh(new THREE.BoxGeometry(.12,.035,CITY_EDGE*2),edge);
   edgeZ.position.set(street+side*8.2,.057,0);scene.add(edgeZ);
  }
  for(let along=-CITY_EDGE;along<=CITY_EDGE;along+=10){
   if(Math.min(Math.abs(along%100),100-Math.abs(along%100))<13)continue;
   dashHorizontal.push([along,street]);
   dashVertical.push([street,along]);
  }
 }
 const horizontal=new THREE.InstancedMesh(new THREE.BoxGeometry(4,.04,.18),paint,dashHorizontal.length);
 dashHorizontal.forEach(([x,z],i)=>{dummy.position.set(x,.055,z);dummy.rotation.set(0,0,0);dummy.updateMatrix();horizontal.setMatrixAt(i,dummy.matrix)});
 scene.add(horizontal);
 const vertical=new THREE.InstancedMesh(new THREE.BoxGeometry(.18,.04,4),paint,dashVertical.length);
 dashVertical.forEach(([x,z],i)=>{dummy.position.set(x,.06,z);dummy.rotation.set(0,0,0);dummy.updateMatrix();vertical.setMatrixAt(i,dummy.matrix)});
 scene.add(vertical);
 // Avenidas costeiras curvas para quebrar a leitura de grade perfeita e sugerir a malha de Miami.
 const arterialMat=new THREE.MeshStandardMaterial({color:0x666a6b,map:asphaltTexture,roughness:.95});
 const lineMat=new THREE.MeshBasicMaterial({color:0xe7d6a0});
 function curvedRoad(points,width){const curve=new THREE.CatmullRomCurve3(points.map(([x,z])=>new THREE.Vector3(x,.065,z)));const verts=[],uv=[],idx=[],steps=100;for(let i=0;i<=steps;i++){const t=i/steps,pt=curve.getPoint(t),tan=curve.getTangent(t),nx=-tan.z,nz=tan.x;for(const side of [-1,1]){verts.push(pt.x+nx*width/2*side,.065,pt.z+nz*width/2*side);uv.push(t,side)}}for(let i=0;i<steps;i++){const a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();scene.add(new THREE.Mesh(g,arterialMat));}
 curvedRoad([[-650,-500],[-510,-420],[-390,-260],[-270,-120],[-80,-20],[100,60],[300,120],[500,260],[650,410]],13);
 curvedRoad([[-600,470],[-470,390],[-330,360],[-160,390],[20,470],[220,520],[420,490],[610,400]],11);
 curvedRoad([[-250,650],[-190,520],[-210,390],[-290,260],[-320,100],[-250,-80],[-170,-250],[-130,-430],[-190,-620]],10);
 // Avenidas costeiras e ligações entre bairros, desenhadas em curvas suaves.
 curvedRoad([[ -610,-430],[-500,-360],[-380,-330],[-240,-360],[-80,-410],[90,-430],[260,-390],[430,-315],[590,-260]],12);
 curvedRoad([[610,430],[490,350],[390,240],[330,100],[360,-40],[430,-170],[500,-300]],11);
 curvedRoad([[-570,220],[-450,180],[-330,115],[-190,60],[-40,30],[120,65],[260,135],[420,150],[570,110]],9);

 // Boulevard markings: dashed center lines and curb-edge paint, batched as instanced meshes.
 const laneMat=new THREE.MeshBasicMaterial({color:0xe9dfb8});
 const roadCurbMat=new THREE.MeshBasicMaterial({color:0xc7c5b7});
 const laneGeo=new THREE.BoxGeometry(.16,.028,4.2),curbGeo=new THREE.BoxGeometry(.12,.035,7.5);
 const laneCount=13*96, laneX=new THREE.InstancedMesh(laneGeo,laneMat,laneCount),laneZ=new THREE.InstancedMesh(new THREE.BoxGeometry(4.2,.028,.16),laneMat,laneCount);
 const curbX=new THREE.InstancedMesh(curbGeo,roadCurbMat,13*26*2),curbZ=new THREE.InstancedMesh(new THREE.BoxGeometry(7.5,.035,.12),roadCurbMat,13*26*2);
 const dummyRoad=new THREE.Object3D();let ix=0,iz=0,cx=0,cz=0;
 for(let road=-600;road<=600;road+=100){for(let along=-575;along<=575;along+=12){dummyRoad.position.set(road,.055,along);dummyRoad.updateMatrix();laneX.setMatrixAt(ix++,dummyRoad.matrix);dummyRoad.position.set(along,.055,road);dummyRoad.updateMatrix();laneZ.setMatrixAt(iz++,dummyRoad.matrix)}
  for(let along=-600;along<=600;along+=50){dummyRoad.position.set(road+9.5,.05,along);dummyRoad.updateMatrix();curbX.setMatrixAt(cx++,dummyRoad.matrix);dummyRoad.position.set(road-9.5,.05,along);dummyRoad.updateMatrix();curbX.setMatrixAt(cx++,dummyRoad.matrix);dummyRoad.position.set(along,.05,road+9.5);dummyRoad.updateMatrix();curbZ.setMatrixAt(cz++,dummyRoad.matrix);dummyRoad.position.set(along,.05,road-9.5);dummyRoad.updateMatrix();curbZ.setMatrixAt(cz++,dummyRoad.matrix)}
 }
 scene.add(laneX,laneZ,curbX,curbZ);
}

function createFuelStations(){
 // Dois postos simples, reconhecíveis e baratos para renderizar no Android.
 const concrete=new THREE.MeshStandardMaterial({color:0xbab8ad,roughness:.95});
 const red=new THREE.MeshStandardMaterial({color:0xd84a45,roughness:.65});
 const white=new THREE.MeshStandardMaterial({color:0xf0eee5,roughness:.7});
 const dark=new THREE.MeshStandardMaterial({color:0x343b40,roughness:.8});
 window.fuelStationPositions=[new THREE.Vector3(300,0,-300),new THREE.Vector3(-400,0,200)];
 for(const pos of window.fuelStationPositions){
  const pad=new THREE.Mesh(new THREE.BoxGeometry(38,.12,26),concrete);pad.position.set(pos.x,.03,pos.z);scene.add(pad);
  const canopy=new THREE.Mesh(new THREE.BoxGeometry(27,.65,13),white);canopy.position.set(pos.x,5,pos.z);scene.add(canopy);
  const stripe=new THREE.Mesh(new THREE.BoxGeometry(27,.18,13.1),red);stripe.position.set(pos.x,5.35,pos.z);scene.add(stripe);
  for(const dx of [-10,10]){const post=new THREE.Mesh(new THREE.BoxGeometry(.45,4.5,.45),white);post.position.set(pos.x+dx,2.5,pos.z);scene.add(post)}
  for(const dx of [-7,0,7]){const pump=new THREE.Group();const base=new THREE.Mesh(new THREE.BoxGeometry(1.25,1.8,1.1),red);base.position.y=.95;pump.add(base);const screen=new THREE.Mesh(new THREE.BoxGeometry(.72,.38,.08),dark);screen.position.set(0,1.25,-.57);pump.add(screen);const hose=new THREE.Mesh(new THREE.TorusGeometry(.24,.045,5,10,Math.PI),dark);hose.position.set(.45,1.0,-.45);hose.rotation.z=Math.PI/2;pump.add(hose);pump.position.set(pos.x+dx,0,pos.z+2.6);scene.add(pump)}
 }
}
function refuelVehicle(){
 if(!inVehicle||!vehicle){showGameToast('POSTO DE GASOLINA','Entre em um veículo primeiro.','#ffd166');return}
 const stations=window.fuelStationPositions||[];let near=false;
 for(const station of stations)if(vehicle.position.distanceTo(station)<24)near=true;
 if(!near||Math.abs(speed)>1.8){showGameToast('ABASTECIMENTO','Pare dentro de um posto para abastecer.','#ffd166');return}
 if(fuel>=100){showGameToast('TANQUE CHEIO','Você já tem combustível suficiente.','#b9ff6a');return}
 if(money<25){showGameToast('SEM DINHEIRO','O abastecimento custa $25.','#ff6b6b');return}
 money-=25;fuel=100;updateStatsDisplay();showGameToast('TANQUE CHEIO','Abastecimento concluído por $25.','#b9ff6a');
}
function repairAtGarage(){
 if(!inVehicle||!vehicle){showGameToast('OFICINA','Entre no carro para fazer reparos.','#ffd166');return}
 if(Math.abs(speed)>1.8){showGameToast('OFICINA','Pare o veículo antes do reparo.','#ffd166');return}
 if(money<100){showGameToast('SEM DINHEIRO','O reparo custa $100.','#ff6b6b');return}
 if(carDamage===0&&!vehicleDestroyed&&fuel>=100){showGameToast('VEÍCULO EM ORDEM','Não precisa de reparos agora.','#b9ff6a');return}
 money-=100;carDamage=0;fuel=100;vehicleDestroyed=false;damageStage=-1;
 if(carBody){carBody.scale.set(1,1,1);carBody.rotation.set(0,0,0)}
 const parts=vehicle.userData.damageParts||{};
 for(const [key,pos] of Object.entries({hood:[0,1.03,-1.18],frontBumper:[0,.46,-2.12],rearBumper:[0,.46,2.12],leftDoor:[-.78,.86,.28],rightDoor:[.78,.86,.28]}))if(parts[key]){parts[key].position.set(...pos);parts[key].rotation.set(0,0,0)}
 applyVehicleDamage();updateStatsDisplay();showGameToast('REPARO CONCLUÍDO','Veículo restaurado por $100.','#b9ff6a');
}

function createCharacterGroup(colors={shirt:0x1475df,pants:0x26354a,skin:0xe3ad82}){
 const root=new THREE.Group();
 const shirt=new THREE.MeshStandardMaterial({color:colors.shirt,roughness:.62});
 const pants=new THREE.MeshStandardMaterial({color:colors.pants,roughness:.78});
 const skin=new THREE.MeshStandardMaterial({color:colors.skin,roughness:.72});
 const shoe=new THREE.MeshStandardMaterial({color:0x202126,roughness:.8});
 const torso=new THREE.Mesh(new THREE.BoxGeometry(.62,.78,.34),shirt);torso.position.y=1.22;root.add(torso);
 const hips=new THREE.Mesh(new THREE.BoxGeometry(.48,.24,.3),pants);hips.position.y=.72;root.add(hips);
 const neck=new THREE.Mesh(new THREE.CylinderGeometry(.085,.10,.16,10),skin);neck.position.set(0,1.66,0);root.add(neck);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.22,18,14),skin);head.position.y=1.83;root.add(head);
 const hairMat=new THREE.MeshStandardMaterial({color:0x30251f,roughness:.92});
 const hair=new THREE.Mesh(new THREE.SphereGeometry(.225,16,10,0,Math.PI*2,0,Math.PI*.58),hairMat);hair.position.y=1.89;root.add(hair);
 // Rosto com olhos, sobrancelhas, nariz e orelhas: mantém o modelo leve, mas menos genérico.
 const eyeWhite=new THREE.MeshStandardMaterial({color:0xf1e8d9,roughness:.55});
 const eyeDark=new THREE.MeshStandardMaterial({color:0x201a18,roughness:.5});
 for(const side of [-1,1]){
  const ear=new THREE.Mesh(new THREE.SphereGeometry(.052,8,8),skin);ear.position.set(side*.215,1.82,.005);root.add(ear);
  const eye=new THREE.Mesh(new THREE.SphereGeometry(.027,8,6),eyeWhite);eye.scale.set(1,.72,.5);eye.position.set(side*.075,1.85,.197);root.add(eye);
  const pupil=new THREE.Mesh(new THREE.SphereGeometry(.014,7,5),eyeDark);pupil.position.set(side*.075,1.85,.211);root.add(pupil);
  const brow=new THREE.Mesh(new THREE.BoxGeometry(.075,.018,.018),hairMat);brow.position.set(side*.075,1.895,.194);root.add(brow);
 }
 const nose=new THREE.Mesh(new THREE.SphereGeometry(.035,8,6),skin);nose.scale.set(.75,.8,.8);nose.position.set(0,1.80,.215);root.add(nose);
 const shirtSeam=new THREE.Mesh(new THREE.BoxGeometry(.025,.54,.012),new THREE.MeshStandardMaterial({color:0xffffff,roughness:.8}));shirtSeam.position.set(0,1.22,.174);root.add(shirtSeam);
 const arms=[],legs=[];
 for(const side of [-1,1]){
  const arm=new THREE.Group();arm.position.set(side*.39,1.48,0);root.add(arm);
  const upper=new THREE.Mesh(new THREE.CylinderGeometry(.105,.13,.43,8),shirt);upper.position.y=-.22;arm.add(upper);
  const fore=new THREE.Mesh(new THREE.CylinderGeometry(.075,.09,.36,8),skin);fore.position.set(0,-.58,-.015);arm.add(fore);arms.push(arm);
  const leg=new THREE.Group();leg.position.set(side*.16,.68,0);root.add(leg);
  const thigh=new THREE.Mesh(new THREE.CylinderGeometry(.12,.14,.4,8),pants);thigh.position.y=-.2;leg.add(thigh);
  const shin=new THREE.Mesh(new THREE.CylinderGeometry(.075,.1,.34,8),pants);shin.position.y=-.55;leg.add(shin);
  const footMat=colors.playerShoes?new THREE.MeshStandardMaterial({color:0xe2e0d7,roughness:.8}):shoe;const foot=new THREE.Mesh(new THREE.BoxGeometry(.17,.11,.30),footMat);foot.position.set(0,-.62,.055);leg.add(foot);legs.push(leg);
 }
 root.userData={arms,legs,walkPhase:Math.random()*6,character:true};
 return root;
}
function createPlayer(){
 // CJ: protagonista inspirado no visual de San Andreas, com camiseta verde e jeans azul.
 player=createCharacterGroup({shirt:0x2f6d46,pants:0x243e83,skin:0x80543b,playerShoes:true});
 player.position.set(0,0,8);player.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});scene.add(player);
 player.scale.set(1.06,1.06,1.06);
 // Detalhes de roupa e silhueta do protagonista, mantendo a malha leve para celular.
 const belt=new THREE.Mesh(new THREE.BoxGeometry(.49,.07,.31),new THREE.MeshStandardMaterial({color:0x29251f,roughness:.85}));belt.position.set(0,.81,0);player.add(belt);
 const buckle=new THREE.Mesh(new THREE.BoxGeometry(.105,.065,.025),new THREE.MeshStandardMaterial({color:0xb6a36b,metalness:.65,roughness:.32}));buckle.position.set(0,.81,.17);player.add(buckle);
 const denim=new THREE.MeshStandardMaterial({color:0x263f86,roughness:.9});
 const cjShirtMat=new THREE.MeshStandardMaterial({color:0x2f6d46,roughness:.62});
 for(const side of [-1,1]){
  const pocket=new THREE.Mesh(new THREE.BoxGeometry(.13,.13,.025),denim);pocket.position.set(side*.145,.78,.16);player.add(pocket);
  const shoulder=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),cjShirtMat);shoulder.scale.set(1,.8,1);shoulder.position.set(side*.31,1.48,0);player.add(shoulder);
 }
 // Costuras discretas na calça e gola da camiseta.
 const seamMat=new THREE.MeshStandardMaterial({color:0x5877bf,roughness:.9});
 for(const side of [-1,1]){const seam=new THREE.Mesh(new THREE.BoxGeometry(.012,.43,.012),seamMat);seam.position.set(side*.13,.39,.153);player.add(seam)}
 const collar=new THREE.Mesh(new THREE.TorusGeometry(.095,.018,6,12),new THREE.MeshStandardMaterial({color:0x1b4c34,roughness:.8}));collar.position.set(0,1.59,.005);collar.rotation.x=Math.PI/2;player.add(collar);
}
function createMikuNPC(){
 // Hatsune Miku estilizada em 3D local: olhos anime, franja, twin-tails,
 // headset, gravata, saia plissada e botas. Não depende de download externo.
 const miku=createCharacterGroup({shirt:0x252b42,pants:0x252d46,skin:0xffd8c5});
 miku.scale.set(.88,.92,.88);
 const hairMat=new THREE.MeshStandardMaterial({color:0x12cbd0,roughness:.48,metalness:.08});
 const hairDark=new THREE.MeshStandardMaterial({color:0x079ca8,roughness:.52,metalness:.05});
 const blackMat=new THREE.MeshStandardMaterial({color:0x252b3b,roughness:.48,metalness:.2});
 const pinkMat=new THREE.MeshStandardMaterial({color:0xf04f8b,roughness:.45,metalness:.1});
 // Rabos compridos em segmentos cônicos curvados, com pontas mais finas.
 for(const side of [-1,1]){
  const upper=new THREE.Mesh(new THREE.CylinderGeometry(.105,.13,.43,10),hairMat);upper.position.set(side*.29,1.60,-.015);upper.rotation.z=side*-.16;miku.add(upper);
  const middle=new THREE.Mesh(new THREE.CylinderGeometry(.075,.105,.43,10),hairMat);middle.position.set(side*.36,1.22,-.005);middle.rotation.z=side*-.28;miku.add(middle);
  const tip=new THREE.Mesh(new THREE.ConeGeometry(.075,.38,10),hairDark);tip.position.set(side*.43,.84,.005);tip.rotation.z=side*-.32;miku.add(tip);
  const tie=new THREE.Mesh(new THREE.BoxGeometry(.18,.12,.12),blackMat);tie.position.set(side*.27,1.82,.015);miku.add(tie);
  const tieStripe=new THREE.Mesh(new THREE.BoxGeometry(.19,.025,.126),pinkMat);tieStripe.position.set(side*.27,1.82,.08);miku.add(tieStripe);
  // Headset e microfone em ambos os lados.
  const earcup=new THREE.Mesh(new THREE.BoxGeometry(.075,.16,.08),blackMat);earcup.position.set(side*.225,1.82,.015);miku.add(earcup);
 }
 const bangs=new THREE.Mesh(new THREE.SphereGeometry(.226,16,10,0,Math.PI*2,0,Math.PI*.56),hairMat);bangs.position.set(0,1.91,-.012);miku.add(bangs);
 for(const side of [-1,1]){
  const lock=new THREE.Mesh(new THREE.ConeGeometry(.075,.24,8),hairMat);lock.position.set(side*.115,1.76,.13);lock.rotation.z=side*-.18;miku.add(lock);
  // Olhos grandes turquesa com brilho, sobre os olhos básicos do personagem.
  const iris=new THREE.Mesh(new THREE.SphereGeometry(.043,10,8),new THREE.MeshStandardMaterial({color:0x16bfc8,roughness:.3,metalness:.1}));iris.scale.set(1,.95,.45);iris.position.set(side*.075,1.85,.218);miku.add(iris);
  const glint=new THREE.Mesh(new THREE.SphereGeometry(.012,6,5),new THREE.MeshBasicMaterial({color:0xffffff}));glint.position.set(side*.065,1.868,.238);miku.add(glint);
 }
 // Gravata preta e detalhe rosa no busto.
 const tie=new THREE.Mesh(new THREE.BoxGeometry(.095,.27,.045),blackMat);tie.position.set(0,1.36,.195);miku.add(tie);
 const tieKnot=new THREE.Mesh(new THREE.BoxGeometry(.12,.07,.055),pinkMat);tieKnot.position.set(0,1.51,.2);miku.add(tieKnot);
 // Saia plissada turquesa com painéis escuros alternados.
 const skirtMat=new THREE.MeshStandardMaterial({color:0x13b8c1,roughness:.7,side:THREE.DoubleSide});
 const skirt=new THREE.Mesh(new THREE.CylinderGeometry(.25,.37,.28,12,1,true),skirtMat);skirt.position.set(0,.72,0);miku.add(skirt);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;const pleat=new THREE.Mesh(new THREE.BoxGeometry(.018,.25,.012),hairDark);pleat.position.set(Math.sin(a)*.31,.72,Math.cos(a)*.31);pleat.rotation.y=a;miku.add(pleat)}
 const hem=new THREE.Mesh(new THREE.TorusGeometry(.35,.025,6,16),blackMat);hem.position.y=.58;hem.rotation.x=Math.PI/2;miku.add(hem);
 // Mangas, punhos e botas de palco.
 for(const side of [-1,1]){
  const sleeve=new THREE.Mesh(new THREE.CylinderGeometry(.12,.105,.22,8),blackMat);sleeve.position.set(side*.42,1.39,0);sleeve.rotation.z=side*-.12;miku.add(sleeve);
  const cuff=new THREE.Mesh(new THREE.BoxGeometry(.13,.07,.13),new THREE.MeshStandardMaterial({color:0x9ba5b8,metalness:.45,roughness:.4}));cuff.position.set(side*.43,1.22,.01);miku.add(cuff);
  const boot=new THREE.Mesh(new THREE.BoxGeometry(.18,.17,.31),blackMat);boot.position.set(side*.14,.075,.045);miku.add(boot);
  const bootStripe=new THREE.Mesh(new THREE.BoxGeometry(.185,.035,.315),pinkMat);bootStripe.position.set(side*.14,.13,.045);miku.add(bootStripe);
 }
 miku.userData.isMiku=true;
 return miku;
}
function animateCharacter(character,dt,moving=true){
 if(!character||!character.userData.character)return;
 const ud=character.userData;ud.walkPhase=(ud.walkPhase||0)+dt*(moving?10:2);
 const swing=moving?Math.sin(ud.walkPhase)*.58:0;
 ud.legs.forEach((limb,i)=>{limb.rotation.x=(i===0?1:-1)*swing});
 ud.arms.forEach((limb,i)=>{limb.rotation.x=(i===0?-1:1)*swing*.8;limb.rotation.z=(i===0?-.04:.04)+(moving?Math.cos(ud.walkPhase)*.035:0)});
 const torso=character.children.find(o=>o.isMesh&&o.geometry&&o.geometry.type==='BoxGeometry'&&Math.abs(o.position.y-1.22)<.01);
 if(torso)torso.position.y=1.22+(moving?Math.abs(Math.sin(ud.walkPhase*2))*.035:0);
}

function createVehicle(){
 vehicle=new THREE.Group();
 vehicle.userData.isPersonalVehicle=true;
 const paint=new THREE.MeshStandardMaterial({color:0xd52657,roughness:.16,metalness:.72});
 const glass=new THREE.MeshStandardMaterial({color:0x172b3a,roughness:.18,metalness:.25});
 const rubber=new THREE.MeshStandardMaterial({color:0x17191c,roughness:.92});
 carBody=new THREE.Group();vehicle.add(carBody);vehicle.userData.driveBody=carBody;
 vehicle.userData.damageParts={hood:null,frontBumper:null,rearBumper:null,leftDoor:null,rightDoor:null};
 wheelMeshes=[];vehicle.userData.driveWheels=wheelMeshes;
 const lower=new THREE.Mesh(new THREE.BoxGeometry(2,.58,4.15),paint);
 lower.position.y=.67;carBody.add(lower);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(1.82,.22,1.32),paint);
 hood.position.set(0,1.03,-1.18);carBody.add(hood);vehicle.userData.damageParts.hood=hood;
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.52,.72,1.95),glass);
 cabin.position.set(0,1.25,.08);carBody.add(cabin);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(1.42,.12,1.58),paint);
 roof.position.set(0,1.64,.13);carBody.add(roof);
 const bumperMat=new THREE.MeshStandardMaterial({color:0x282b30,metalness:.55,roughness:.4});
 for(const z of [-2.12,2.12]){
  const bumper=new THREE.Mesh(new THREE.BoxGeometry(1.9,.18,.16),bumperMat);
  bumper.position.set(0,.46,z);carBody.add(bumper);vehicle.userData.damageParts[z<0?'frontBumper':'rearBumper']=bumper;
 }
 const headlightMat=new THREE.MeshStandardMaterial({color:0xfff1cb,emissive:0xffd27a,emissiveIntensity:.8});
 const tailMat=new THREE.MeshStandardMaterial({color:0xc21c2c,emissive:0x66000a,emissiveIntensity:.45});
 for(const x of [-.68,.68]){
  const headlight=new THREE.Mesh(new THREE.BoxGeometry(.38,.2,.08),headlightMat);
  headlight.position.set(x,.78,-2.1);carBody.add(headlight);
  const tail=new THREE.Mesh(new THREE.BoxGeometry(.38,.2,.08),tailMat);
  tail.position.set(x,.78,2.1);carBody.add(tail);
 }
 const wheelGeo=new THREE.CylinderGeometry(.39,.39,.28,12);
 const rimMat=new THREE.MeshStandardMaterial({color:0x929ba4,metalness:.8,roughness:.28});
 for(const x of [-.98,.98])for(const z of [-1.34,1.34]){
  const wheel=new THREE.Mesh(wheelGeo,rubber);wheel.rotation.z=Math.PI/2;
  wheel.position.set(x,.4,z);wheel.userData.isDriveWheel=true;vehicle.add(wheel);wheelMeshes.push(wheel);
  const rim=new THREE.Mesh(new THREE.CylinderGeometry(.19,.19,.30,12),rimMat);rim.rotation.z=Math.PI/2;rim.position.set(x*1.015,.4,z);vehicle.add(rim);
 }
 // Detalhes extras da carroceria: grade, placas, maçanetas, escapamentos e arcos de roda.
 const grilleMat=new THREE.MeshStandardMaterial({color:0x25292c,metalness:.62,roughness:.42});
 const chromeMat=new THREE.MeshStandardMaterial({color:0xb6c1c7,metalness:.86,roughness:.22});
 const plateMat=new THREE.MeshStandardMaterial({color:0xe8e5d8,roughness:.7});
 const grille=new THREE.Mesh(new THREE.BoxGeometry(.82,.22,.045),grilleMat);grille.position.set(0,.69,-2.095);carBody.add(grille);
 for(let i=0;i<6;i++){const slat=new THREE.Mesh(new THREE.BoxGeometry(.72,.018,.025),chromeMat);slat.position.set(0,.61+i*.032,-2.125);carBody.add(slat)}
 for(const z of [-2.19,2.19]){const plate=new THREE.Mesh(new THREE.BoxGeometry(.48,.15,.025),plateMat);plate.position.set(0,.55,z);carBody.add(plate);for(let i=0;i<4;i++){const digit=new THREE.Mesh(new THREE.BoxGeometry(.035,.065,.008),grilleMat);digit.position.set(-.12+i*.08,.55,z+(z<0?-.016:.016));carBody.add(digit)}}
 for(const side of [-1,1]){const handle=new THREE.Mesh(new THREE.BoxGeometry(.13,.035,.025),chromeMat);handle.position.set(side*.805,.94,.28);carBody.add(handle);const trim=new THREE.Mesh(new THREE.BoxGeometry(.035,.38,.025),chromeMat);trim.position.set(side*.805,.86,.28);carBody.add(trim)}
 const rearStrip=new THREE.Mesh(new THREE.BoxGeometry(1.35,.10,.045),tailMat);rearStrip.position.set(0,.80,2.105);carBody.add(rearStrip);
 for(const x of [-.55,.55]){const exhaust=new THREE.Mesh(new THREE.CylinderGeometry(.07,.08,.22,8),chromeMat);exhaust.rotation.x=Math.PI/2;exhaust.position.set(x,.35,2.17);carBody.add(exhaust)}
 const archMat=new THREE.MeshStandardMaterial({color:0x25282c,roughness:.8});
 for(const x of [-.98,.98])for(const z of [-1.34,1.34]){const arch=new THREE.Mesh(new THREE.TorusGeometry(.43,.065,6,14,Math.PI),archMat);arch.rotation.z=x<0?Math.PI/2:-Math.PI/2;arch.rotation.x=Math.PI/2;arch.position.set(x,.43,z);carBody.add(arch)}
 const windshield=new THREE.Mesh(new THREE.PlaneGeometry(1.35,.53),glass);windshield.position.set(0,1.35,-.88);windshield.rotation.x=-.25;carBody.add(windshield);
 const rearGlass=new THREE.Mesh(new THREE.PlaneGeometry(1.28,.45),glass);rearGlass.position.set(0,1.35,1.02);rearGlass.rotation.x=Math.PI+.24;carBody.add(rearGlass);
 const sideWindowMat=new THREE.MeshStandardMaterial({color:0x314b59,roughness:.2,metalness:.2});
 for(const side of [-1,1]){
  for(const z of [-.55,.55]){const seam=new THREE.Mesh(new THREE.BoxGeometry(.025,.34,.025),new THREE.MeshStandardMaterial({color:0x30343a}));seam.position.set(side*.765,1.27,z);carBody.add(seam)}
  const mirror=new THREE.Mesh(new THREE.BoxGeometry(.16,.12,.19),paint);mirror.position.set(side*1.02,1.15,-.67);carBody.add(mirror);
  const window=new THREE.Mesh(new THREE.PlaneGeometry(.62,.36),sideWindowMat);window.rotation.y=side*Math.PI/2;window.position.set(side*.766,1.28,.02);carBody.add(window);
  const door=new THREE.Mesh(new THREE.BoxGeometry(.035,.42,.78),paint);door.position.set(side*.78,.86,.28);carBody.add(door);vehicle.userData.damageParts[side<0?'leftDoor':'rightDoor']=door;
 }
 // Marcas de impacto visíveis: amassados escuros, riscos na pintura e trincas no para-brisa.
 const damageVisuals=[];
 const dentMat=new THREE.MeshStandardMaterial({color:0x29252a,roughness:.9,metalness:.08,transparent:true,opacity:.88,depthWrite:false});
 const scratchMat=new THREE.MeshStandardMaterial({color:0xb7a7a0,roughness:.86,metalness:.18,transparent:true,opacity:.9,depthWrite:false});
 const crackMat=new THREE.MeshBasicMaterial({color:0x9ab4c2,transparent:true,opacity:.92});
 function damagePatch(w,h,d,x,y,z,mat,rotZ=0){
  const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.rotation.z=rotZ;m.visible=false;carBody.add(m);damageVisuals.push(m);return m;
 }
 // Amassados nas extremidades e nos dois lados da carroceria.
 damagePatch(.72,.16,.025,0,.91,-1.84,dentMat,-.08);
 damagePatch(.62,.14,.025,0,.89,1.82,dentMat,.06);
 damagePatch(.025,.24,.44,-.806,.84,-.62,dentMat,.12);
 damagePatch(.025,.22,.42,.806,.85,.78,dentMat,-.10);
 // Riscos finos que aparecem junto com o dano médio.
 damagePatch(.42,.018,.018,-.28,1.151,-1.40,scratchMat,-.14);
 damagePatch(.32,.016,.018,.30,1.145,-1.28,scratchMat,.12);
 damagePatch(.018,.23,.018,-.806,.87,.45,scratchMat,.16);
 damagePatch(.018,.20,.018,.806,.87,-.12,scratchMat,-.12);
 // Pequenas linhas de trinca sobre o para-brisa dianteiro.
 const crackGroup=new THREE.Group();crackGroup.position.set(0,1.35,-.905);crackGroup.rotation.x=-.25;crackGroup.visible=false;carBody.add(crackGroup);damageVisuals.push(crackGroup);
 const crackPoints=[[-.48,.16,0,-.20,.02,0],[-.20,.02,0,-.05,-.12,0],[-.20,.02,0,-.35,-.10,0],[.06,.12,0,.20,-.02,0],[.20,-.02,0,.34,-.16,0],[.20,-.02,0,.44,.04,0]];
 const crackGeometry=new THREE.BufferGeometry();crackGeometry.setAttribute('position',new THREE.Float32BufferAttribute(crackPoints.flat(),3));
 crackGroup.add(new THREE.LineSegments(crackGeometry,crackMat));
 vehicle.userData.damageVisuals=damageVisuals;
 vehicle.position.set(2.5,0,4);vehicle.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});
 scene.add(vehicle);
}

function addCityBuilding(x,z,width,depth,height,tint){
 const variation=Math.abs(Math.round(x*11+z*7))%9;
 width*=.93+(variation%5)*.025;depth*=.92+((variation*3)%5)*.025;height*=.86+((variation*5)%7)*.035;
 const geometry=new THREE.BoxGeometry(width,height,depth);
 const facadeColor=new THREE.Color(tint).offsetHSL(0,(variation-4)*.012,(variation-4)*.018);
 const facadeMap=facadeTextures[activeFacadeIndex]||facadeTexture;
 const material=new THREE.MeshStandardMaterial({color:facadeColor,map:facadeMap,bumpMap:facadeMap.userData.surfaceBump,bumpScale:activeFacadeIndex===2?.018:.055,roughness:activeFacadeIndex===2?.34:.88,metalness:activeFacadeIndex===2 ? .24 : .04});
 const building=new THREE.Mesh(geometry,material);
 building.position.set(x,height/2,z);building.castShadow=true;building.receiveShadow=true;scene.add(building);
 // Rooflines vary so the skyline does not read as a field of identical cubes.
 const roofMat=new THREE.MeshStandardMaterial({color:variation%3===0?0x514d49:(variation%3===1?0x77736c:0x393f43),roughness:.9});
 if(variation%4===0){
  const roof=new THREE.Mesh(new THREE.ConeGeometry(Math.max(width,depth)*.72,Math.min(5,height*.24),4),roofMat);
  roof.rotation.y=Math.PI/4;roof.position.set(x,height+Math.min(2.5,height*.12),z);scene.add(roof);
 }else{
  const roof=new THREE.Mesh(new THREE.BoxGeometry(width+.35,.28,depth+.35),roofMat);
  roof.position.set(x,height+.14,z);scene.add(roof);
 }
 // Real window rhythm on street-facing walls; different floors and spacing per building.
 const windowMat=new THREE.MeshStandardMaterial({color:variation%3===0?0x9bc9d1:0x263d4b,roughness:.24,metalness:.22,emissive:variation%3===0?0x101d20:0x020609});
 const trimMat=new THREE.MeshStandardMaterial({color:0xc4bba8,roughness:.75});
 const cols=Math.max(2,Math.min(7,Math.floor(width/3.3))), floors=Math.max(1,Math.min(9,Math.floor((height-1.8)/3.2)));
 const winW=Math.min(1.45,width/(cols*1.8)), winH=Math.min(1.55,height/(floors*2.1));
 for(let f=0;f<floors;f++)for(let c=0;c<cols;c++){
  const wx=x-width/2+(c+.5)*width/cols, wy=1.35+f*((height-1.8)/floors);
  const front=new THREE.Mesh(new THREE.PlaneGeometry(winW,winH),windowMat);front.position.set(wx,wy,z+depth/2+.012);scene.add(front);
  if(variation%2===0){const side=new THREE.Mesh(new THREE.PlaneGeometry(winW,winH),windowMat);side.rotation.y=Math.PI/2;side.position.set(x+width/2+.012,wy,z-depth/2+(c+.5)*depth/cols);scene.add(side)}
 }
 // Fachadas mais urbanas: marquises, entradas, letreiros comerciais e unidades de ar-condicionado.
 if(height<18){
  const shopColors=[0xe9a64c,0x48c6c8,0xe56e77,0x82c978,0xe6dfc9];
  const signColor=shopColors[variation%shopColors.length];
  const awning=new THREE.Mesh(new THREE.BoxGeometry(width*.92,.22,1.05),new THREE.MeshStandardMaterial({color:signColor,roughness:.62,metalness:.08}));
  awning.position.set(x,Math.min(4.1,height*.42),z+depth/2+.42);scene.add(awning);
  const signCanvas=document.createElement('canvas');signCanvas.width=256;signCanvas.height=64;
  const signCtx=signCanvas.getContext('2d');signCtx.fillStyle=['#132a38','#3c2028','#123c37','#29223e'][variation%4];signCtx.fillRect(0,0,256,64);
  signCtx.fillStyle=['#ffd778','#70f4e5','#ff8eaa','#e7edff'][variation%4];signCtx.font='bold 27px Arial';signCtx.textAlign='center';signCtx.textBaseline='middle';
  signCtx.fillText(['MARKET','VICE CAFE','MOTORS','MINI MART','HOTEL'][variation%5],128,33,240);
  const signTex=new THREE.CanvasTexture(signCanvas);signTex.encoding=THREE.sRGBEncoding;
  const signMesh=new THREE.Mesh(new THREE.PlaneGeometry(Math.max(3,width*.68),1.15),new THREE.MeshBasicMaterial({map:signTex,side:THREE.DoubleSide}));
  signMesh.position.set(x,Math.min(5.1,height*.52),z+depth/2+.48);scene.add(signMesh);
 }else{
  // Faixas de andares e equipamentos de cobertura quebram silhuetas repetitivas.
  for(let floorIndex=1;floorIndex<Math.min(5,Math.floor(height/7));floorIndex++){
   const band=new THREE.Mesh(new THREE.BoxGeometry(width+.16,.11,depth+.16),trimMat);band.position.set(x,floorIndex*height/Math.min(5,Math.floor(height/7)),z);scene.add(band);
  }
  if(variation%2===0){
   const acMat=new THREE.MeshStandardMaterial({color:0x727c80,metalness:.35,roughness:.68});
   const ac=new THREE.Mesh(new THREE.BoxGeometry(1.2,.72,.75),acMat);ac.position.set(x+width*.25,height+.58,z+depth*.22);scene.add(ac);
   const grille=new THREE.Mesh(new THREE.BoxGeometry(.72,.38,.035),new THREE.MeshStandardMaterial({color:0x30383b,roughness:.8}));grille.position.set(ac.position.x,ac.position.y,ac.position.z+.39);scene.add(grille);
  }
 }
 if(height>14 && variation%3===1){
  const ledge=new THREE.Mesh(new THREE.BoxGeometry(width+.45,.28,depth+.45),trimMat);ledge.position.set(x,height*.55,z);scene.add(ledge);
 }
 buildingColliders.push({x,z,halfX:width/2,halfZ:depth/2});
 return building;
}
function addLocationSign(location){
 const canvas=document.createElement("canvas");canvas.width=256;canvas.height=64;
 const ctx=canvas.getContext("2d");
 ctx.fillStyle="#12333a";ctx.fillRect(0,0,256,64);
 ctx.fillStyle="#24c3b4";ctx.fillRect(0,0,7,64);
 ctx.fillStyle="#f7f1da";ctx.textAlign="center";ctx.textBaseline="middle";
 ctx.font="bold 16px Arial";ctx.fillText(location.title,136,21,236);
 ctx.font="bold 12px Arial";ctx.fillStyle="#7ce0d0";ctx.fillText(location.district,136,46,230);
 const texture=new THREE.CanvasTexture(canvas);texture.encoding=THREE.sRGBEncoding;
 const board=new THREE.Mesh(new THREE.BoxGeometry(19,3.8,.45),new THREE.MeshStandardMaterial({color:0x18232a,roughness:.6}));
 board.position.set(location.x,5.2,location.z+(location.z>0?-28:28));
 const face=new THREE.Mesh(new THREE.PlaneGeometry(18.4,3.25),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}));
 face.position.set(board.position.x,board.position.y,board.position.z+(location.z>0?-.24:.24));
 if(location.z>0)face.rotation.y=Math.PI;
 scene.add(board,face);
}
function addVenueDetails(location){
 const {x,z,type}=location;
 const concrete=new THREE.MeshStandardMaterial({color:0xaaa79e,map:sidewalkTexture,roughness:.92});
 if(type===0){
  const lawn=new THREE.Mesh(new THREE.PlaneGeometry(68,68),new THREE.MeshStandardMaterial({color:0xaab98b,map:parkGrassTexture,roughness:1}));
  lawn.rotation.x=-Math.PI/2;lawn.position.set(x,.012,z);scene.add(lawn);
  const pathA=new THREE.Mesh(new THREE.PlaneGeometry(4,64),concrete);pathA.rotation.x=-Math.PI/2;pathA.position.set(x,.025,z);scene.add(pathA);
  const pathB=new THREE.Mesh(new THREE.PlaneGeometry(64,4),concrete);pathB.rotation.x=-Math.PI/2;pathB.position.set(x,.03,z);scene.add(pathB);
  addCityBuilding(x,z,14,12,6,0xd9d1b5);
 }else if(type===1){
  addCityBuilding(x,z,42,31,14,0xf0d9b6);
  for(const side of [-1,1]){const stall=new THREE.Mesh(new THREE.BoxGeometry(9,4,8),new THREE.MeshStandardMaterial({color:side<0?0xc86743:0x398d80,roughness:.8}));stall.position.set(x+side*25,2,z+17);scene.add(stall)}
 }else if(type===2){
  addCityBuilding(x-7,z,34,30,30,0xe6e8e4);addCityBuilding(x+22,z+9,17,18,17,0xf1f0e9);
  const crossMat=new THREE.MeshStandardMaterial({color:0xd64b46,emissive:0x43100c});
  const crossA=new THREE.Mesh(new THREE.BoxGeometry(5,.7,1),crossMat);crossA.position.set(x,25,z-15);scene.add(crossA);
  const crossB=new THREE.Mesh(new THREE.BoxGeometry(1,.7,5),crossMat);crossB.position.set(x,25,z-15);scene.add(crossB);
 }else if(type===3){
  addCityBuilding(x,z,48,24,12,0xc9d0ce);
  const canopy=new THREE.Mesh(new THREE.BoxGeometry(52,.65,7),new THREE.MeshStandardMaterial({color:0x357f89,metalness:.25,roughness:.5}));canopy.position.set(x,8,z+20);scene.add(canopy);
  for(let t=-1;t<=1;t++){const rail=new THREE.Mesh(new THREE.BoxGeometry(54,.12,.12),new THREE.MeshStandardMaterial({color:0x555b5e,metalness:.7}));rail.position.set(x,.22,z+t*2);scene.add(rail)}
 }else if(type===4){
  addCityBuilding(x,z,34,30,18,0xdccfae);
  const columnGeo=new THREE.CylinderGeometry(.65,.8,6,8),columnMat=new THREE.MeshStandardMaterial({color:0xeee4cf,roughness:.75});
  for(let c=-2;c<=2;c++){const column=new THREE.Mesh(columnGeo,columnMat);column.position.set(x+c*5,3,z-16);scene.add(column)}
 }else if(type===5){
  const arena=new THREE.Mesh(new THREE.CylinderGeometry(25,27,15,16),new THREE.MeshStandardMaterial({color:0x899599,map:facadeTextures[activeFacadeIndex]||facadeTexture,roughness:.8}));arena.position.set(x,7.5,z);scene.add(arena);
  const roof=new THREE.Mesh(new THREE.TorusGeometry(24,.8,8,24),new THREE.MeshStandardMaterial({color:0x3b5961,metalness:.3,roughness:.6}));roof.rotation.x=Math.PI/2;roof.position.set(x,15,z);scene.add(roof);
  buildingColliders.push({x,z,halfX:26,halfZ:26});
 }else if(type===6){
  addCityBuilding(x,z,38,29,20,0xe0d8c9);
  const columnGeo=new THREE.CylinderGeometry(.42,.55,8,8),columnMat=new THREE.MeshStandardMaterial({color:0xeee5d8,roughness:.7});
  for(let c=-2;c<=2;c++){const column=new THREE.Mesh(columnGeo,columnMat);column.position.set(x+c*5,4,z-15);scene.add(column)}
 }else if(type===7){
  addCityBuilding(x-11,z,25,35,17,0xd4dcd9);addCityBuilding(x+13,z,25,35,14,0xe4d5bd);
  const atrium=new THREE.Mesh(new THREE.BoxGeometry(13,11,18),new THREE.MeshStandardMaterial({color:0x4794a0,metalness:.2,roughness:.3}));atrium.position.set(x,5.5,z-4);scene.add(atrium);
 }else if(type===8){
  const plaza=new THREE.Mesh(new THREE.PlaneGeometry(64,64),concrete);plaza.rotation.x=-Math.PI/2;plaza.position.set(x,.015,z);scene.add(plaza);
  const pool=new THREE.Mesh(new THREE.CylinderGeometry(6,6,.45,16),new THREE.MeshStandardMaterial({color:0x45a9b5,metalness:.4,roughness:.2,transparent:true,opacity:.86}));pool.position.set(x,.25,z);scene.add(pool);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(6,.45,8,20),new THREE.MeshStandardMaterial({color:0xd6d0bd,roughness:.72}));rim.rotation.x=Math.PI/2;rim.position.set(x,.5,z);scene.add(rim);
 }else if(type===9){
  addCityBuilding(x-14,z,22,25,14,0xe2ddc9);addCityBuilding(x+13,z-7,24,23,21,0xd3d9d4);
  const hall=new THREE.Mesh(new THREE.BoxGeometry(14,7,12),new THREE.MeshStandardMaterial({color:0x417d86,metalness:.2,roughness:.4}));hall.position.set(x,3.5,z+17);scene.add(hall);
 }else if(type===10){
  addCityBuilding(x,z,46,29,15,0xe2d7c7);
  const doorMat=new THREE.MeshStandardMaterial({color:0x28343b,roughness:.45});
  for(let bay=-1;bay<=1;bay++){const door=new THREE.Mesh(new THREE.BoxGeometry(8,5,.28),doorMat);door.position.set(x+bay*13,2.5,z-14.8);scene.add(door)}
  const tower=new THREE.Mesh(new THREE.BoxGeometry(9,24,9),new THREE.MeshStandardMaterial({color:0xc55d45,map:facadeTextures[activeFacadeIndex]||facadeTexture,roughness:.8}));tower.position.set(x-25,12,z+17);scene.add(tower);
 }else if(type===11){
  addCityBuilding(x,z-18,32,16,10,0xe0eee3);
  const glassHouse=new THREE.Mesh(new THREE.BoxGeometry(35,10,19),new THREE.MeshStandardMaterial({color:0x72a99b,transparent:true,opacity:.48,metalness:.15,roughness:.2}));glassHouse.position.set(x,5,z+13);scene.add(glassHouse);
  const roof=new THREE.Mesh(new THREE.ConeGeometry(24,13,8),new THREE.MeshStandardMaterial({color:0x659366,roughness:.8}));roof.position.set(x,6.5,z-14);scene.add(roof);
 }else if(type===12){
  addCityBuilding(x-13,z-13,28,24,17,0xc3d0d2);
  const pad=new THREE.Mesh(new THREE.CylinderGeometry(17,17,.45,20),new THREE.MeshStandardMaterial({color:0x525d60,roughness:.86}));pad.position.set(x+17,.24,z+15);scene.add(pad);
  const hMat=new THREE.MeshBasicMaterial({color:0xffdf5c});
  const h1=new THREE.Mesh(new THREE.BoxGeometry(2,.05,12),hMat);h1.position.set(x+17,.5,z+15);scene.add(h1);
  const h2=new THREE.Mesh(new THREE.BoxGeometry(10,.05,2),hMat);h2.position.set(x+17,.5,z+15);scene.add(h2);
 }else if(type===13){
  addCityBuilding(x-9,z,34,29,18,0xd7e2df);
  const tank=new THREE.Mesh(new THREE.CylinderGeometry(9,9,12,20),new THREE.MeshStandardMaterial({color:0x38a9c5,transparent:true,opacity:.72,metalness:.22,roughness:.18}));tank.position.set(x+17,6,z+8);scene.add(tank);
  for(let b=0;b<6;b++){const bubble=new THREE.Mesh(new THREE.SphereGeometry(.55+(b%2)*.3,7,6),new THREE.MeshBasicMaterial({color:0xb6f4f1,transparent:true,opacity:.75}));bubble.position.set(x+12+(b%3)*4,2+(b%4)*2,z+8);scene.add(bubble)}
 }else if(type===15){
  // Modern airport terminal and runway markings.
  addCityBuilding(x,z,48,24,16,0xc9d5d8);
  const glass=new THREE.Mesh(new THREE.BoxGeometry(32,8,1),new THREE.MeshStandardMaterial({color:0x58a9bc,metalness:.35,roughness:.22,transparent:true,opacity:.78}));glass.position.set(x,7,z-12.3);scene.add(glass);
  const runway=new THREE.Mesh(new THREE.PlaneGeometry(76,15),new THREE.MeshStandardMaterial({color:0x454b50,roughness:1}));runway.rotation.x=-Math.PI/2;runway.position.set(x,0.035,z+28);scene.add(runway);
  for(let i=-5;i<=5;i++){const mark=new THREE.Mesh(new THREE.BoxGeometry(2,.025,.35),new THREE.MeshBasicMaterial({color:0xf5f0d8}));mark.position.set(x+i*6,.06,z+28);scene.add(mark)}
 }else if(type===16){
  // Waterfront promenade with blue water, sand, palms and boardwalk.
  const water=new THREE.Mesh(new THREE.PlaneGeometry(64,52),new THREE.MeshStandardMaterial({color:0x329eb5,metalness:.25,roughness:.28}));water.rotation.x=-Math.PI/2;water.position.set(x,.025,z+10);scene.add(water);
  const sand=new THREE.Mesh(new THREE.PlaneGeometry(64,13),new THREE.MeshStandardMaterial({color:0xd8c28c,roughness:1}));sand.rotation.x=-Math.PI/2;sand.position.set(x,.03,z-22);scene.add(sand);
  addCityBuilding(x,z-34,42,8,4,0xf0e4cc);
  for(let i=-2;i<=2;i++){const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.22,.32,4,7),new THREE.MeshStandardMaterial({color:0x795337}));trunk.position.set(x+i*11,2,z-24);scene.add(trunk);const leaves=new THREE.Mesh(new THREE.ConeGeometry(2.2,4,7),new THREE.MeshStandardMaterial({color:0x32804a}));leaves.position.set(x+i*11,5.2,z-24);scene.add(leaves)}
 }else if(type===17){
  // Industrial district with warehouses, loading bays and tanks.
  for(let i=-1;i<=1;i++){addCityBuilding(x+i*18,z,16,35,10+(i===0?3:0),i===0?0x8c9b9e:0xb5b8b0);const door=new THREE.Mesh(new THREE.BoxGeometry(7,5,.25),new THREE.MeshStandardMaterial({color:0x3e4c53}));door.position.set(x+i*18,2.5,z-17.7);scene.add(door)}
  for(let i=0;i<2;i++){const tank=new THREE.Mesh(new THREE.CylinderGeometry(4,4,8,16),new THREE.MeshStandardMaterial({color:0x9aa9a9,metalness:.35,roughness:.48}));tank.position.set(x+28,4,z+i*12);scene.add(tank)}
 }else if(type===18){
  // Upscale residential district with villas and landscaped gardens.
  for(let i=-1;i<=1;i++){const villa=new THREE.Mesh(new THREE.BoxGeometry(12,5,10),new THREE.MeshStandardMaterial({color:[0xe9dfcb,0xd9e5e3,0xe4d5c5][i+1],roughness:.8}));villa.position.set(x+i*17,2.5,z);scene.add(villa);const roof=new THREE.Mesh(new THREE.ConeGeometry(9,4,4),new THREE.MeshStandardMaterial({color:0x47565b,roughness:.8}));roof.position.set(x+i*17,7,z);roof.rotation.y=Math.PI/4;scene.add(roof);const garden=new THREE.Mesh(new THREE.PlaneGeometry(12,8),new THREE.MeshStandardMaterial({color:0x5b8b4b,map:parkGrassTexture,roughness:1}));garden.rotation.x=-Math.PI/2;garden.position.set(x+i*17,.04,z+9);scene.add(garden)}
 }else if(type===19){
  // Downtown business towers with a lit plaza.
  addCityBuilding(x-11,z,18,22,34,0x82969e);addCityBuilding(x+12,z+4,20,20,27,0xabb8bb);
  const plaza=new THREE.Mesh(new THREE.PlaneGeometry(42,34),new THREE.MeshStandardMaterial({color:0x9ba6a5,map:sidewalkTexture,roughness:.8}));plaza.rotation.x=-Math.PI/2;plaza.position.set(x,.035,z+23);scene.add(plaza);
  for(let i=-2;i<=2;i++){const light=new THREE.Mesh(new THREE.SphereGeometry(.5,8,6),new THREE.MeshBasicMaterial({color:0x75e8ff}));light.position.set(x+i*6,3,z+20);scene.add(light)}
 }else{
  addCityBuilding(x,z,42,29,19,0x943f43);
  const marquee=new THREE.Mesh(new THREE.BoxGeometry(22,3,.8),new THREE.MeshStandardMaterial({color:0xf1cf86,emissive:0x523410,roughness:.5}));marquee.position.set(x,10,z-15);scene.add(marquee);
  const awning=new THREE.Mesh(new THREE.BoxGeometry(32,.55,6),new THREE.MeshStandardMaterial({color:0xb55245,roughness:.7}));awning.position.set(x,6,z-20);scene.add(awning);
 }
}
function createCustomLosSantosDistricts(){
 // Mapa original inspirado no clima de uma cidade costeira da Califórnia,
 // sem copiar o mapa ou os assets proprietários de GTA.
 const districts=[
  {name:"OCEAN BEACH",x:-520,z:-500,color:0xff69bd},
  {name:"VICE CITY DOWNTOWN",x:0,z:-120,color:0x6bdcff},
  {name:"LITTLE HAVANA",x:180,z:430,color:0xff8b72},
  {name:"VICE BEACH",x:-590,z:520,color:0x6de6d0},
  {name:"VICE PORT",x:570,z:530,color:0xffad72},
  {name:"STARFISH ISLAND",x:420,z:-420,color:0xd7a5ff}
 ];
 for(const d of districts){
  const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#101b26';ctx.fillRect(0,0,512,128);
  ctx.fillStyle='#24c3b4';ctx.fillRect(0,0,10,128);ctx.fillStyle='#f3f5f7';ctx.font='bold 34px Arial';ctx.textBaseline='middle';ctx.fillText(d.name,28,52,465);
  ctx.fillStyle='#9bb3c2';ctx.font='18px Arial';ctx.fillText('VICE CITY • DISTRICT',28,94,465);
  const tex=new THREE.CanvasTexture(canvas);tex.encoding=THREE.sRGBEncoding;
  const mat=new THREE.MeshBasicMaterial({map:tex,transparent:true,side:THREE.DoubleSide});
  const sign=new THREE.Mesh(new THREE.PlaneGeometry(34,8),mat);sign.position.set(d.x,9,d.z);sign.rotation.y=(d.x>0?Math.PI:0);scene.add(sign);
  const glow=new THREE.PointLight(d.color,.55,45);glow.position.set(d.x,7,d.z);scene.add(glow);
 }
 // Faixas largas dão identidade de boulevard e ajudam a orientar a navegação.
 const boulevardMat=new THREE.MeshStandardMaterial({color:0x343b42,roughness:1});
 for(const z of [-600,-300,0,300,600]){const road=new THREE.Mesh(new THREE.PlaneGeometry(1500,17),boulevardMat);road.rotation.x=-Math.PI/2;road.position.set(0,.018,z);scene.add(road)}
 for(const x of [-600,-300,0,300,600]){const road=new THREE.Mesh(new THREE.PlaneGeometry(17,1500),boulevardMat);road.rotation.x=-Math.PI/2;road.position.set(x,.019,0);scene.add(road)}
}
function setVehicleSpeedPreset(preset){
 vehicleSpeedLimit=VEHICLE_SPEED_PRESETS[preset]||VEHICLE_SPEED_PRESETS.medium;
 document.querySelectorAll('[data-car-speed]').forEach(btn=>{const active=btn.dataset.carSpeed===preset;btn.style.outline=active?'2px solid #fff':'none';btn.setAttribute('aria-pressed',active?'true':'false')});
 const label=document.getElementById('car-speed-status');if(label)label.textContent=vehicleSpeedLimit+' m/s';
}
window.setVehicleSpeedPreset=setVehicleSpeedPreset;

function createBuildings(){
 const venueNames=["Parque das Palmeiras","Mercado Municipal","Hospital São Miguel","Estação das Artes","Biblioteca Central","Arena Horizonte","Museu da Cidade","Galeria Alameda","Praça das Fontes","Campus Universitário","Quartel dos Bombeiros","Jardim Botânico","Heliporto Metropolitano","Aquário Atlântico","Teatro Municipal","Aeroporto Alta Vista","Orla do Sol","Distrito Industrial","Vilas do Mirante","Centro Financeiro"];
 const districts=["do Centro","das Acácias","de Santa Marina","da Aurora","do Porto","das Flores","do Vale Verde","da Esperança","do Lago Norte","da Serra Azul","do Mirante","da Estação","das Colinas","do Horizonte","da Enseada"];
 for(let row=0;row<15;row++)for(let col=0;col<15;col++){
  const x=-700+col*100,z=-700+row*100,type=(col*7+row*11)%20;
  const location={x,z,type,title:venueNames[type],district:districts[row],name:venueNames[type]+" "+districts[row],skin:(row*7+col*11)%facadeTextures.length};
  cityLocations.push(location);
  activeFacadeIndex=location.skin;
  addVenueDetails(location);
  addLocationSign(location);
 }
}


// Vegetation, landscaped medians, and small open spaces break up the rigid block pattern.
function createNaturalDistricts(){
 const trunkMat=new THREE.MeshStandardMaterial({color:0x62432d,roughness:1});
 const leafMats=[0x39734a,0x4f8548,0x658e4b,0x2f6747].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
 const shrubMat=new THREE.MeshStandardMaterial({color:0x4b7544,roughness:1});
 function tree(x,z,scale=1){
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.16*scale,.25*scale,1.9*scale,7),trunkMat);trunk.position.set(x,.95*scale,z);scene.add(trunk);
  const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.15*scale,1),leafMats[Math.floor(Math.random()*leafMats.length)]);crown.position.set(x,2.35*scale,z);crown.rotation.y=Math.random()*Math.PI;scene.add(crown);
  if(Math.random()<.35){const crown2=new THREE.Mesh(new THREE.IcosahedronGeometry(.72*scale,1),leafMats[Math.floor(Math.random()*leafMats.length)]);crown2.position.set(x+.45*scale,2.55*scale,z+.15*scale);scene.add(crown2)}
 }
 // Green courtyards and irregular tree clusters inside selected blocks.
 for(let row=0;row<15;row++)for(let col=0;col<15;col++){
  const cx=-650+col*100,cz=-650+row*100,seed=(row*17+col*13)%11;
  if(seed===0||seed===3||seed===7){
   const w=seed===3?35:22+Math.random()*15,d=seed===3?42:22+Math.random()*15;
   const patch=new THREE.Mesh(new THREE.PlaneGeometry(w,d),new THREE.MeshStandardMaterial({color:0x668753,map:parkGrassTexture,roughness:1}));patch.rotation.x=-Math.PI/2;patch.position.set(cx+(Math.random()-.5)*18,.018,cz+(Math.random()-.5)*18);scene.add(patch);
   const count=seed===3?9:5;
   for(let i=0;i<count;i++)tree(cx+(Math.random()-.5)*(w-5),cz+(Math.random()-.5)*(d-5),.72+Math.random()*.55);
   for(let i=0;i<4;i++){const shrub=new THREE.Mesh(new THREE.IcosahedronGeometry(.55+Math.random()*.4,0),shrubMat);shrub.position.set(cx+(Math.random()-.5)*w,.45,cz+(Math.random()-.5)*d);scene.add(shrub)}
  }
 }
 // Low, landscaped roundabouts at selected junctions add variety to intersections.
 for(let i=0;i<15;i++){
  const x=-600+i*85,z=(i%2?1:-1)*(120+(i%4)*95);
  if(Math.abs(z)>650)continue;
  const island=new THREE.Mesh(new THREE.CircleGeometry(5.8,20),new THREE.MeshStandardMaterial({color:0x567b43,roughness:1}));island.rotation.x=-Math.PI/2;island.position.set(x,.07,z);scene.add(island);
  tree(x,z,.8);
 }
}

// Extra street furniture and public-space details make the city feel inhabited.
function createStreetLife(){
 const poleMat=new THREE.MeshStandardMaterial({color:0x39434a,metalness:.62,roughness:.42});
 const lampMat=new THREE.MeshStandardMaterial({color:0xffe4a0,emissive:0xffbd55,emissiveIntensity:.65,roughness:.3});
 const stripeMat=new THREE.MeshBasicMaterial({color:0xf2eee0});
 const benchWood=new THREE.MeshStandardMaterial({color:0x805735,roughness:.9});
 const benchMetal=new THREE.MeshStandardMaterial({color:0x303b42,metalness:.45,roughness:.6});
 const binMat=new THREE.MeshStandardMaterial({color:0x287d78,roughness:.75});
 const planterMat=new THREE.MeshStandardMaterial({color:0x9a9b92,roughness:.95});
 const flowerMats=[0xf5c64b,0xf18a9b,0xe9e7d5].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
 const dummy=new THREE.Object3D(),stripesX=[],stripesZ=[];
 // Batched crosswalk paint at intersections; low overhead on mobile.
 for(let street=-600;street<=600;street+=100)for(let along=-600;along<=600;along+=100){
  for(const side of [-1,1])for(let n=0;n<5;n++){const o=side*(8.8+n*0.72);stripesX.push([street+o,along]);stripesZ.push([street,along+o]);}
 }
 const crossX=new THREE.InstancedMesh(new THREE.BoxGeometry(.72,.035,5.8),stripeMat,stripesX.length);
 stripesX.forEach(([x,z],i)=>{dummy.position.set(x,.075,z);dummy.updateMatrix();crossX.setMatrixAt(i,dummy.matrix)});scene.add(crossX);
 const crossZ=new THREE.InstancedMesh(new THREE.BoxGeometry(5.8,.035,.72),stripeMat,stripesZ.length);
 stripesZ.forEach(([x,z],i)=>{dummy.position.set(x,.078,z);dummy.updateMatrix();crossZ.setMatrixAt(i,dummy.matrix)});scene.add(crossZ);
 // Street lamps in batches instead of hundreds of separate draw calls.
 const lampPositions=[];
 for(let street=-600;street<=600;street+=100)for(let along=-650;along<=650;along+=100){if(Math.abs(along%200)===0)continue;lampPositions.push([street+10.8,along],[street-10.8,along]);}
 const poles=new THREE.InstancedMesh(new THREE.CylinderGeometry(.09,.14,5.2,7),poleMat,lampPositions.length);
 const heads=new THREE.InstancedMesh(new THREE.SphereGeometry(.25,7,5),lampMat,lampPositions.length);
 lampPositions.forEach(([x,z],i)=>{dummy.position.set(x,2.6,z);dummy.updateMatrix();poles.setMatrixAt(i,dummy.matrix);dummy.position.set(x,5.15,z);dummy.updateMatrix();heads.setMatrixAt(i,dummy.matrix)});scene.add(poles,heads);
 // Street furniture is placed on sidewalks, never at arbitrary coordinates
 // in the middle of roads or inside buildings.
 const sidewalkSpots=[];
 for(let street=-600;street<=600;street+=100){
   for(let along=-560;along<=560;along+=80){
     if(Math.abs(along%100)<18) continue;
     sidewalkSpots.push([street+12.2,along,Math.PI/2],[street-12.2,along,-Math.PI/2]);
     sidewalkSpots.push([along,street+12.2,0],[along,street-12.2,Math.PI]);
   }
 }
 let placed=0;
 for(const [x,z,rot] of sidewalkSpots){
   if(placed>=90) break;
   if(buildingColliders.some(b=>Math.abs(x-b.x)<b.halfX+2.8 && Math.abs(z-b.z)<b.halfZ+2.8)) continue;
   if(Math.abs(x%100)<9.5 || Math.abs(z%100)<9.5) continue;
   const bench=new THREE.Group(),seat=new THREE.Mesh(new THREE.BoxGeometry(2.15,.14,.62),benchWood);
   seat.position.y=.68;bench.add(seat);
   for(const dx of [-.82,.82]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.12,.65,.48),benchMetal);leg.position.set(dx,.34,0);bench.add(leg)}
   const back=new THREE.Mesh(new THREE.BoxGeometry(2.15,.72,.12),benchWood);back.position.set(0,1.08,.25);back.rotation.x=-.12;bench.add(back);
   bench.position.set(x,.03,z);bench.rotation.y=rot;scene.add(bench);
   if(placed%2===0){const bin=new THREE.Mesh(new THREE.CylinderGeometry(.28,.32,.72,8),binMat);bin.position.set(x+Math.cos(rot)*1.8,.39,z-Math.sin(rot)*1.8);scene.add(bin)}
   if(placed%3===0){const planter=new THREE.Mesh(new THREE.BoxGeometry(2.4,.38,1.25),planterMat);planter.position.set(x-Math.sin(rot)*2,.2,z-Math.cos(rot)*2);planter.rotation.y=rot;scene.add(planter);
     for(let f=0;f<5;f++){const flower=new THREE.Mesh(new THREE.SphereGeometry(.18,6,5),flowerMats[(placed+f)%flowerMats.length]);flower.position.set(planter.position.x-1+f*.38,.55,planter.position.z);scene.add(flower)}}
   placed++;
 }
 // Bus shelters sit parallel to sidewalks and avoid building footprints.
 for(let i=0;i<12;i++){
   const street=-500+(i%6)*200,along=i<6?-480:480;
   const candidates=[[street+12.2,along,Math.PI/2],[street-12.2,along,-Math.PI/2],[along,street+12.2,0],[along,street-12.2,Math.PI]];
   let chosen=candidates[i%4];
   if(buildingColliders.some(b=>Math.abs(chosen[0]-b.x)<b.halfX+4 && Math.abs(chosen[1]-b.z)<b.halfZ+3)) continue;
   const [x,z,rot]=chosen,shelter=new THREE.Group();
   const frame=new THREE.MeshStandardMaterial({color:0x354b55,metalness:.4,roughness:.5});
   const glass=new THREE.MeshStandardMaterial({color:0x74cbd8,transparent:true,opacity:.28,metalness:.15,roughness:.2,side:THREE.DoubleSide});
   for(const dx of [-2,2])for(const dz of [-.8,.8]){const post=new THREE.Mesh(new THREE.BoxGeometry(.12,2.7,.12),frame);post.position.set(dx,1.35,dz);shelter.add(post)}
   const roof=new THREE.Mesh(new THREE.BoxGeometry(4.4,.16,2),frame);roof.position.y=2.75;shelter.add(roof);
   const pane=new THREE.Mesh(new THREE.BoxGeometry(3.8,1.75,.045),glass);pane.position.set(0,1.65,-.78);shelter.add(pane);
   const seat=new THREE.Mesh(new THREE.BoxGeometry(2.6,.12,.42),benchWood);seat.position.set(0,.62,.28);shelter.add(seat);
   const sign=new THREE.Mesh(new THREE.BoxGeometry(.72,1.2,.12),new THREE.MeshStandardMaterial({color:0x12a9b5,emissive:0x063e48,roughness:.55}));sign.position.set(2.15,1.85,0);shelter.add(sign);
   shelter.position.set(x,.03,z);shelter.rotation.y=rot;scene.add(shelter);
 }
 // Direction arrows add visual cues to selected junctions.
 const arrowMat=new THREE.MeshBasicMaterial({color:0xe6e1c9});
 for(let street=-500;street<=500;street+=200)for(let along=-500;along<=500;along+=200){const arrow=new THREE.Mesh(new THREE.ConeGeometry(.62,1.5,3),arrowMat);arrow.rotation.x=-Math.PI/2;arrow.rotation.z=Math.PI;arrow.position.set(street+3,.07,along+5);scene.add(arrow)}
}

function addParkingLots(){
 const lineMat=new THREE.MeshBasicMaterial({color:0xf1e6ad});
 const kinds=['sedan','luxury','compact','suv','pickup','van','taxi','sports','muscle'];
 for(let street=-600;street<=600;street+=200){
  for(let along=-600;along<=600;along+=200){
   const x=street+19,z=along+27;
   if(!isClearParkingArea(x,z))continue;
   for(let slot=0;slot<3;slot++){
    const zz=z+slot*5.4;
    for(const side of [-1,1]){
     const mark=new THREE.Mesh(new THREE.BoxGeometry(.07,.025,4.5),lineMat);mark.position.set(x+side*1.25,.06,zz);scene.add(mark);
    }
    if(Math.random()<.32){
     const kind=kinds[Math.floor(Math.random()*kinds.length)];
     const car=createDetailedParkedCar(kind);
     car.scale.setScalar(.82+Math.random()*.10);
     car.position.set(x,0,zz);car.rotation.y=Math.PI;scene.add(car);parkedVehicles.push(car);
    }
   }
  }
 }
}
function isClearParkingArea(x,z){
 return buildingColliders.every(b=>!(Math.abs(x-b.x)<b.halfX+4 && Math.abs(z-b.z)<b.halfZ+8));
}

// Vagas especiais com três carros reconhecíveis. O BMW usa um modelo GLB real;
// Mercedes e Uno usam malhas locais detalhadas para funcionar mesmo offline.
function createDetailedParkedCar(kind){
 const g=new THREE.Group();
 const configs={
  bmw:{w:1.88,l:4.05,h:.70,roof:.10,cabin:1.78,color:0x2479b8,style:'sedan'},
  mercedes:{w:1.90,l:4.10,h:.72,roof:.10,cabin:1.82,color:0x20252c,style:'luxury'},
  luxury:{w:1.90,l:4.10,h:.72,roof:.10,cabin:1.82,color:0x20252c,style:'luxury'},
  uno:{w:1.66,l:3.45,h:.68,roof:.16,cabin:1.48,color:0x176b42,style:'compact'},
  sedan:{w:1.82,l:4.0,h:.69,roof:.11,cabin:1.78,color:0x596a7a,style:'sedan'},
  suv:{w:2.02,l:4.45,h:.88,roof:.12,cabin:2.15,color:0x6d725f,style:'suv'},
  pickup:{w:1.98,l:4.8,h:.70,roof:.10,cabin:1.55,color:0x8b3f32,style:'pickup'},
  van:{w:2.0,l:4.35,h:.98,roof:.12,cabin:2.45,color:0xc8cbd0,style:'van'},
  taxi:{w:1.84,l:4.05,h:.70,roof:.10,cabin:1.8,color:0xf2c526,style:'taxi'},
  police:{w:1.88,l:4.1,h:.72,roof:.10,cabin:1.8,color:0xf0f0e9,style:'police'},
  sports:{w:1.92,l:4.25,h:.56,roof:.08,cabin:1.48,color:0xe33b36,style:'sports'},
  muscle:{w:1.98,l:4.55,h:.68,roof:.10,cabin:1.55,color:0x3954a3,style:'muscle'},
  ambulance:{w:2.02,l:4.55,h:1.0,roof:.10,cabin:2.25,color:0xf4f1e9,style:'ambulance'},
  truck:{w:2.15,l:5.7,h:.78,roof:.12,cabin:1.65,color:0x477b55,style:'truck'}
 };
 const cfg=configs[kind]||configs.sedan;
 const paintColor=(['taxi','police','ambulance'].includes(kind))?cfg.color:[0x2479b8,0xb73c3c,0x2e7952,0xddd4c0,0x333941,0xd18b2c,0x8b65a6,0x5d7b88,0xe0e0df,0x171b20][Math.floor(Math.random()*10)];
 const paint=new THREE.MeshStandardMaterial({color:paintColor,roughness:.32,metalness:.42});
 const darkPaint=new THREE.MeshStandardMaterial({color:paintColor,roughness:.4,metalness:.25});
 const glass=new THREE.MeshStandardMaterial({color:0x172c3a,roughness:.2,metalness:.18});
 const black=new THREE.MeshStandardMaterial({color:0x141619,roughness:.84});
 const chrome=new THREE.MeshStandardMaterial({color:0xc4cbd0,metalness:.72,roughness:.3});
 const lamp=new THREE.MeshStandardMaterial({color:0xfff1c4,emissive:0x504322,roughness:.35});
 const tail=new THREE.MeshStandardMaterial({color:0xc91f2c,emissive:0x330609,roughness:.35});
 const body=new THREE.Mesh(new THREE.BoxGeometry(cfg.w,cfg.h,cfg.l),paint);body.position.y=cfg.style==='truck'?.72:.62;g.add(body);
 const hood=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.94,.15,cfg.l*(cfg.style==='van'?.22:.29)),paint);hood.position.set(0,cfg.style==='truck'?.99:.94,-cfg.l*.32);g.add(hood);
 const cabinH=cfg.style==='sports'?.43:(cfg.style==='van'||cfg.style==='ambulance'||cfg.style==='truck'? .83:(kind==='uno'?.60:.53));
 const cabin=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.78,cabinH,cfg.cabin),glass);cabin.position.set(0,1.14,cfg.style==='compact'?.10:.05);g.add(cabin);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.72,cfg.roof,cfg.cabin*.7),paint);roof.position.set(0,1.14+cabinH/2+.04,cfg.style==='compact'?.12:.04);g.add(roof);
 const grille=new THREE.Mesh(new THREE.BoxGeometry(cfg.style==='compact'?.58:.72,.17,.05),kind==='uno'?black:chrome);grille.position.set(0,.78,-cfg.l/2-.025);g.add(grille);
 for(const x of [-cfg.w*.34,cfg.w*.34]){
  const head=new THREE.Mesh(new THREE.BoxGeometry(cfg.style==='sports'?.28:.25,.13,.055),lamp);head.position.set(x,.82,-cfg.l/2-.03);g.add(head);
  const rear=new THREE.Mesh(new THREE.BoxGeometry(.20,.14,.055),tail);rear.position.set(x,.79,cfg.l/2+.025);g.add(rear);
 }
 const wheelRadius=cfg.style==='compact'?.26:(cfg.style==='truck'?.38:.30);
 const wheelGeo=new THREE.CylinderGeometry(wheelRadius,wheelRadius,.19,14);
 const rimGeo=new THREE.CylinderGeometry(wheelRadius*.52,wheelRadius*.52,.205,12);const driveWheels=[];
 const rimDark=new THREE.MeshStandardMaterial({color:0x343b42,metalness:.65,roughness:.34});
 for(const x of [-cfg.w*.49,cfg.w*.49])for(const z of [-cfg.l*.31,cfg.l*.31]){
  const wheel=new THREE.Mesh(wheelGeo,black);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.36,z);wheel.userData.isDriveWheel=true;g.add(wheel);driveWheels.push(wheel);
  const rim=new THREE.Mesh(rimGeo,chrome);rim.rotation.z=Math.PI/2;rim.position.set(x*1.015,.36,z);g.add(rim);
  const hub=new THREE.Mesh(new THREE.CylinderGeometry(.055,.055,.214,10),rimDark);hub.rotation.z=Math.PI/2;hub.position.set(x*1.02,.36,z);g.add(hub);
  // Molduras de paralama deixam as rodas integradas à carroceria.
  const arch=new THREE.Mesh(new THREE.TorusGeometry(wheelRadius+.035,.045,5,14,Math.PI),darkPaint);
  arch.rotation.set(0,Math.PI/2,Math.PI);arch.position.set(x*.985,.37,z);g.add(arch);
 }
 // Vidros laterais, pilares, retrovisores e linhas de portas para quebrar o aspecto de bloco.
 const sideGlass=new THREE.MeshStandardMaterial({color:0x253d4b,roughness:.24,metalness:.15});
 for(const side of [-1,1]){
  const mirrorStem=new THREE.Mesh(new THREE.BoxGeometry(.08,.07,.16),black);mirrorStem.position.set(side*cfg.w*.49,1.08,-.58);g.add(mirrorStem);
  const mirror=new THREE.Mesh(new THREE.BoxGeometry(.14,.12,.18),paint);mirror.position.set(side*cfg.w*.54,1.13,-.60);g.add(mirror);
  const frontSide=new THREE.Mesh(new THREE.PlaneGeometry(cfg.style==='compact'?.48:.58,.30),sideGlass);frontSide.rotation.y=side*Math.PI/2;frontSide.position.set(side*cfg.w*.395,1.28,-.35);g.add(frontSide);
  const rearSide=new THREE.Mesh(new THREE.PlaneGeometry(cfg.style==='van'?.75:.48,.30),sideGlass);rearSide.rotation.y=side*Math.PI/2;rearSide.position.set(side*cfg.w*.395,1.28,.43);g.add(rearSide);
  for(const z of [-.18,.42]){
   const seam=new THREE.Mesh(new THREE.BoxGeometry(.018,.34,.018),black);seam.position.set(side*cfg.w*.501,.72,z);g.add(seam);
   const handle=new THREE.Mesh(new THREE.BoxGeometry(.025,.045,.15),chrome);handle.position.set(side*cfg.w*.512,.82,z+.08);g.add(handle);
  }
  const sill=new THREE.Mesh(new THREE.BoxGeometry(.045,.09,cfg.l*.53),black);sill.position.set(side*cfg.w*.49,.43,0);g.add(sill);
 }
 const windshield=new THREE.Mesh(new THREE.PlaneGeometry(cfg.w*.67,cabinH*.56),sideGlass);
 windshield.position.set(0,1.30,-cfg.l*.30);windshield.rotation.x=-.12;g.add(windshield);
 const rearWindow=new THREE.Mesh(new THREE.PlaneGeometry(cfg.w*.64,cabinH*.45),sideGlass);
 rearWindow.position.set(0,1.29,cfg.l*.29);rearWindow.rotation.y=Math.PI;g.add(rearWindow);
 // Silhuetas próprias para distinguir categorias à distância.
 if(cfg.style==='pickup'){
  const bed=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.78,.28,cfg.l*.30),darkPaint);bed.position.set(0,.94,cfg.l*.30);g.add(bed);
  for(const x of [-cfg.w*.39,cfg.w*.39]){const rail=new THREE.Mesh(new THREE.BoxGeometry(.07,.35,cfg.l*.31),paint);rail.position.set(x,.99,cfg.l*.30);g.add(rail)}
 }
 if(cfg.style==='sports'||cfg.style==='muscle'){
  const spoiler=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.72,.08,.18),darkPaint);spoiler.position.set(0,1.04,cfg.l*.48);g.add(spoiler);
  for(const x of [-.42,.42]){const support=new THREE.Mesh(new THREE.BoxGeometry(.06,.18,.06),black);support.position.set(x,.96,cfg.l*.46);g.add(support)}
 }
 if(cfg.style==='taxi'){
  const sign=new THREE.Mesh(new THREE.BoxGeometry(.48,.16,.22),new THREE.MeshStandardMaterial({color:0xffdf37,emissive:0x403000}));sign.position.set(0,1.58,0);g.add(sign);
 }
 if(cfg.style==='police'){
  const bar=new THREE.Mesh(new THREE.BoxGeometry(.66,.13,.22),black);bar.position.set(0,1.57,0);g.add(bar);
  const red=new THREE.Mesh(new THREE.BoxGeometry(.25,.12,.18),new THREE.MeshStandardMaterial({color:0xff3030,emissive:0x8c0000}));red.position.set(-.17,1.66,0);g.add(red);
  const blue=new THREE.Mesh(new THREE.BoxGeometry(.25,.12,.18),new THREE.MeshStandardMaterial({color:0x328cff,emissive:0x002d8c}));blue.position.set(.17,1.66,0);g.add(blue);
 }
 if(cfg.style==='ambulance'){
  const stripe=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*1.01,.16,cfg.l*.66),new THREE.MeshStandardMaterial({color:0xd92832}));stripe.position.set(0,.78,.06);g.add(stripe);
  const crossV=new THREE.Mesh(new THREE.BoxGeometry(.18,.46,.06),new THREE.MeshBasicMaterial({color:0xd92832}));crossV.position.set(0,1.48,-cfg.l*.30);g.add(crossV);
  const crossH=new THREE.Mesh(new THREE.BoxGeometry(.48,.16,.06),new THREE.MeshBasicMaterial({color:0xd92832}));crossH.position.set(0,1.48,-cfg.l*.30);g.add(crossH);
 }
 if(cfg.style==='truck'){
  const cargo=new THREE.Mesh(new THREE.BoxGeometry(cfg.w*.94,1.2,cfg.l*.42),new THREE.MeshStandardMaterial({color:0xb6b8b4,roughness:.75}));cargo.position.set(0,1.55,cfg.l*.27);g.add(cargo);
 }
 g.userData.brandCar=kind;g.userData.driveBody=null;g.userData.driveWheels=driveWheels;g.userData.isPersonalVehicle=false;g.userData.displayName=({bmw:'Sedã esportivo',mercedes:'Sedã de luxo',luxury:'Sedã de luxo',uno:'Compacto',sedan:'Sedã',suv:'SUV',pickup:'Picape',van:'Van',taxi:'Táxi',police:'Viatura',sports:'Esportivo',muscle:'Muscle car',ambulance:'Ambulância',truck:'Caminhão'})[kind]||'Carro';
 return g;
}
function addBrandCarsToParking(){ /* A frota é montada com silhuetas procedurais originais. */ }

// Spawn seguro: evita iniciar dentro das caixas de colisão dos prédios.
function isClearSpawn(x,z,radius){
 for(const b of buildingColliders){
  if(Math.abs(x-b.x)<b.halfX+radius && Math.abs(z-b.z)<b.halfZ+radius) return false;
 }
 return true;
}
function findClearSpawn(radius,avoidPosition=null){
 for(let ring=0;ring<=60;ring++){
  const d=ring*12.5;
  const candidates=ring===0?[[12.5,25]]:[[d,25],[-d,25],[25,d],[25,-d],[d,-25],[-d,-25],[-25,d],[-25,-d],[d,d],[-d,d],[d,-d],[-d,-d]];
  for(const [x,z] of candidates){
   if(Math.abs(x)<CITY_LIMIT-10 && Math.abs(z)<CITY_LIMIT-10 && isClearSpawn(x,z,radius) && (!avoidPosition || Math.hypot(x-avoidPosition.x,z-avoidPosition.z)>8)) return new THREE.Vector3(x,0,z);
  }
 }
 return new THREE.Vector3(50,0,50);
}
function relocateSpawnPoints(){
 if(player) player.position.copy(findClearSpawn(.8));
 if(vehicle){vehicle.position.copy(findClearSpawn(2.8,player?player.position:null));vehicle.rotation.set(0,0,0);carVelocity.set(0,0,0);}
}

function createPedestrians(n){
 const mat=new THREE.MeshStandardMaterial({color:0xffaa66});
 for(let i=0;i<n;i++){
  // Cada 18º pedestre é a NPC especial inspirada na Hatsune Miku.
  const isMiku=(i===0 || i%18===0);
  const p=isMiku?createMikuNPC():new THREE.Group();
  if(!isMiku){
   const shirts=[0xffaa66,0x5b84c4,0xc95d53,0x6e9a68,0x8c6ab4,0xd1b66b,0x343a46,0xe0ded7];
   const pants=[0x26354a,0x34383e,0x4a3a2e,0x263b35,0x454b63];
   const skin=[0xe3ad82,0xc98d68,0xf0c5a1,0x9c684d];
   const human=createCharacterGroup({shirt:shirts[i%shirts.length],pants:pants[i%pants.length],skin:skin[i%skin.length]});
   p.add(human);p.userData.humanModel=human;
  }
  const street=(Math.floor(Math.random()*16)-7.5)*100,along=(Math.random()-.5)*1460,side=Math.random()<.5?-1:1;
  if(Math.random()<.5)p.position.set(street+side*12.5,0,along);else p.position.set(along,0,street+side*12.5);
  p.userData={...p.userData,isRagdoll:false,health:100,patrolAngle:Math.random()*Math.PI*2,character:!!p.userData.character};
  scene.add(p);pedestrians.push(p);
 }
}

/* ---------- CONTROLS ---------- */
function setupCameraDrag(){
 let dragging=false,lastX=0,lastY=0;
 const canvas=renderer.domElement;
 canvas.style.touchAction='none';
 canvas.addEventListener('pointerdown',e=>{
  if(e.target!==canvas)return;
  dragging=true;lastX=e.clientX;lastY=e.clientY;
  if(canvas.setPointerCapture) canvas.setPointerCapture(e.pointerId);
 });
 canvas.addEventListener('pointermove',e=>{
  if(!dragging)return;
  const dx=e.clientX-lastX,dy=e.clientY-lastY;
  lastX=e.clientX;lastY=e.clientY;
  cameraAngleY-=dx*.0048;
  cameraPitch=clamp(cameraPitch+dy*.0025,-0.10,0.72);
 });
 const stop=()=>{dragging=false};
 canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',stop);
}

function setupControls(){
 const key=(e,v)=>{
  if(e.target&&["INPUT","TEXTAREA"].includes(e.target.tagName))return;
  const k=e.key.toLowerCase();
  if(k==="w"||k==="arrowup")keys.forward=v;
  if(k==="s"||k==="arrowdown")keys.backward=v;
  if(k==="a"||k==="arrowleft")keys.left=v;
  if(k==="d"||k==="arrowright")keys.right=v;
  if(k==="e"&&v)toggleVehicle();
  if(k==="r"&&v)reloadWeapon();
  if(k==="j"&&v)jumpPlayer();
  if(k==="c"&&v)toggleCameraMode();
  if((k==="p"||k==="escape")&&v)togglePauseGame();
  if((k==="q"||k==="tab")&&v){e.preventDefault();cycleWeaponArsenal()}
  if(k===" "&&v)shootWeapon();
 };
 addEventListener("keydown",e=>key(e,true));
 addEventListener("keyup",e=>key(e,false));


 $("btn-enter").onclick=toggleVehicle;
 if($("btn-refuel"))$("btn-refuel").onclick=refuelVehicle;
 if($("btn-repair"))$("btn-repair").onclick=repairAtGarage;
 if($("btn-aim"))$("btn-aim").onclick=toggleAimMode;
 $("btn-shoot").onclick=shootWeapon;
 if($("btn-reload"))$("btn-reload").onclick=reloadWeapon;
 if($("btn-jump"))$("btn-jump").onclick=jumpPlayer;
 $("btn-camera").onclick=toggleCameraMode;
 // O rádio é conectado em initAudioSystem().
 $("btn-pause").onclick=togglePauseGame;
 setupJoystick();
}

function bindHold(id,getter,setter){
 const el=$(id);
 const on=e=>{e.preventDefault();setter(true)};
 const off=e=>{e.preventDefault();setter(false)};
 ["pointerdown"].forEach(x=>el.addEventListener(x,on));
 ["pointerup","pointercancel","pointerleave"].forEach(x=>el.addEventListener(x,off));
}

function setupJoystick(){
 const base=$("joystick"),stick=$("stick");
 let active=false;
 const move=e=>{
  if(!active)return;
  const r=base.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  let dx=e.clientX-cx,dy=e.clientY-cy;
  const max=Math.min(r.width,r.height)*.34,len=Math.hypot(dx,dy)||1;
  if(len>max){dx=dx/len*max;dy=dy/len*max}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  const dead=Math.max(7,Math.min(r.width,r.height)*.065);
  // Movimento proporcional à inclinação do joystick, com zona morta para evitar deriva.
  const strength=Math.min(1,Math.hypot(dx,dy)/Math.max(1,max));
  keys.left=dx<-dead;keys.right=dx>dead;keys.forward=dy<-dead;keys.backward=dy>dead;
  base.dataset.strength=String(strength);
 };
 base.addEventListener("pointerdown",e=>{e.preventDefault();active=true;if(base.setPointerCapture)base.setPointerCapture(e.pointerId);move(e)});
 base.addEventListener("pointermove",e=>{if(active){e.preventDefault();move(e)}},{passive:false});
 const release=()=>{active=false;delete base.dataset.strength;stick.style.transform="";keys.left=keys.right=keys.forward=keys.backward=false};
 base.addEventListener("pointerup",release);base.addEventListener("pointercancel",release);base.addEventListener("lostpointercapture",release);
}

const gameMemes = [
 ['🚗 O motorista','Carteira de motorista? Foi comprada no GTA.'],
 ['💀 Eita','O plano era perfeito… até você apertar o botão errado.'],
 ['🚓 A polícia','A polícia viu isso e já está digitando seu endereço.'],
 ['🏍️ Motoca','Capacete é opcional? A física discorda.'],
 ['🚁 Piloto profissional','Aterrissagem suave: definição desconhecida.'],
 ['🛥️ Marinheiro','O Titanic também começou com confiança.'],
 ['💸 Economia','Você não está sem dinheiro. Está em modo desafio.'],
 ['🧠 200 de QI','A estratégia foi tão avançada que nem você entendeu.'],
 ['📱 Lag lendário','Não foi você que bateu. Foi o ping. Confia.'],
 ['🗿 Modo sigma','Zero preocupação, cem por cento problema.'],
 ['🍞 NPC','Esse NPC tem mais história que muito protagonista.'],
 ['🎮 Clássico','Se deu errado, chama de speedrun.']
];
let lastMemeIndex=-1;
function showRandomGameMeme(){
 let i=Math.floor(Math.random()*gameMemes.length);
 if(gameMemes.length>1&&i===lastMemeIndex)i=(i+1)%gameMemes.length;
 lastMemeIndex=i;
 const meme=gameMemes[i];
 showGameToast(meme[0],meme[1],'#ffca55');
}

function showGameToast(title,message,color='#b9ff6a'){
 const c=$('toast-container');if(!c)return;
 const t=document.createElement('div');t.className='toast';
 t.style.borderColor=color;t.innerHTML=`<b style="color:${color}">${title}</b><br><small>${message}</small>`;
 c.appendChild(t);setTimeout(()=>t.remove(),3200);
}
function activateDriveableVehicle(target){
 vehicle=target;
 carBody=target.userData.driveBody||null;
 wheelMeshes=target.userData.driveWheels||[];
 vehicleSpeedLimit=target.userData.maxSpeed||22;
 carVelocity.set(0,0,0);speed=0;steering=0;carDamage=0;fuel=100;vehicleDestroyed=false;damageStage=0;
}
function nearestVehicleToPlayer(){
 const candidates=[];if(vehicle)candidates.push(vehicle);
 for(const c of parkedVehicles)if(c&&c!==vehicle)candidates.push(c);
 for(const c of npcVehicles)if(c&&c!==vehicle)candidates.push(c);
 let best=null,bestD=6.2;
 for(const c of candidates){const d=player.position.distanceTo(c.position);if(d<bestD){best=c;bestD=d}}
 return best;
}
function toggleVehicle(){
 if(isAiming)toggleAimMode();
 if(inVehicle){
  inVehicle=false;player.visible=true;
  const forward=new THREE.Vector3(1,0,0).applyQuaternion(vehicle.quaternion);
  player.position.copy(vehicle.position).addScaledVector(forward,2.4);player.position.y=0;
  if(!parkedVehicles.includes(vehicle))parkedVehicles.push(vehicle);
  stopEngineSound();
  showGameToast('VEÍCULO','Você saiu do carro. Aproxime-se de outro e toque 🚗 para entrar.','#62f5ff');
  return;
 }
 const target=nearestVehicleToPlayer();
 if(!target){showGameToast('NENHUM CARRO PRÓXIMO','Chegue mais perto de um veículo.','#ffcc66');return}
 const wasPersonal=!!target.userData.isPersonalVehicle;
 const wasAlreadyStolen=!!target.userData.stolen;
 if(target!==vehicle){
  // O veículo que o jogador deixou continua no mundo e pode ser reutilizado.
  if(vehicle&&!parkedVehicles.includes(vehicle))parkedVehicles.push(vehicle);
  parkedVehicles=parkedVehicles.filter(c=>c!==target);
  npcVehicles=npcVehicles.filter(c=>c!==target);
  activateDriveableVehicle(target);
 }
 inVehicle=true;player.visible=false;startEngineSound();
 const name=target.userData.displayName||'veículo';
 if(!wasPersonal&&!wasAlreadyStolen){
  target.userData.stolen=true;addWanted(1);
  showGameToast('🚨 CARRO ROUBADO',`${name} ligado! A polícia pode começar a perseguir você.`,'#ff6b6b');
  playSoundEffect('horn');
 }else if(wasAlreadyStolen){showGameToast('VEÍCULO','Você voltou para um carro roubado. Fique atento à polícia.','#ffcc66')}
 else showGameToast('VEÍCULO','Você entrou no seu carro.','#b9ff6a');
}

/* ---------- PLAYER / VEHICLE ---------- */
function updateGame(dt){
 if(inVehicle) updateVehicle(dt);
 else updatePlayer(dt);
}

function updatePlayer(dt){
 const move=.085*dt*60;
 const input=new THREE.Vector3();
 if(keys.forward)input.z-=1;
 if(keys.backward)input.z+=1;
 if(keys.left)input.x-=1;
 if(keys.right)input.x+=1;
 if(input.lengthSq()){
  input.normalize();
  // Movement follows the camera's horizontal heading, so forward is always toward the view.
  const dir=input.applyAxisAngle(new THREE.Vector3(0,1,0),cameraAngleY);
  const previous=player.position.clone();
  player.position.addScaledVector(dir,move);
  // Avoid walking through building footprints.
  for(const obstacle of buildingColliders){
   if(Math.abs(player.position.x-obstacle.x)<obstacle.halfX+.28&&Math.abs(player.position.z-obstacle.z)<obstacle.halfZ+.28){player.position.x=previous.x;player.position.z=previous.z;break;}
  }
  player.rotation.y=Math.atan2(dir.x,dir.z);
  animateCharacter(player,dt,true);
 }else animateCharacter(player,dt,false);
 if(playerIsJumping){playerVerticalVelocity-=18*dt;player.position.y+=playerVerticalVelocity*dt;if(player.position.y<=0){player.position.y=0;playerVerticalVelocity=0;playerIsJumping=false;}}
 player.position.x=clamp(player.position.x,-CITY_LIMIT,CITY_LIMIT);player.position.z=clamp(player.position.z,-CITY_LIMIT,CITY_LIMIT);
 const followDistance=isAiming?4.4:7.5;
 const horizontal=Math.cos(cameraPitch)*followDistance;
 const shoulder=isAiming?0.72:0;
 const cameraOffset=new THREE.Vector3(Math.sin(cameraAngleY)*horizontal+Math.cos(cameraAngleY)*shoulder, (isAiming?2.15:3.0)+Math.sin(cameraPitch)*followDistance, Math.cos(cameraAngleY)*horizontal-Math.sin(cameraAngleY)*shoulder);
 camera.position.lerp(player.position.clone().add(cameraOffset),isAiming?.24:.18);
 camera.lookAt(player.position.clone().add(new THREE.Vector3(0,isAiming?1.45:1.25,0)));
}

function applyVehicleDamage(){
 if(!carBody)return;
 const stage=carDamage>=75?3:carDamage>=50?2:carDamage>=25?1:0;
 if(stage===damageStage&&stage===0)return;
 damageStage=stage;
 // Deformações progressivas e localizadas nos painéis em vez de apenas escalar o carro inteiro.
 const parts=vehicle&&vehicle.userData.damageParts||{};
 if(parts.hood){parts.hood.position.z=-1.18+stage*.10;parts.hood.position.y=1.03-stage*.045;parts.hood.rotation.x=-stage*.055;parts.hood.rotation.z=stage*.025;}
 if(parts.frontBumper){parts.frontBumper.position.z=-2.12+stage*.13;parts.frontBumper.position.y=.46-stage*.035;parts.frontBumper.rotation.x=stage*.035;}
 if(parts.rearBumper){parts.rearBumper.position.z=2.12-stage*.07;parts.rearBumper.position.y=.46-stage*.025;}
 if(parts.leftDoor){parts.leftDoor.position.x=-.78-stage*.025;parts.leftDoor.rotation.z=stage*.025;}
 if(parts.rightDoor){parts.rightDoor.position.x=.78+stage*.025;parts.rightDoor.rotation.z=-stage*.025;}
 // Os danos ficam claramente visíveis e acumulam intensidade com a barra de dano.
 const visuals=vehicle&&vehicle.userData.damageVisuals||[];
 visuals.forEach((part,index)=>{part.visible=stage>= (index<4?1:index<8?2:3)});
 carBody.scale.x=1-stage*.012;carBody.rotation.z=clamp((Math.random()-.5)*stage*.025,-.075,.075);
 if(stage>=2&&Math.random()<.5)createSmokeParticle(vehicle.position.clone().add(new THREE.Vector3(0,1.3,-.7)));
}

function explodePlayerVehicle(){
 if(vehicleDestroyed)return;vehicleDestroyed=true;carDamage=100;speed=0;carVelocity.set(0,0,0);
 const center=vehicle.position.clone();
 const fireMat=new THREE.MeshBasicMaterial({color:0xff5a16,transparent:true,opacity:.92});
 const core=new THREE.Mesh(new THREE.SphereGeometry(1.8,10,8),fireMat);core.position.copy(center).add(new THREE.Vector3(0,1,0));scene.add(core);
 const flashMat=new THREE.MeshBasicMaterial({color:0xffd56a,transparent:true,opacity:.8});const flash=new THREE.Mesh(new THREE.SphereGeometry(3.4,10,8),flashMat);flash.position.copy(core.position);scene.add(flash);
 let life=0;const timer=setInterval(()=>{life++;core.scale.multiplyScalar(1.16);core.material.opacity*=.76;flash.scale.multiplyScalar(1.2);flash.material.opacity*=.68;if(life>7){clearInterval(timer);scene.remove(core,flash);core.geometry.dispose();flash.geometry.dispose();core.material.dispose();flash.material.dispose()}},65);
 // Fragmentos leves de carroceria voam para fora; permanecem poucos segundos para manter desempenho mobile.
 for(let i=0;i<8;i++){const shard=new THREE.Mesh(new THREE.BoxGeometry(.18+Math.random()*.25,.08+Math.random()*.12,.12+Math.random()*.22),new THREE.MeshStandardMaterial({color:[0xd52657,0x292d31,0x8b9299][i%3],metalness:.45,roughness:.55}));shard.position.copy(center).add(new THREE.Vector3((Math.random()-.5)*2,.4+Math.random(),(Math.random()-.5)*2));scene.add(shard);const vel=new THREE.Vector3((Math.random()-.5)*10,2+Math.random()*7,(Math.random()-.5)*10);let age=0;const tick=()=>{age+=.05;shard.position.addScaledVector(vel,.05);vel.y-=.22;shard.rotation.x+=.12;shard.rotation.z+=.09;if(age<2.2)requestAnimationFrame(tick);else{scene.remove(shard);shard.geometry.dispose();shard.material.dispose()}};requestAnimationFrame(tick)}
 for(let i=0;i<10;i++)createSmokeParticle(center.clone().add(new THREE.Vector3((Math.random()-.5)*2,1+Math.random()*1.5,(Math.random()-.5)*2)));
 playSoundEffect('crash');showGameToast('VEÍCULO DESTRUÍDO','Dano 100%. O carro parou; leve-o à oficina para reparar.','#ff654a');updateStatsDisplay();
}

function updateVehicle(dt){
 const transportType=vehicle&&vehicle.userData.transportType;
 const throttle=keys.forward?1:keys.backward?-1:0;
 const maxSpeed=(carDamage>=100||vehicleDestroyed)?0:(vehicle&&vehicle.userData.maxSpeed||vehicleSpeedLimit);
 const steerInput=(keys.left?1:0)-(keys.right?1:0);
 steering+=(steerInput-steering)*Math.min(1,dt*5.5);
 const turnGrip=clamp(Math.abs(speed)/3.5,0,1.25);
 vehicle.rotation.y+=steering*turnGrip*1.35*Math.sign(speed||0)*dt;
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(vehicle.quaternion);
 const right=new THREE.Vector3(1,0,0).applyQuaternion(vehicle.quaternion);
 const forwardSpeed=carVelocity.dot(forward);
 let driveForce=0;
 if(throttle>0&&fuel>0)driveForce=forwardSpeed<0?19:10.5;
 else if(throttle<0)driveForce=forwardSpeed>0?-19:(fuel>0?-7:0);
 carVelocity.addScaledVector(forward,driveForce*dt);
 carVelocity.multiplyScalar(Math.exp(-(throttle===0?.42:.16)*dt));
 const longitudinal=clamp(carVelocity.dot(forward),-8,maxSpeed);
 const lateral=carVelocity.dot(right)*Math.exp(-3.4*dt);
 carVelocity.copy(forward.multiplyScalar(longitudinal).add(right.multiplyScalar(lateral)));
 speed=longitudinal;
 const previous=vehicle.position.clone();
 vehicle.position.addScaledVector(carVelocity,dt);
 if(transportType==='helicopter'){
  // Voo estável em altitude de cruzeiro; o joystick controla deslocamento e direção.
  const targetAltitude=7+Math.min(5,Math.abs(speed)*.09);
  vehicle.position.y+=(targetAltitude-vehicle.position.y)*Math.min(1,dt*1.8);
  if(vehicle.userData.rotor)vehicle.userData.rotor.rotation.y+=dt*22;
  if(vehicle.userData.tailRotor)vehicle.userData.tailRotor.rotation.x+=dt*28;
 }else if(transportType==='boat'){
  vehicle.position.y=.05+Math.sin(performance.now()*.0025)*.035;
 }
 let collided=false;
 for(const obstacle of (transportType==='helicopter'?[]:buildingColliders)){
  const dx=Math.abs(vehicle.position.x-obstacle.x),dz=Math.abs(vehicle.position.z-obstacle.z);
  if(dx<obstacle.halfX+1.25&&dz<obstacle.halfZ+2){
   vehicle.position.copy(previous);carVelocity.multiplyScalar(-.22);speed=carVelocity.dot(forward);
   const oldDamage=carDamage;carDamage=clamp(carDamage+Math.max(4,Math.abs(longitudinal)*.7),0,100);applyVehicleDamage();if(oldDamage<100&&carDamage>=100)explodePlayerVehicle();collided=true;break;
  }
 }
 if(collided)playSoundEffect("crash");
 if(vehicle.position.x<-CITY_LIMIT||vehicle.position.x>CITY_LIMIT){vehicle.position.x=clamp(vehicle.position.x,-CITY_LIMIT,CITY_LIMIT);carVelocity.x*=-.25}
 if(vehicle.position.z<-CITY_LIMIT||vehicle.position.z>CITY_LIMIT){vehicle.position.z=clamp(vehicle.position.z,-CITY_LIMIT,CITY_LIMIT);carVelocity.z*=-.25}
 fuel=Math.max(0,fuel-Math.abs(speed)*dt*.018);
 const wheelSpin=speed*dt/.39;
 for(const wheel of wheelMeshes)wheel.rotation.x+=wheelSpin;
 if(carBody)carBody.rotation.z=clamp(-steering*speed*.003,-.08,.08);
 updateVehicleCamera(dt);
 if(Math.abs(speed)>2&&carDamage>25&&Math.random()<dt*(carDamage>=70?3:1.1))createSmokeParticle(vehicle.position);
 updateEngineSound(speed/22);
}

function triggerPedestrianRagdoll(ped,impactVelocity){
 if(!ped||ped.userData.isRagdoll)return;
 ped.userData.isRagdoll=true;
 const impulse=impactVelocity?impactVelocity.clone():new THREE.Vector3((Math.random()-.5)*2,0,(Math.random()-.5)*2);
 ped.userData.velocity=impulse.multiplyScalar(.65);ped.userData.velocity.y=Math.max(.16,Math.abs(impulse.length())*.12);
 ped.userData.ragdollTimer=3.2;ped.userData.hitCooldown=1.2;
 const model=ped.userData.humanModel||ped;
 if(model.userData){for(const limb of (model.userData.arms||[]))limb.rotation.z+=(Math.random()-.5)*1.8;for(const limb of (model.userData.legs||[]))limb.rotation.x+=(Math.random()-.5)*1.3;}
 ped.rotation.x=(Math.random()-.5)*.45;ped.rotation.z=(Math.random()-.5)*.5;
}

/* ---------- TRAFFIC ---------- */

function createExtraTransport(kind){
 const g=new THREE.Group();g.userData.displayName=kind==='motorcycle'?'Motocicleta':kind==='scooter'?'Scooter elétrico':'Bicicleta';g.userData.maxSpeed=kind==='motorcycle'?30:kind==='scooter'?17:11;g.userData.transportType=kind;
 const frameMat=new THREE.MeshStandardMaterial({color:kind==='bicycle'?0x24a0ed:kind==='scooter'?0x29c6b7:0xc52d42,metalness:.55,roughness:.38});
 const dark=new THREE.MeshStandardMaterial({color:0x20242a,roughness:.9});const metal=new THREE.MeshStandardMaterial({color:0xb6c0c7,metalness:.82,roughness:.25});
 const wheels=[];const wheelGeo=new THREE.TorusGeometry(kind==='bicycle'?.34:.31,.065,8,18);
 // Helicóptero pilotável: corpo leve, cabine, cauda, rotor animado e patins.
 if(kind==='helicopter'){
  g.userData.displayName='Helicóptero';g.userData.maxSpeed=34;g.userData.transportType=kind;g.userData.rotor=null;
  const fuselage=new THREE.Mesh(new THREE.SphereGeometry(1,12,9),new THREE.MeshStandardMaterial({color:0x2d7d55,metalness:.25,roughness:.48}));fuselage.scale.set(.72,.62,1.35);fuselage.position.y=.95;g.add(fuselage);
  const cockpit=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),new THREE.MeshStandardMaterial({color:0x79c7df,metalness:.35,roughness:.2,transparent:true,opacity:.82}));cockpit.scale.set(.52,.4,.58);cockpit.position.set(0,1.08,-.78);g.add(cockpit);
  const tail=new THREE.Mesh(new THREE.CylinderGeometry(.12,.2,1.8,8),new THREE.MeshStandardMaterial({color:0x286447,roughness:.55}));tail.rotation.x=Math.PI/2;tail.position.set(0,1.02,1.72);g.add(tail);
  const mast=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.48,8),metal);mast.position.set(0,1.68,0);g.add(mast);
  const rotor=new THREE.Group();rotor.position.set(0,1.94,0);for(let i=0;i<4;i++){const blade=new THREE.Mesh(new THREE.BoxGeometry(.16,.035,2.65),dark);blade.rotation.y=i*Math.PI/2;blade.position.z=-.85;rotor.add(blade)}g.add(rotor);g.userData.rotor=rotor;
  const tailRotor=new THREE.Mesh(new THREE.TorusGeometry(.3,.035,5,12),metal);tailRotor.position.set(0,1.05,2.48);tailRotor.rotation.y=Math.PI/2;g.add(tailRotor);g.userData.tailRotor=tailRotor;
  for(const x of [-.58,.58]){const skid=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,1.8,7),dark);skid.rotation.z=Math.PI/2;skid.position.set(x,.35,.05);g.add(skid);const strut=new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.5,6),metal);strut.position.set(x,.56,0);g.add(strut)}
  g.userData.driveBody=null;g.userData.driveWheels=[];g.userData.isExtraTransport=true;g.position.y=7;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g;
 }
 // Lancha pilotável para a área costeira.
 if(kind==='boat'){
  g.userData.displayName='Lancha';g.userData.maxSpeed=23;g.userData.transportType=kind;
  const hull=new THREE.Mesh(new THREE.CylinderGeometry(.5,.9,3.4,8,1,false),new THREE.MeshStandardMaterial({color:0xf0f1e9,metalness:.2,roughness:.42}));hull.rotation.x=Math.PI/2;hull.scale.set(.72,.55,1);hull.position.set(0,.38,0);g.add(hull);
  const stripe=new THREE.Mesh(new THREE.BoxGeometry(.9,.18,2.7),new THREE.MeshStandardMaterial({color:0xe64b38,roughness:.5}));stripe.position.set(0,.68,0);g.add(stripe);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(.82,.65,1.0),new THREE.MeshStandardMaterial({color:0x6abbd0,metalness:.25,roughness:.22,transparent:true,opacity:.82}));cabin.position.set(0,1.02,-.18);g.add(cabin);
  const seat=new THREE.Mesh(new THREE.BoxGeometry(.68,.18,.38),dark);seat.position.set(0,.77,.72);g.add(seat);
  const motor=new THREE.Mesh(new THREE.BoxGeometry(.35,.45,.28),metal);motor.position.set(0,.45,1.52);g.add(motor);
  g.userData.driveBody=null;g.userData.driveWheels=[];g.userData.isExtraTransport=true;g.position.y=.05;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g;
 }
 for(const z of [-.83,.78]){const w=new THREE.Mesh(wheelGeo,dark);w.position.set(0,.36,z);w.rotation.y=Math.PI/2;g.add(w);wheels.push(w);const hub=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.12,10),metal);hub.rotation.z=Math.PI/2;hub.position.copy(w.position);g.add(hub)}
 if(kind==='bicycle'){
  // Quadro leve com tubos cilíndricos, pedais e guidão.
  const tube=(a,b,r=.035,mat=frameMat)=>{const d=new THREE.Vector3().subVectors(b,a),m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),7),mat);m.position.copy(a).add(b).multiplyScalar(.5);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());g.add(m)};
  const rear=new THREE.Vector3(0,.38,.78),crank=new THREE.Vector3(0,.42,.05),seat=new THREE.Vector3(0,.9,.25),front=new THREE.Vector3(0,.38,-.83),stem=new THREE.Vector3(0,.91,-.58);
  tube(rear,crank);tube(crank,seat);tube(seat,rear);tube(seat,stem);tube(stem,front);tube(front,crank);tube(seat,new THREE.Vector3(0,1.02,.36),.045,dark);tube(stem,new THREE.Vector3(0,1.02,-.68),.035,metal);
  const pedal=new THREE.Mesh(new THREE.BoxGeometry(.32,.045,.08),dark);pedal.position.set(0,.4,.05);g.add(pedal);
 }else{
  const deck=new THREE.Mesh(new THREE.BoxGeometry(.32,.12,.72),dark);deck.position.set(0,.55,.05);g.add(deck);
  const body=new THREE.Mesh(new THREE.BoxGeometry(.42,.42,.5),frameMat);body.position.set(0,.76,.12);g.add(body);
  const seat=new THREE.Mesh(new THREE.BoxGeometry(.34,.10,.38),dark);seat.position.set(0,1.05,.3);g.add(seat);
  const column=new THREE.Mesh(new THREE.CylinderGeometry(.035,.045,.5,8),metal);column.position.set(0,.83,-.48);column.rotation.x=-.16;g.add(column);
  const bar=new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,.55,8),dark);bar.rotation.z=Math.PI/2;bar.position.set(0,1.1,-.54);g.add(bar);
  if(kind==='motorcycle'){
   const tank=new THREE.Mesh(new THREE.SphereGeometry(.27,10,8),frameMat);tank.scale.set(.8,.65,1.25);tank.position.set(0,.98,-.1);g.add(tank);
   const lamp=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),new THREE.MeshStandardMaterial({color:0xffefbd,emissive:0xffd27a,emissiveIntensity:.7}));lamp.position.set(0,.95,-.66);g.add(lamp);
   const exhaust=new THREE.Mesh(new THREE.CylinderGeometry(.045,.055,.62,8),metal);exhaust.rotation.x=Math.PI/2;exhaust.position.set(.22,.48,.35);g.add(exhaust);
  }else{
   const lamp=new THREE.Mesh(new THREE.BoxGeometry(.14,.1,.06),new THREE.MeshStandardMaterial({color:0xffefbd,emissive:0xffd27a,emissiveIntensity:.55}));lamp.position.set(0,.78,-.25);g.add(lamp);
  }
 }
 g.userData.driveBody=null;g.userData.driveWheels=wheels;g.userData.isExtraTransport=true;g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});return g;
}
function createExtraTransportFleet(){
 const kinds=['motorcycle','motorcycle','motorcycle','scooter','scooter','scooter','bicycle','bicycle','bicycle','helicopter','boat','boat'];
 for(let i=0;i<kinds.length;i++){
  const kind=kinds[i],t=createExtraTransport(kind);
  if(kind==='helicopter'){t.position.set(720,7,690);t.rotation.y=-Math.PI/3;}
  else if(kind==='boat'){t.position.set(-500,.05,-500+i*7);t.rotation.y=Math.PI/2;}
  else{const street=(Math.floor(Math.random()*14)-6.5)*100;const along=(Math.random()-.5)*1300;
   if(Math.random()<.5){t.position.set(along,0,street+(Math.random()<.5?-7:7));t.rotation.y=Math.random()<.5?Math.PI/2:-Math.PI/2}else{t.position.set(street+(Math.random()<.5?-7:7),0,along);t.rotation.y=Math.random()<.5?0:Math.PI}}
  t.userData.stolen=false;scene.add(t);parkedVehicles.push(t);
 }
}

function createTrafficSystem(){
 const kinds=['sedan','luxury','compact','suv','pickup','van','taxi','sports','muscle','ambulance','truck'];
 for(let i=0;i<42;i++){
  const kind=kinds[Math.floor(Math.random()*kinds.length)];
  const car=createDetailedParkedCar(kind);
  car.scale.setScalar(kind==='compact'?.88:(kind==='truck'?1.02:.94));
  const axis=Math.random()<.5?'x':'z',street=(Math.floor(Math.random()*16)-7.5)*100;
  const direction=Math.random()<.5?1:-1,lane=(Math.random()<.5?-1:1)*4;
  if(axis==='x'){car.position.set((Math.random()-.5)*1460,0,street+lane);car.rotation.y=direction>0?-Math.PI/2:Math.PI/2}
  else{car.position.set(street+lane,0,(Math.random()-.5)*1460);car.rotation.y=direction>0?Math.PI:0}
  car.userData.speed=.28+Math.random()*.18;car.userData.direction=direction;car.userData.axis=axis;car.userData.hitCooldown=0;car.userData.type=i%3;car.userData.health=100;car.userData.disabled=false;
  scene.add(car);npcVehicles.push(car);
 }
}
function updateTraffic(dt){
 for(const npc of npcVehicles){
  const playerPosition=playerPos();
  const distanceToPlayer=npc.position.distanceTo(playerPosition);
  npc.visible=distanceToPlayer<220;
  if(distanceToPlayer>260)continue;
  if(npc.userData.disabled)continue;
  const d=npc.userData.speed*npc.userData.direction*dt*60;
  if(npc.userData.axis==="x")npc.position.x+=d;else npc.position.z+=d;
  const p=npc.userData.axis==="x"?npc.position.x:npc.position.z;
  if(Math.abs(p)>CITY_LIMIT){npc.userData.direction*=-1;npc.rotation.y+=Math.PI;}
  if(npc.userData.hitCooldown>0)npc.userData.hitCooldown-=dt;
  if(inVehicle&&vehicle.position.distanceTo(npc.position)<3&&Math.abs(speed)>3&&npc.userData.hitCooldown<=0){
   const oldDamage=carDamage;carDamage=clamp(carDamage+clamp(Math.abs(speed)*1.1,8,30),0,100);applyVehicleDamage();if(oldDamage<100&&carDamage>=100)explodePlayerVehicle();
   const impactSpeed=Math.abs(speed);carVelocity.multiplyScalar(-.28);speed*= -.28;npc.userData.hitCooldown=.75;damagePlayer(clamp(impactSpeed*.7,2,14),'Colisão');addWanted(1);playSoundEffect("crash");
  }
 }
 // Colisão do carro controlado com pedestres: impulso, queda e recuperação simples.
 if(inVehicle&&Math.abs(speed)>2.8){
  for(const ped of pedestrians){
   if(ped.userData.isRagdoll)continue;
   if(vehicle.position.distanceTo(ped.position)<2.15){
    const impact=carVelocity.clone();if(impact.length()<1)impact.set(0,0,1);
    triggerPedestrianRagdoll(ped,impact);playSoundEffect("crash");
    ped.userData.hitCooldown=1.2;
   }
  }
 }
}

/* ---------- WEAPONS ---------- */
function setupWeaponSystem(){}
let shootCooldown=0;
function toggleAimMode(){
 if(inVehicle){showGameToast('MIRA','Saia do veículo para mirar.','#ffd166');return;}
 isAiming=!isAiming;
 const reticle=$("aim-reticle"),btn=$("btn-aim");
 if(reticle)reticle.style.display=isAiming?'block':'none';
 if(btn){btn.classList.toggle('active',isAiming);btn.setAttribute('aria-pressed',String(isAiming));btn.setAttribute('aria-label',isAiming?'Desativar mira':'Ativar mira');btn.title=isAiming?'Desativar mira':'Mirar';}
 showGameToast(isAiming?'MIRA ATIVADA':'MIRA DESATIVADA',isAiming?'Toque em atirar para disparar com precisão.':'Câmera normal restaurada.',isAiming?'#b9ff6a':'#9ee7ff');
}
function setupWeaponArsenalSystem(){updateWeaponHud()}
function updateWeaponHud(){
 const w=weaponsList[currentWeaponIndex];currentWeapon=w.name;ammoCount=weaponAmmo[currentWeaponIndex];
 if($("weapon-name"))$("weapon-name").innerText=w.name;
 if($("ammo-count"))$("ammo-count").innerText=ammoCount;
 saveCooldown+=1;
 if(saveCooldown%12===0){try{localStorage.setItem('owm-save-v1',JSON.stringify({money,playerHealth,weaponAmmo,currentWeaponIndex,storyMissionIndex,position:player?{x:player.position.x,z:player.position.z}:null}));}catch(e){}}
}
function cycleWeaponArsenal(){
 currentWeaponIndex=(currentWeaponIndex+1)%weaponsList.length;
 updateWeaponHud();triggerAchievement("Arsenal Pesado","Equipou: "+currentWeapon);
}
function jumpPlayer(){
 if(inVehicle||playerIsJumping||gameOver||isGamePaused)return;
 playerIsJumping=true;playerVerticalVelocity=6.8;playSoundEffect('jump');
}
function reloadWeapon(){
 if(reloadTimer>0)return;
 const capacities=[50,120,90,30],idx=currentWeaponIndex,capacity=capacities[idx],missing=capacity-weaponAmmo[idx];
 if(missing<=0){showGameToast('MUNIÇÃO','O pente já está cheio.','#ffd166');return;}
 if(money>=0){const reserve=weaponAmmo[idx];weaponAmmo[idx]=Math.min(capacity,reserve+missing);ammoCount=weaponAmmo[idx];reloadTimer=.7;updateWeaponHud();updateStatsDisplay();showGameToast('RECARREGADO',currentWeapon+' pronto.','#b9ff6a');}
}
function damagePlayer(amount,source='Perigo'){
 if(gameOver||isGamePaused)return;
 playerHealth=clamp(playerHealth-amount,0,100);updateStatsDisplay();
 if(playerHealth<=0){
  gameOver=true;isGamePaused=true;keys.forward=keys.backward=keys.left=keys.right=false;
  const overlay=$('game-over');if(overlay){overlay.style.display='flex';const h=overlay.querySelector('h1'),p=overlay.querySelector('p');if(h)h.textContent='💥 VOCÊ FOI DERRUBADO';if(p)p.textContent='Você ficou sem vida. Reinicie para voltar à cidade.';}
  showGameToast('FIM DE JOGO','Sua vida chegou a zero.','#ff6b6b');
 }else if(playerHealth<30)showGameToast('VIDA BAIXA',source+'! Procure um kit médico.','#ff6b6b');
}
function shootWeapon(){
 if(inVehicle||weaponAmmo[currentWeaponIndex]<=0||shootCooldown>0||reloadTimer>0)return;
 const w=weaponsList[currentWeaponIndex];
 weaponAmmo[currentWeaponIndex]--;ammoCount=weaponAmmo[currentWeaponIndex];
 shootCooldown=w.fireDelay;updateStatsDisplay();playSoundEffect("shoot");
 const aimDir=new THREE.Vector3();camera.getWorldDirection(aimDir);
 const muzzle=player.position.clone().add(new THREE.Vector3(0,1.35,0));
 // Disparos seguem a direção real da câmera; a mira usa menos dispersão.
 for(let i=0;i<w.projectiles;i++){
  const geo=new THREE.SphereGeometry(i===0?.085:.065,isAiming?5:4,isAiming?5:4),mat=new THREE.MeshBasicMaterial({color:w.color});
  const bullet=new THREE.Mesh(geo,mat);
  bullet.position.copy(muzzle).addScaledVector(aimDir,.7);
  const spreadScale=isAiming?.28:1;
  const dir=aimDir.clone().add(new THREE.Vector3((Math.random()-.5)*w.spread*spreadScale,(Math.random()-.5)*w.spread*.35*spreadScale,(Math.random()-.5)*w.spread*spreadScale)).normalize();
  bullet.userData={velocity:dir.multiplyScalar(w.velocity),life:w.range/w.velocity,damage:w.damage};
  scene.add(bullet);bullets.push(bullet);
 }
}
function updateBullets(dt){
 for(let i=bullets.length-1;i>=0;i--){
  const bullet=bullets[i];bullet.position.addScaledVector(bullet.userData.velocity,dt*60);bullet.userData.life-=dt*60;
  let hit=false;
  for(const ped of pedestrians){
   if(!ped.userData.isRagdoll&&bullet.position.distanceTo(ped.position.clone().add(new THREE.Vector3(0,1,0)))<1.15){
    ped.userData.health=(ped.userData.health==null?100:ped.userData.health)-bullet.userData.damage;
    ped.userData.fleeTimer=4;ped.userData.fleeAngle=Math.atan2(ped.position.x-playerPos().x,ped.position.z-playerPos().z);
    addWanted(1);
    if(ped.userData.health<=0){
     triggerPedestrianRagdoll(ped,new THREE.Vector3((Math.random()-.5)*1.5,.6,(Math.random()-.5)*1.5));
     showGameToast('NPC ATINGIDO','O personagem foi derrubado. A polícia foi alertada.','#ffb36b');
    }else showGameToast('DANO','NPC: '+Math.max(0,Math.round(ped.userData.health))+'% de vida restante.','#ffd166');
    hit=true;break;
   }
  }
  if(!hit)for(const cop of policeCars){
   if(bullet.position.distanceTo(cop.position.clone().add(new THREE.Vector3(0,.8,0)))<2.8){
    cop.userData.health-=bullet.userData.damage;addWanted(2);hit=true;
    if(cop.userData.health<=0){
     if(cop.userData.officer)scene.remove(cop.userData.officer);
     cop.traverse(o=>{if(o.isMesh&&o.material&&o.material.color){o.material=o.material.clone();o.material.color.lerp(new THREE.Color(0x292929),.7)}});
     cop.userData.state='disabled';cop.userData.officer=null;cop.userData.disabled=true;
     showGameToast('VIATURA DESTRUÍDA','A polícia enviará reforços.','#ff6b6b');
    }else showGameToast('VIATURA ATINGIDA','Integridade: '+Math.max(0,Math.round(cop.userData.health))+'%.','#ffb36b');
    break;
   }
  }
  if(!hit)for(const npc of npcVehicles){
   if(bullet.position.distanceTo(npc.position.clone().add(new THREE.Vector3(0,.8,0)))<2.5){
    npc.userData.health=(npc.userData.health==null?100:npc.userData.health)-bullet.userData.damage;
    npc.userData.hitCooldown=1.0;addWanted(1);
    if(npc.userData.health<=0){
     npc.userData.disabled=true;npc.userData.speed=0;
     npc.traverse(o=>{if(o.isMesh&&o.material&&o.material.color){o.material=o.material.clone();o.material.color.lerp(new THREE.Color(0x292929),.62);o.material.roughness=.95}});
     showGameToast('CARRO DANIFICADO','O veículo foi imobilizado. Procure outro carro.','#ffb36b');
    }else showGameToast('DANO NO VEÍCULO','Integridade: '+Math.max(0,Math.round(npc.userData.health))+'%.','#ffd166');
    hit=true;break;
   }
  }
  if(hit||bullet.userData.life<=0){scene.remove(bullet);bullet.geometry.dispose();bullet.material.dispose();bullets.splice(i,1)}
 }
 shootCooldown=Math.max(0,shootCooldown-dt);reloadTimer=Math.max(0,reloadTimer-dt);
}

/* ---------- AI / POLICE ---------- */
function updatePedestrianAI(dt){
 const target=playerPos();
 for(const ped of pedestrians){
  if(ped.userData.isRagdoll){
   if(ped.userData.velocity){ped.position.addScaledVector(ped.userData.velocity,dt*60);ped.userData.velocity.y-=.018*dt*60;ped.userData.velocity.multiplyScalar(Math.pow(.965,dt*60));}
   if(ped.position.y<0)ped.position.y=0;
   ped.userData.ragdollTimer=(ped.userData.ragdollTimer||3)-dt;
   if(ped.userData.ragdollTimer<=0){ped.userData.isRagdoll=false;ped.userData.velocity=null;ped.rotation.set(0,ped.rotation.y,0);const model=ped.userData.humanModel||ped;if(model.userData){for(const limb of (model.userData.arms||[]))limb.rotation.set(0,0,0);for(const limb of (model.userData.legs||[]))limb.rotation.set(0,0,0);}}
   continue;
  }
  const dx=ped.position.x-target.x,dz=ped.position.z-target.z;
  const dist=Math.hypot(dx,dz);
  // Render pedestrians only nearby; distant AI sleeps to reduce CPU usage on phones.
  ped.visible=dist<72;
  if(dist>80)continue;
  if(ped.userData.fleeTimer>0){
   ped.userData.fleeTimer-=dt;const a=ped.userData.fleeAngle||0;ped.position.x+=Math.sin(a)*.12*dt*60;ped.position.z+=Math.cos(a)*.12*dt*60;
  }else if(dist<12){
   const len=dist||1;ped.position.x+=(dx/len)*.08*dt*60;ped.position.z+=(dz/len)*.08*dt*60;
  }else{
   ped.userData.patrolAngle+=.01*dt*60;
   ped.position.x+=Math.sin(ped.userData.patrolAngle)*.02*dt*60;
   ped.position.z+=Math.cos(ped.userData.patrolAngle)*.02*dt*60;
  }
  ped.position.x=clamp(ped.position.x,-CITY_LIMIT+8,CITY_LIMIT-8);
  ped.position.z=clamp(ped.position.z,-CITY_LIMIT+8,CITY_LIMIT-8);
  if(ped.userData.humanModel) animateCharacter(ped.userData.humanModel,dt,dist>2);
 }
}
function setupWantedSystem(){updateWantedDisplay()}
function addWanted(amount){
 wantedLevel=clamp(wantedLevel+amount,0,5);wantedSearchTimer=55;updateWantedDisplay();spawnPoliceCars();
}
function updateWantedDisplay(){
 const el=$("wanted-stars");if(el)el.innerText=wantedLevel?"⭐".repeat(wantedLevel):"Nenhum";
}
function spawnPoliceCars(){
 const desired=wantedLevel?Math.min(7,wantedLevel+1):0;
 const bodyMat=new THREE.MeshStandardMaterial({color:0x172f50,metalness:.48,roughness:.38});
 const glassMat=new THREE.MeshStandardMaterial({color:0x101c27,metalness:.2,roughness:.2});
 const redMat=new THREE.MeshStandardMaterial({color:0xff263e,emissive:0x9b0014,emissiveIntensity:.8});
 const blueMat=new THREE.MeshStandardMaterial({color:0x278dff,emissive:0x063d9b,emissiveIntensity:.8});
 const target=playerPos();
 while(policeCars.length<desired){
  const cop=new THREE.Group();
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.2,.82,4.5),bodyMat);body.position.y=.62;cop.add(body);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.7,.65,2.1),glassMat);cabin.position.set(0,1.28,.05);cop.add(cabin);
  const bar=new THREE.Mesh(new THREE.BoxGeometry(1.15,.16,.34),bodyMat);bar.position.set(0,1.7,-.05);cop.add(bar);
  const red=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.3),redMat);red.position.set(-.3,1.82,-.05);cop.add(red);
  const blue=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.3),blueMat);blue.position.set(.3,1.82,-.05);cop.add(blue);
  const tires=new THREE.MeshStandardMaterial({color:0x141619,roughness:.9});
  const wheelGeo=new THREE.CylinderGeometry(.37,.37,.27,10);
  for(const wx of [-1,1])for(const wz of [-1.35,1.35]){const wheel=new THREE.Mesh(wheelGeo,tires);wheel.rotation.z=Math.PI/2;wheel.position.set(wx,.38,wz);cop.add(wheel)}
  const axis=Math.random()<.5?"x":"z",lane=(Math.random()<.5?-1:1)*4;
  const road=value=>clamp(Math.round((value+CITY_EDGE)/100)*100-CITY_EDGE,-CITY_EDGE,CITY_EDGE);
  if(axis==="x")cop.position.set(clamp(target.x+(Math.random()<.5?-1:1)*85,-CITY_LIMIT,CITY_LIMIT),0,road(target.z)+lane);
  else cop.position.set(road(target.x)+lane,0,clamp(target.z+(Math.random()<.5?-1:1)*85,-CITY_LIMIT,CITY_LIMIT));
  cop.lookAt(target);cop.userData={health:100,flash:Math.random()*Math.PI*2,state:"chase",officer:null};
  scene.add(cop);policeCars.push(cop);
 }
}
function updatePoliceAI(dt){
 if(!wantedLevel||gameOver)return;
 const target=playerPos();let closest=Infinity;
 for(const cop of policeCars){
  const ud=cop.userData;
  if(ud.state==='arrested'||ud.disabled||ud.state==='disabled')continue;
  if(ud.state==='chase'){
   const dir=new THREE.Vector3().subVectors(target,cop.position);dir.y=0;
   const distance=dir.length();closest=Math.min(closest,distance);
   // A viatura para antes de alcançar o jogador; nunca empurra nem bate no carro do jogador.
   if(distance>15){dir.normalize();cop.position.addScaledVector(dir,Math.min(7*dt,Math.max(0,distance-14)));cop.lookAt(target)}
   else{
    ud.state='exit';ud.exitTimer=.85;ud.officer=createCharacterGroup({shirt:0x182a42,pants:0x101923,skin:0xc9906d});
    ud.officer.position.copy(cop.position).add(new THREE.Vector3(2.7,0,0).applyAxisAngle(new THREE.Vector3(0,1,0),cop.rotation.y));
    ud.officer.rotation.y=cop.rotation.y;scene.add(ud.officer);
   }
  } else if(ud.state==='exit'){
   ud.exitTimer-=dt;
   if(ud.exitTimer<=0)ud.state='walk';
   animateCharacter(ud.officer,dt,false);
  } else if(ud.state==='walk'){
   const goal=playerPos();const dir=new THREE.Vector3().subVectors(goal,ud.officer.position);dir.y=0;
   const distance=dir.length();closest=Math.min(closest,distance);
   if(distance>1.7){dir.normalize();ud.officer.position.addScaledVector(dir,Math.min(2.15*dt,distance-1.4));ud.officer.rotation.y=Math.atan2(dir.x,dir.z);animateCharacter(ud.officer,dt,true)}
   else{
    policeAttackCooldown-=dt;
    if(policeAttackCooldown<=0){damagePlayer(8,'Polícia');policeAttackCooldown=.8;}
    if(playerHealth<=0){ud.state='arrested';}
    if(ud.officer)animateCharacter(ud.officer,dt,false);
   }
  }
  ud.flash+=dt*12;
  if(cop.children[3])cop.children[3].visible=Math.sin(ud.flash)>-.1;
  if(cop.children[4])cop.children[4].visible=!cop.children[3].visible;
 }
 if(closest<105)wantedSearchTimer=45;else wantedSearchTimer-=dt;
 if(wantedSearchTimer<=0){
  wantedLevel=Math.max(0,wantedLevel-1);wantedSearchTimer=wantedLevel?38:0;updateWantedDisplay();
  const desired=wantedLevel?Math.min(7,wantedLevel+1):0;
  while(policeCars.length>desired){const cop=policeCars.pop();if(cop.userData.officer)scene.remove(cop.userData.officer);scene.remove(cop)}
  if(wantedLevel===0){for(const cop of policeCars){if(cop.userData.officer)scene.remove(cop.userData.officer);scene.remove(cop)}policeCars.length=0}
  else spawnPoliceCars();
 }
}

/* ---------- CAMPANHA / MISSÕES ---------- */
const storyDialogues=[
 {speaker:'NARRADOR',text:'VICE CITY — 22:40. O ônibus para perto da orla. Neon, motores e sirenes iluminam a noite.'},
 {speaker:'CJ',text:'Uma cidade nova, uma chance nova. Só preciso encontrar o contato que me prometeram.'},
 {speaker:'TELEFONE DESCONHECIDO',text:'Se você recebeu esta mensagem, não venha ao porto. Procure o telefone público perto da marina. A chave está escondida lá.'},
 {speaker:'CJ',text:'Isso está com cara de problema... mas é a única pista que eu tenho.'}
];
// Campanha completa: objetivos de localização que usam o mapa, GPS, marcador e sistema de recompensas existentes.
const storyMissions=[
 {title:'A mensagem',chapter:'CAPÍTULO 1 — UMA NOVA VIDA',x:115,z:8,reward:300,description:'Vá ao telefone público da marina e encontre a pista.',speaker:'CJ',after:'A chave estava escondida atrás do telefone. O bilhete cita uma mecânica chamada Maya e um carro deixado para você.'},
 {title:'O carro emprestado',chapter:'CAPÍTULO 1 — UMA NOVA VIDA',x:-300,z:-200,reward:450,description:'Encontre a garagem de Maya e pegue o carro emprestado.',speaker:'MAYA',after:'Maya entrega a chave, mas avisa: alguém está seguindo seus passos. Ela encontrou uma pista sobre um pacote no centro.'},
 {title:'A pista',chapter:'CAPÍTULO 1 — UMA NOVA VIDA',x:100,z:-300,reward:500,description:'Vá ao prédio abandonado e procure o contato.',speaker:'CONTATO',after:'O contato revela que o pacote pertence a uma organização que controla parte do porto. Você precisa descobrir quem está por trás disso.'},
 {title:'Dívidas de sangue',chapter:'CAPÍTULO 2 — DÍVIDAS DE SANGUE',x:300,z:100,reward:650,description:'Vá ao encontro no distrito comercial e fale com o informante.',speaker:'INFORMANTE',after:'O informante aponta um veículo roubado usado pelos criminosos. Ele está escondido perto dos galpões.'},
 {title:'Carro roubado',chapter:'CAPÍTULO 2 — DÍVIDAS DE SANGUE',x:500,z:300,reward:700,description:'Localize o carro roubado perto dos galpões do distrito industrial.',speaker:'CJ',after:'Dentro do carro há documentos que ligam a quadrilha a um depósito no porto. A polícia também está chegando.'},
 {title:'Arquivos secretos',chapter:'CAPÍTULO 3 — A CIDADE TEM UM PREÇO',x:600,z:-300,reward:850,description:'Chegue ao arquivo secreto e encontre os documentos.',speaker:'MAYA',after:'Os documentos mostram que a rede criminosa comprou testemunhas e policiais. Uma testemunha está escondida na praia.'},
 {title:'Testemunha na praia',chapter:'CAPÍTULO 3 — A CIDADE TEM UM PREÇO',x:-500,z:400,reward:900,description:'Encontre a testemunha na praia antes que ela fuja.',speaker:'TESTEMUNHA',after:'A testemunha confirma a identidade do chefe e revela a entrada de serviço do porto.'},
 {title:'Infiltração no porto',chapter:'CAPÍTULO 3 — A CIDADE TEM UM PREÇO',x:700,z:500,reward:1100,description:'Vá até a entrada de serviço do porto para localizar o carregamento.',speaker:'CJ',after:'Você encontrou o carregamento, mas os criminosos perceberam a infiltração. Agora é preciso despistar a perseguição.'},
 {title:'Caçada noturna',chapter:'CAPÍTULO 4 — SEM SAÍDA',x:-100,z:600,reward:1250,description:'Atravesse a cidade e alcance o esconderijo para despistar os perseguidores.',speaker:'MAYA',after:'Você despistou os perseguidores. Maya foi levada para a marina; não há tempo a perder.'},
 {title:'Resgate na marina',chapter:'CAPÍTULO 4 — SEM SAÍDA',x:115,z:8,reward:1500,description:'Volte à marina e encontre Maya.',speaker:'MAYA',after:'Maya está segura e entrega a última prova. O chefe estará no porto para a negociação final.'},
 {title:'A última entrega',chapter:'CAPÍTULO 5 — O ÚLTIMO NEGÓCIO',x:650,z:650,reward:1800,description:'Leve as provas ao ponto de encontro no porto.',speaker:'CJ',after:'As provas chegaram ao destino. O chefe tentou fugir para o cais, mas você finalmente o encurralou.'},
 {title:'O confronto',chapter:'CAPÍTULO 5 — O ÚLTIMO NEGÓCIO',x:720,z:700,reward:3000,description:'Vá ao cais e encerre a operação.',speaker:'NARRADOR',after:'A operação terminou. A cidade ainda guarda segredos, mas sua história virou lenda em Vice City. Campanha principal concluída!'}
];
function readStoryProgress(){try{return Math.max(0,Math.min(storyMissions.length,parseInt(localStorage.getItem('owm-story-v1-progress')||'0',10)||0))}catch(e){return 0}}
function saveStoryProgress(){try{localStorage.setItem('owm-story-v1-progress',String(storyMissionIndex))}catch(e){}}
function setupMissionSystem(){
 storyMissionIndex=readStoryProgress();
 showMission(storyMissionIndex>=storyMissions.length?'🏆 Campanha concluída! Explore a cidade ou faça entregas.':'📖 Sombras de Vice City — campanha '+(storyMissionIndex+1)+'/'+storyMissions.length);
 try{if(!localStorage.getItem('owm-story-v1-intro-seen')&&storyMissionIndex===0){setTimeout(showStoryIntro,700)}else{storyIntroShown=true;if(storyMissionIndex<storyMissions.length)startStoryMission(storyMissionIndex)}}catch(e){setTimeout(showStoryIntro,700)}
}
function showStoryIntro(){
 if(storyIntroShown)return;storyIntroShown=true;storyDialogIndex=0;
 const overlay=document.createElement('div');overlay.id='story-dialog-overlay';overlay.innerHTML='<div class="story-card"><div class="story-kicker">OPEN WORLD MOBILE · CAMPANHA</div><h2>Sombras de Vice City</h2><div class="story-scene">CAPÍTULO 1 · UMA NOVA VIDA</div><div id="story-speaker">NARRADOR</div><p id="story-line"></p><button id="story-next">CONTINUAR ▶</button><div class="story-progress" id="story-progress"></div></div>';
 document.body.appendChild(overlay);
 const advance=()=>{const d=storyDialogues[storyDialogIndex];if(!d){overlay.remove();try{localStorage.setItem('owm-story-v1-intro-seen','1')}catch(e){}startStoryMission(0);return}document.getElementById('story-speaker').textContent=d.speaker;document.getElementById('story-line').textContent=d.text;document.getElementById('story-progress').textContent=(storyDialogIndex+1)+' / '+storyDialogues.length;storyDialogIndex++;document.getElementById('story-next').textContent=storyDialogIndex>=storyDialogues.length?'COMEÇAR MISSÃO ▶':'CONTINUAR ▶'};
 document.getElementById('story-next').addEventListener('click',advance);advance();
}
function startStoryMissionOne(){startStoryMission(0)}
function clearMissionMarker(){if(missionMarker){if(missionMarker.userData.ring)scene.remove(missionMarker.userData.ring);scene.remove(missionMarker)}missionMarker=null}
function startStoryMission(index){
 if(currentMission||index>=storyMissions.length)return;
 const m=storyMissions[index];storyMissionIndex=index;saveStoryProgress();
 currentMission={...m,index,kind:'story'};gpsTarget=currentMission;clearMissionMarker();
 const geo=new THREE.CylinderGeometry(2.2,2.2,22,12);
 missionMarker=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xffd400,emissive:0x665000,transparent:true,opacity:.88,depthWrite:false}));
 missionMarker.position.set(m.x,11,m.z);scene.add(missionMarker);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(4,0.35,8,24),new THREE.MeshBasicMaterial({color:0xffea55,emissive:0x665500,transparent:true,opacity:.98}));ring.rotation.x=Math.PI/2;ring.position.set(m.x,.25,m.z);missionMarker.userData.ring=ring;scene.add(ring);
 showMission(m.chapter+' · '+(index+1)+'/'+storyMissions.length+' — '+m.title+': '+m.description);
 showGameToast('NOVA MISSÃO',m.title,'#ffd400');
}
function startDeliveryMission(){
 if(currentMission){showGameToast('MISSÃO ATIVA','Conclua o objetivo atual primeiro.','#ff75d8');return}
 const destination=cityLocations[Math.floor(Math.random()*cityLocations.length)]||{x:100,z:100};
 currentMission={x:destination.x+18,z:destination.z,reward:300,title:'Entrega urgente',description:'Leve a encomenda ao destino marcado.',stage:'reach',kind:'delivery'};gpsTarget=currentMission;createGenericMissionMarker();showMission('ENTREGA URGENTE: '+currentMission.description);showGameToast('TRABALHO EXTRA','Entregue a encomenda para ganhar $300.','#ffd400');
}
function createGenericMissionMarker(){clearMissionMarker();const geo=new THREE.CylinderGeometry(2,2,25,12);missionMarker=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xffd400,transparent:true,opacity:.65}));missionMarker.position.set(currentMission.x,12.5,currentMission.z);scene.add(missionMarker);const ring=new THREE.Mesh(new THREE.TorusGeometry(4,.3,8,24),new THREE.MeshBasicMaterial({color:0xffea55,transparent:true,opacity:.95}));ring.rotation.x=Math.PI/2;ring.position.set(currentMission.x,.25,currentMission.z);missionMarker.userData.ring=ring;scene.add(ring)}
function showMission(t){let e=$('mission-text');if(!e){e=document.createElement('div');e.id='mission-text';e.className='hud';e.style.position='absolute';e.style.top='185px';e.style.left='10px';e.style.maxWidth='min(320px,70vw)';e.style.zIndex='15';e.style.padding='8px 10px';e.style.border='1px solid rgba(255,212,0,.65)';e.style.borderRadius='8px';e.style.background='rgba(5,12,20,.78)';e.style.color='#fff';$('ui').appendChild(e)}e.innerText='📋 '+t}
function showMissionResult(m,final=false){
 const overlay=document.createElement('div');overlay.id='story-dialog-overlay';overlay.innerHTML='<div class="story-card"><div class="story-kicker">'+(final?'CAMPANHA CONCLUÍDA':'MISSÃO CONCLUÍDA')+'</div><h2>'+m.title+'</h2><div class="story-scene">RECOMPENSA: +$'+m.reward+'</div><div id="story-speaker"></div><p id="story-line"></p><button id="story-next">'+(final?'CONTINUAR EXPLORANDO':'PRÓXIMA MISSÃO ▶')+'</button></div>';document.body.appendChild(overlay);
 overlay.querySelector('#story-speaker').textContent=m.speaker||'CJ';overlay.querySelector('#story-line').textContent=m.after||'Entrega concluída. Bom trabalho.';
 overlay.querySelector('#story-next').addEventListener('click',()=>{overlay.remove();if(final){showMission('🏆 Campanha principal concluída! Explore a cidade ou faça entregas.');showGameToast('LENDÁRIO','Você concluiu Sombras de Vice City!','#ffd400')}else startStoryMission(storyMissionIndex)});
}
function finishStoryMission(m){
 money+=m.reward;storyMissionIndex=Math.max(storyMissionIndex,m.index+1);saveStoryProgress();clearMissionMarker();currentMission=null;gpsTarget=null;updateStatsDisplay();
 triggerAchievement('Missão: '+m.title,'Concluiu uma missão da campanha.');showMission('Missão concluída: '+m.title+' · +$'+m.reward);
 showMissionResult(m,storyMissionIndex>=storyMissions.length);
}
function updateMissionSystem(){
 if(!currentMission)return;
 if(missionMarker&&missionMarker.userData.ring){missionMarker.userData.ring.rotation.z+=.012;missionMarker.userData.ring.position.y=.25+Math.sin(performance.now()*.003)*.12}
 if(playerPos().distanceTo(new THREE.Vector3(currentMission.x,0,currentMission.z))<7){
  const completed={...currentMission};money+=completed.reward;clearMissionMarker();currentMission=null;gpsTarget=null;updateStatsDisplay();
  if(completed.kind==='story'){storyMissionIndex=Math.max(storyMissionIndex,completed.index+1);saveStoryProgress();triggerAchievement('Missão: '+completed.title,'Concluiu uma missão da campanha.');showMissionResult(completed,storyMissionIndex>=storyMissions.length)}
  else{showMission('Entrega concluída! +$'+completed.reward);triggerAchievement('Entregador','Concluiu uma missão de entrega.');showGameToast('ENTREGA CONCLUÍDA','Você ganhou $'+completed.reward,'#ffd400');setTimeout(()=>{if(!currentMission)showMission('Nenhuma missão ativa. Explore a cidade ou inicie uma entrega.' )},4000)}
 }
}

/* ---------- GARAGE / ECONOMY ---------- */
function setupGarageSystem(){}
function setupVehicleCustomization(){}
function changeCarColor(hex){
 if(!vehicle)return;
 vehicle.traverse(c=>{if(c.isMesh&&c.material&&c.material.color)c.material.color.setHex(hex)});
 triggerAchievement("Estilo de Luxo","Customizou a pintura do veículo.");
}
function repairCar(){
 if(money>=100&&carDamage>0){money-=100;carDamage=0;fuel=100;vehicleDestroyed=false;damageStage=-1;if(carBody){carBody.scale.set(1,1,1);carBody.rotation.set(0,0,0)}if(vehicle&&vehicle.userData.damageParts){const p=vehicle.userData.damageParts;if(p.hood){p.hood.position.set(0,1.03,-1.18);p.hood.rotation.set(0,0,0)}if(p.frontBumper){p.frontBumper.position.set(0,.46,-2.12);p.frontBumper.rotation.set(0,0,0)}if(p.rearBumper){p.rearBumper.position.set(0,.46,2.12);p.rearBumper.rotation.set(0,0,0)}if(p.leftDoor){p.leftDoor.position.set(-.78,.86,.28);p.leftDoor.rotation.set(0,0,0)}if(p.rightDoor){p.rightDoor.position.set(.78,.86,.28);p.rightDoor.rotation.set(0,0,0)}}applyVehicleDamage();updateStatsDisplay()}
}
function storeCurrentVehicle(){
 if(!inVehicle)return;
 storedGarageVehicles.push({color:0xff0055});
 triggerAchievement("Veículo Guardado","Salvou um veículo na garagem.");
}
function spawnGarageVehicle(){
 if(!storedGarageVehicles.length)return;
 vehicle.position.copy(player.position).add(new THREE.Vector3(3,0,3));inVehicle=true;player.visible=false;
 triggerAchievement("Frota Liberada","Retirou um veículo guardado.");
}
function setupEconomyAndStores(){}
function buyStoreItem(type){
 if(type==="heal"&&money>=20&&playerHealth<100){money-=20;playerHealth=clamp(playerHealth+25,0,100)}
 if(type==="ammo"&&money>=50){money-=50;weaponAmmo[currentWeaponIndex]+=30;ammoCount=weaponAmmo[currentWeaponIndex]}
 updateStatsDisplay();
}
let savedStateRestored=false;
function restoreSavedGame(){
 if(savedStateRestored)return;savedStateRestored=true;
 try{const d=JSON.parse(localStorage.getItem('owm-save-v1')||'null');if(!d)return;
  money=Math.max(0,Number(d.money)||0);playerHealth=clamp(Number(d.playerHealth)||100,1,100);
  if(Array.isArray(d.weaponAmmo)&&d.weaponAmmo.length===weaponsList.length)weaponAmmo=d.weaponAmmo.map((n,i)=>clamp(Number(n)||0,0,[50,120,90,30][i]));
  currentWeaponIndex=clamp(Number(d.currentWeaponIndex)||0,0,weaponsList.length-1);
  if(player&&d.position&&Number.isFinite(d.position.x)&&Number.isFinite(d.position.z)){player.position.x=clamp(d.position.x,-CITY_LIMIT,CITY_LIMIT);player.position.z=clamp(d.position.z,-CITY_LIMIT,CITY_LIMIT);}
  updateWeaponHud();
 }catch(e){}
}
function updateStatsDisplay(){
 if(player&&!savedStateRestored)restoreSavedGame();
 if($("money"))$("money").innerText=money;
 if($("health-value"))$("health-value").innerText=Math.round(playerHealth);
 if($("fuel"))$("fuel").innerText=Math.round(fuel);
 if($("car-damage"))$("car-damage").innerText=Math.round(carDamage);
 if($("ammo-count"))$("ammo-count").innerText=ammoCount;
}

/* ---------- AUDIO / RÁDIO ---------- */
const radioTracks=[
 {title:"Acid Rain",src:"music/acid-rain.mp3"},
 {title:"Dream On",src:"music/dream-on.mp3"},
 {title:"Bones",src:"music/bones.mp3"},
 {title:"Smile",src:"music/smile.mp3"},
 {title:"Introspective",src:"music/introspective.mp3"},
 {title:"Me, Myself & I",src:"music/me-myself-and-i.mp3"},
 {title:"Alien Boy",src:"music/alien-boy.mp3"},
 {title:"I'm Gone",src:"music/im-gone.mp3"},
 {title:"Pompeii",src:"music/pompeii.mp3"}
];
let radioIndex=0,radioShuffle=false,radioRepeat=false,radioVolume=.45;
let backgroundMusicStarted=false;
function radioAudio(){return $("bg-music")}
function updateRadioUI(){
 const a=radioAudio(),title=$("radio-title"),vol=$("radio-volume");
 if(title)title.textContent=radioTracks[radioIndex].title;
 if(vol)vol.value=String(Math.round(radioVolume*100));
 const play=$("radio-play");if(play)play.textContent=a&&!a.paused?"⏸":"▶";
 const shuffle=$("radio-shuffle");if(shuffle)shuffle.classList.toggle("active",radioShuffle);
 const repeat=$("radio-repeat");if(repeat)repeat.classList.toggle("active",radioRepeat);
}
function loadRadioTrack(autoplay=true){
 const a=radioAudio();if(!a)return;
 const track=radioTracks[radioIndex];
 // Limpa o estado anterior antes de trocar a faixa; isso evita ficar preso na primeira música.
 a.pause();
 a.loop=radioRepeat;
 a.src=new URL(track.src,document.baseURI).href;
 a.load();updateRadioUI();
 if(autoplay){
  const title=$("radio-title");if(title)title.textContent=track.title+" • carregando…";
  a.play().then(()=>{backgroundMusicStarted=true;updateRadioUI()}).catch(err=>{if(title)title.textContent=track.title+" • toque ▶ para continuar";console.warn("Falha ao tocar rádio:",err)})
 }
}
function toggleBackgroundMusic(){
 const a=radioAudio();if(!a)return;
 if(a.paused){
  if(!a.src||!a.src.endsWith(radioTracks[radioIndex].src))a.src=new URL(radioTracks[radioIndex].src,document.baseURI).href;
  a.volume=radioVolume;
  const title=$("radio-title");if(title)title.textContent=radioTracks[radioIndex].title+" • carregando…";
  a.play().then(()=>{backgroundMusicStarted=true;updateRadioUI()}).catch(err=>{if(title)title.textContent="Não foi possível tocar: "+radioTracks[radioIndex].title;console.error("Rádio:",err);updateRadioUI()});
 }else{a.pause();updateRadioUI()}
}
function nextRadioTrack(){
 if(radioShuffle&&radioTracks.length>1){let next=radioIndex;while(next===radioIndex)next=Math.floor(Math.random()*radioTracks.length);radioIndex=next}
 else radioIndex=(radioIndex+1)%radioTracks.length;
 loadRadioTrack(true);
}
function previousRadioTrack(){const a=radioAudio();if(a&&a.currentTime>3){a.currentTime=0;return}radioIndex=(radioIndex-1+radioTracks.length)%radioTracks.length;loadRadioTrack(true)}
function toggleRadioShuffle(){radioShuffle=!radioShuffle;updateRadioUI()}
function toggleRadioRepeat(){radioRepeat=!radioRepeat;radioAudio().loop=radioRepeat;updateRadioUI()}
function startBackgroundMusicAfterInteraction(){/* rádio inicia somente quando o jogador toca ▶ */}
function initAudioSystem(){
 const a=radioAudio();if(a){
  a.volume=radioVolume;a.loop=radioRepeat;a.preload="auto";
  // Use onended para garantir uma única troca automática ao terminar cada faixa.
  a.onended=()=>{if(!radioRepeat)nextRadioTrack()};
  a.onplay=updateRadioUI;a.onpause=updateRadioUI;
  a.onerror=()=>{const t=$("radio-title");if(t)t.textContent="Erro ao carregar: "+radioTracks[radioIndex].title;console.error("Erro no arquivo de áudio",a.error,a.currentSrc)};
 }
 addEventListener("pointerdown",()=>{if(!audioCtx)audioCtx=new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==="suspended")audioCtx.resume()},{once:false});
 $("radio-play")?.addEventListener("click",toggleBackgroundMusic);
 $("radio-next")?.addEventListener("click",nextRadioTrack);
 $("radio-prev")?.addEventListener("click",previousRadioTrack);
 $("radio-shuffle")?.addEventListener("click",toggleRadioShuffle);
 $("radio-repeat")?.addEventListener("click",toggleRadioRepeat);
 $("radio-volume")?.addEventListener("input",e=>{radioVolume=Number(e.target.value)/100;if(a)a.volume=radioVolume});
 $("radio-toggle")?.addEventListener("click",()=>{$("radio-panel").classList.toggle("open")});
 $("btn-meme")?.addEventListener("click",showRandomGameMeme);
 $("radio-close")?.addEventListener("click",()=>$("radio-panel")?.classList.remove("open"));
 // Evita que tocar nos controles do rádio seja interpretado como gesto da câmera.
 $("radio-panel")?.addEventListener("pointerdown",e=>e.stopPropagation());
 updateRadioUI();
}
function playSoundEffect(type){
 if(!audioCtx)return;
 const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime;
 o.connect(g);g.connect(audioCtx.destination);
 if(type==="shoot"){o.type="square";o.frequency.setValueAtTime(400,now);o.frequency.exponentialRampToValueAtTime(40,now+.1);g.gain.setValueAtTime(.15,now);g.gain.exponentialRampToValueAtTime(.01,now+.1);o.start();o.stop(now+.1)}
 else if(type==="crash"){o.type="sawtooth";o.frequency.setValueAtTime(120,now);o.frequency.linearRampToValueAtTime(30,now+.2);g.gain.setValueAtTime(.2,now);g.gain.exponentialRampToValueAtTime(.01,now+.2);o.start();o.stop(now+.2)}
 else {o.type="triangle";o.frequency.setValueAtTime(320,now);g.gain.setValueAtTime(.08,now);g.gain.exponentialRampToValueAtTime(.01,now+.2);o.start();o.stop(now+.2)}
}
function startEngineSound(){
 if(!audioCtx||engineOscillator)return;
 engineOscillator=audioCtx.createOscillator();engineGain=audioCtx.createGain();
 engineOscillator.type="triangle";engineOscillator.frequency.value=48;engineGain.gain.value=.006;
 engineOscillator.connect(engineGain);engineGain.connect(audioCtx.destination);engineOscillator.start();
}
function updateEngineSound(v){
 if(engineOscillator&&audioCtx)engineOscillator.frequency.setTargetAtTime(48+Math.abs(v)*24,audioCtx.currentTime,.16);
}
function stopEngineSound(){if(engineOscillator){try{engineOscillator.stop()}catch(e){}engineOscillator.disconnect();engineOscillator=null;engineGain=null}}

/* ---------- SMOKE ---------- */
const smokeGeo=new THREE.SphereGeometry(.25,5,5);
const smokeMatBase=new THREE.MeshBasicMaterial({color:0xdddddd,transparent:true,opacity:.5});
function createSmokeParticle(pos){
 const p=new THREE.Mesh(smokeGeo,smokeMatBase.clone());p.position.copy(pos);p.position.y+=.2;scene.add(p);
 smokeParticles.push({mesh:p,life:1,scale:.25});
}
function updateSmokeParticles(dt){
 for(let i=smokeParticles.length-1;i>=0;i--){
  const s=smokeParticles[i];s.life-=dt;s.scale+=dt*.9;s.mesh.scale.setScalar(s.scale);s.mesh.material.opacity=Math.max(0,s.life*.5);s.mesh.position.y+=dt*.6;
  if(s.life<=0){scene.remove(s.mesh);s.mesh.material.dispose();smokeParticles.splice(i,1)}
 }
}

/* ---------- COLLECTIBLES ---------- */
function setupHiddenPackages(){
 const geo=new THREE.BoxGeometry(.8,.8,.8),mat=new THREE.MeshStandardMaterial({color:0xff00ff,metalness:.6});
 for(let i=0;i<10;i++){
  const p=new THREE.Mesh(geo,mat),street=(Math.floor(Math.random()*16)-7.5)*100,along=(Math.random()-.5)*1460,lane=(Math.random()<.5?-1:1)*5;
  if(Math.random()<.5)p.position.set(along,.5,street+lane);else p.position.set(street+lane,.5,along);
  scene.add(p);hiddenPackages.push(p);
 }
}
function updateHiddenPackages(dt){
 const pos=playerPos();
 for(let i=hiddenPackages.length-1;i>=0;i--){
  const p=hiddenPackages[i];p.rotation.y+=dt*2;
  if(p.position.distanceTo(pos)<2){scene.remove(p);hiddenPackages.splice(i,1);collectedPackagesCount++;money+=500;updateStatsDisplay();triggerAchievement("Caçador de Pacotes",`Coletou ${collectedPackagesCount}/10 pacotes.`)}
 }
}

/* ---------- CAMERA / MINIMAP ---------- */
function setupCameraSwitchSystem(){}
function toggleCameraMode(){if(inVehicle)cameraMode=(cameraMode+1)%3}
function updateVehicleCamera(){
 if(!inVehicle||!vehicle)return;
 const off=cameraMode===1?new THREE.Vector3(0,2.1,3.8):cameraMode===2?new THREE.Vector3(0,7.5,13):new THREE.Vector3(0,3.4,7.5);
 off.applyAxisAngle(new THREE.Vector3(0,1,0),vehicle.rotation.y+cameraAngleY);
 camera.position.lerp(vehicle.position.clone().add(off),.12);
 const forward=new THREE.Vector3(0,0,-1).applyQuaternion(vehicle.quaternion);
 const lookTarget=vehicle.position.clone().add(new THREE.Vector3(0,1,0)).addScaledVector(forward,cameraMode===2?5:8);
 camera.lookAt(lookTarget);
}
function setupMinimapSystem(){minimapCtx=$("minimap-canvas").getContext("2d")}
function updateMinimap(){
 if(!minimapCtx)return;
 const ctx=minimapCtx,pos=playerPos(),S=140,scale=.08;
 ctx.clearRect(0,0,S,S);ctx.fillStyle="#09110f";ctx.fillRect(0,0,S,S);
 ctx.strokeStyle="#343b3a";ctx.lineWidth=2;
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  let x=70+(street-pos.x)*scale,z=70+(street-pos.z)*scale;
  ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,S);ctx.stroke();
  ctx.beginPath();ctx.moveTo(0,z);ctx.lineTo(S,z);ctx.stroke();
 }
 for(const place of cityLocations){
  const x=(place.x-pos.x)*scale+70,z=(place.z-pos.z)*scale+70;
  if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle=place.type===0?"#8dd68c":place.type===2?"#ff8175":"#d3c79a";ctx.fillRect(x-1.3,z-1.3,2.6,2.6)}
 }
 for(const p of hiddenPackages){let x=(p.position.x-pos.x)*scale+70,z=(p.position.z-pos.z)*scale+70;if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle="#f0f";ctx.fillRect(x-2,z-2,4,4)}}
 if(currentMission){let x=(currentMission.x-pos.x)*scale+70,z=(currentMission.z-pos.z)*scale+70;ctx.fillStyle="#ffd400";ctx.strokeStyle="#fff1a6";ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,z,5,0,Math.PI*2);ctx.fill();ctx.stroke()}
 for(const cop of policeCars){let x=(cop.position.x-pos.x)*scale+70,z=(cop.position.z-pos.z)*scale+70;if(x>0&&x<S&&z>0&&z<S){ctx.fillStyle="#f33";ctx.fillRect(x-2,z-2,4,4)}}
 ctx.fillStyle="#ff3980";ctx.beginPath();ctx.arc(70,70,4,0,Math.PI*2);ctx.fill();
}

/* ---------- RADIO ---------- */
function setupRadioSystem(){}
function toggleRadio(){
 if(!audioCtx)return;
 if(!radioPlaying){radioPlaying=true;currentStation=1;startRadioLoop()}
 else{currentStation++;if(currentStation>2){radioPlaying=false;stopRadioLoop()}}
}
function startRadioLoop(){
 stopRadioLoop();radioInterval=setInterval(()=>{
  if(!radioPlaying||!audioCtx)return;
  const notes=currentStation===1?[220,247,293,329,370]:[110,130,164,196],n=notes[Math.floor(Math.random()*notes.length)];
  const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime;o.type=currentStation===1?"sine":"sawtooth";o.frequency.value=n;g.gain.setValueAtTime(.025,now);g.gain.exponentialRampToValueAtTime(.001,now+.3);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(now+.3)
 },400)
}
function stopRadioLoop(){if(radioInterval){clearInterval(radioInterval);radioInterval=null}}

/* ---------- WEATHER / TIME ---------- */
function setupWeatherSystem(){
 const geo=new THREE.BufferGeometry(),count=1100,pos=new Float32Array(count*3);
 for(let i=0;i<pos.length;i+=3){pos[i]=(Math.random()-.5)*1550;pos[i+1]=Math.random()*70;pos[i+2]=(Math.random()-.5)*1550}
 geo.setAttribute("position",new THREE.BufferAttribute(pos,3));
 rainParticles=new THREE.Points(geo,new THREE.PointsMaterial({color:0xaaaaaa,size:.35,transparent:true,opacity:.5}));
 rainParticles.visible=false;scene.add(rainParticles)
}
function toggleWeather(){isRaining=!isRaining;rainParticles.visible=isRaining;$("weather-status").innerText=isRaining?"Chovendo":"Ensolarado"}
function updateWeather(dt){
 if(!isRaining)return;
 const p=rainParticles.geometry.attributes.position.array;
 for(let i=1;i<p.length;i+=3){p[i]-=35*dt;if(p[i]<0)p[i]=70}
 rainParticles.geometry.attributes.position.needsUpdate=true;
}
function setupTimeOfDaySystem(){}
function updateTimeOfDay(dt){
 gameTime+=timeSpeed*dt*60;if(gameTime>=24)gameTime=0;
 const angle=(gameTime/24)*Math.PI*2;
 directionalLight.position.set(Math.cos(angle)*150,Math.max(20,Math.sin(angle)*150),50);
 directionalLight.intensity=gameTime>6&&gameTime<18?(.45+Math.sin((gameTime-6)/12*Math.PI)*.8):.12;
 const night=gameTime>=18||gameTime<=6;
 scene.background.setHex(night?0x080817:0x87ceeb);
 scene.fog.color.setHex(night?0x09091a:0x8899aa);
 $("time-display").innerText=`${String(Math.floor(gameTime)).padStart(2,"0")}:${String(Math.floor((gameTime%1)*60)).padStart(2,"0")}`;
}

/* ---------- RACE ---------- */
function setupTimeTrialSystem(){}
function startStreetRace(){
 if(isRacing)return;
 isRacing=true;raceTimer=35;currentCheckpoint=0;
 triggerAchievement("Piloto de Fuga","Iniciou uma corrida contra o relógio.");
}
function updateTimeTrial(dt){
 if(!isRacing)return;
 raceTimer-=dt;
 if(raceTimer<=0){isRacing=false;return}
 const cp=raceCheckpoints[currentCheckpoint],p=playerPos();
 if(Math.hypot(p.x-cp.x,p.z-cp.z)<7){
  currentCheckpoint++;
  if(currentCheckpoint>=raceCheckpoints.length){isRacing=false;money+=1000;triggerAchievement("Rei das Ruas","Completou a corrida e ganhou $1000.")}
 }
}

/* ---------- ACHIEVEMENTS / STATS ---------- */
function setupAchievementSystem(){}
function triggerAchievement(title,description){
 if(unlockedAchievements.includes(title))return;
 unlockedAchievements.push(title);
 const c=$("toast-container"),t=document.createElement("div");t.className="toast";
 t.innerHTML=`<b style="color:#0ff">🏆 CONQUISTA</b><br><strong style="color:#f07">${title}</strong><br><small>${description}</small>`;
 c.appendChild(t);setTimeout(()=>t.remove(),4000);playSoundEffect("horn");
}
function setupStatsDashboard(){}
function toggleStatsModal(){const m=$("stats-modal");m.style.display=m.style.display==="flex"?"none":"flex";if(m.style.display==="flex"){ $("stat-money").innerText="$"+money;$("stat-packages").innerText=collectedPackagesCount;$("stat-achievements").innerText=unlockedAchievements.length;$("stat-race").innerText=isRacing?"Em andamento":"Pronta"}} 
function setupPauseMenu(){}
function togglePauseGame(){isGamePaused=!isGamePaused;$("pause-menu").style.display=isGamePaused?"flex":"none"}
function toggleFullScreen(){if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()}
function resetGameSession(){location.reload()}

/* ---------- CHEATS ---------- */
function setupCheatCodeSystem(){}
function submitCheatCode(code){
 code=(code||prompt("Digite o cheat:")||"").trim().toUpperCase();
 if(code==="HESOYAM"||code==="DINHEIRO"){money+=5000;playerHealth=100}
 else if(code==="WEAPON"||code==="ARMAS"){weaponAmmo=weaponAmmo.map(amount=>amount+100);ammoCount=weaponAmmo[currentWeaponIndex]}
 else return;
 updateStatsDisplay();triggerAchievement("Trapaceiro Profissional","Código especial ativado.");
}

/* ---------- AMBIENCE ---------- */
function setupStreetLights(){
 const postGeo=new THREE.CylinderGeometry(.08,.12,5.2,5),postMat=new THREE.MeshStandardMaterial({color:0x34383a,metalness:.55,roughness:.7});
 const headGeo=new THREE.BoxGeometry(.72,.2,1.25),headMat=new THREE.MeshStandardMaterial({color:0xffd899,emissive:0xffb94d,emissiveIntensity:.06});
 const positions=[{x:30,z:30},{x:-30,z:30},{x:30,z:-30},{x:-30,z:-30},{x:90,z:90},{x:-90,z:-90}];
 for(const p of positions){
  const post=new THREE.Mesh(postGeo,postMat);post.position.set(p.x,2.6,p.z);scene.add(post);
  const l=new THREE.PointLight(0xffaa44,0,18);l.position.set(p.x,5.2,p.z);scene.add(l);streetLights.push(l)
 }
 const lampPositions=[];
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=200){
  for(const side of [-1,1])for(let along=-700;along<=700;along+=200){
   lampPositions.push([along,street+side*16]);lampPositions.push([street+side*16,along]);
  }
 }
 const poles=new THREE.InstancedMesh(postGeo,postMat,lampPositions.length),heads=new THREE.InstancedMesh(headGeo,headMat,lampPositions.length),dummy=new THREE.Object3D();
 lampPositions.forEach(([x,z],i)=>{
  dummy.position.set(x,2.6,z);dummy.updateMatrix();poles.setMatrixAt(i,dummy.matrix);
  dummy.position.set(x,5.15,z);dummy.updateMatrix();heads.setMatrixAt(i,dummy.matrix);
 });
 poles.instanceMatrix.needsUpdate=true;heads.instanceMatrix.needsUpdate=true;scene.add(poles,heads);
 streetLampMaterial=headMat;
}
function updateStreetLights(){const n=gameTime>=18||gameTime<=6;for(const l of streetLights)l.intensity=n?1.8:0;if(streetLampMaterial)streetLampMaterial.emissiveIntensity=n ? .9 : .06}
function setupNeonSigns(){
 const geo=new THREE.BoxGeometry(4,1.2,.2);
 [{x:0,z:-40,c:0xff007f},{x:50,z:0,c:0x00ffff},{x:-50,z:20,c:0xffaa00},{x:0,z:80,c:0x00ff00}].forEach(d=>{
  const s=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:d.c}));s.position.set(d.x,6,d.z);scene.add(s);neonSigns.push({mesh:s,color:d.c})
 })
}
function updateNeonSigns(){const n=gameTime>=18||gameTime<=6;for(const s of neonSigns)s.mesh.visible=n}
function setupDistantHorizon(){
 const group=new THREE.Group(),geo=new THREE.BoxGeometry(16,60,16),mat=new THREE.MeshStandardMaterial({color:0x111122});
 for(let i=0;i<60;i++){const a=i/60*Math.PI*2,r=900,h=35+(i%7)*12,b=new THREE.Mesh(geo,mat);b.scale.set(1+(i%3)*.2,h/60,1+((i+2)%3)*.2);b.position.set(Math.cos(a)*r,h/2,Math.sin(a)*r);group.add(b)}
 scene.add(group)
}
function setupAmbientDustSystem(){
 const count=420,g=new THREE.BufferGeometry(),p=new Float32Array(count*3);
 for(let i=0;i<p.length;i+=3){p[i]=(Math.random()-.5)*1500;p[i+1]=Math.random()*28;p[i+2]=(Math.random()-.5)*1500}
 g.setAttribute("position",new THREE.BufferAttribute(p,3));ambientDustParticles=new THREE.Points(g,new THREE.PointsMaterial({color:0xffeeaa,size:.3,transparent:true,opacity:.3}));scene.add(ambientDustParticles)
}
function updateAmbientDust(dt){
 if(!ambientDustParticles)return;const p=ambientDustParticles.geometry.attributes.position.array;
 for(let i=0;i<p.length;i+=3){p[i]+=.8*dt;p[i+2]+=.4*dt;if(p[i]>750)p[i]=-750;if(p[i+2]>750)p[i+2]=-750}
 ambientDustParticles.geometry.attributes.position.needsUpdate=true
}
function setupUrbanWaterFountains(){
 const water=new THREE.Mesh(new THREE.CylinderGeometry(8,8,.4,24),new THREE.MeshStandardMaterial({color:0x167f9d,metalness:.5,roughness:.15,transparent:true,opacity:.82}));water.position.set(25,.2,25);scene.add(water);
 const rim=new THREE.Mesh(new THREE.TorusGeometry(8,.55,10,24),new THREE.MeshStandardMaterial({color:0x77736b,roughness:.72}));rim.rotation.x=Math.PI/2;rim.position.set(25,.5,25);scene.add(rim);
 const inner=new THREE.Mesh(new THREE.CylinderGeometry(2.6,3.2,.65,16),new THREE.MeshStandardMaterial({color:0x8c8a82,roughness:.8}));inner.position.set(25,.55,25);scene.add(inner);
 const jet=new THREE.Mesh(new THREE.CylinderGeometry(.14,.22,2.2,10),new THREE.MeshStandardMaterial({color:0xc9d5d0,metalness:.6,roughness:.2}));jet.position.set(25,1.9,25);scene.add(jet);
 const spray=new THREE.Mesh(new THREE.SphereGeometry(.9,10,8),new THREE.MeshStandardMaterial({color:0x78cce2,transparent:true,opacity:.6,roughness:.15}));spray.position.set(25,3.1,25);scene.add(spray);
}
function setupUrbanParksAndTrees(){
 const trees=[];const bushes=[];
 for(let street=-CITY_EDGE;street<=CITY_EDGE;street+=100){
  for(const side of [-1,1])for(let along=-725;along<=725;along+=70){
   const crossGap=Math.min(Math.abs(along%100),100-Math.abs(along%100));
   if(crossGap<18)continue;
   const scale=.82+((Math.abs(street+along)%5)*.08);
   trees.push({x:along,z:street+side*17,scale,kind:Math.abs(along+street)%3===0?1:0});
   trees.push({x:street+side*17,z:along,scale,kind:Math.abs(along-street)%4===0?1:0});
  }
 }
 for(const place of cityLocations){
  if(place.type!==0&&place.type!==11)continue;
  for(let ix=-2;ix<=2;ix++)for(let iz=-2;iz<=2;iz++){
   if(Math.abs(ix)<1||Math.abs(iz)<1)continue;
   if(place.type===11&&Math.abs(iz*12-13)<12&&Math.abs(ix*12)<20)continue;
   const x=place.x+ix*12,z=place.z+iz*12,scale=1+(Math.abs(ix+iz)%3)*.12;
   trees.push({x,z,scale,kind:(ix+iz+5)%3===0?1:0});
   if((ix+iz)%2===0)bushes.push({x:x+4,z:z+3,scale:.8+((ix-iz+4)%3)*.16});
  }
 }
 const trunkGeometry=new THREE.CylinderGeometry(.28,.48,4.5,7);
 const trunkMaterial=new THREE.MeshStandardMaterial({color:0x654833,roughness:1});
 const trunkMesh=new THREE.InstancedMesh(trunkGeometry,trunkMaterial,trees.length);
 const broad=trees.filter(tree=>tree.kind===0),conifers=trees.filter(tree=>tree.kind===1);
 const broadMesh=new THREE.InstancedMesh(new THREE.SphereGeometry(2.7,8,7),new THREE.MeshStandardMaterial({color:0x4f8950,roughness:1}),broad.length);
 const coneMesh=new THREE.InstancedMesh(new THREE.ConeGeometry(3.1,7,7),new THREE.MeshStandardMaterial({color:0x367551,roughness:1}),conifers.length);
 const dummy=new THREE.Object3D();
 trees.forEach((tree,i)=>{
  dummy.position.set(tree.x,2.2*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();trunkMesh.setMatrixAt(i,dummy.matrix);
 });
 broad.forEach((tree,i)=>{
  dummy.position.set(tree.x,5.1*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();broadMesh.setMatrixAt(i,dummy.matrix);
  broadMesh.setColorAt(i,new THREE.Color().setHSL(.29+((Math.abs(tree.x+tree.z)%7)*.006),.38,.31+((Math.abs(tree.x-tree.z)%5)*.012)));
 });
 conifers.forEach((tree,i)=>{
  dummy.position.set(tree.x,5.7*tree.scale,tree.z);dummy.scale.setScalar(tree.scale);dummy.updateMatrix();coneMesh.setMatrixAt(i,dummy.matrix);
  coneMesh.setColorAt(i,new THREE.Color().setHSL(.36,.34,.28+((Math.abs(tree.x+tree.z)%4)*.015)));
 });
 trunkMesh.instanceMatrix.needsUpdate=true;broadMesh.instanceMatrix.needsUpdate=true;coneMesh.instanceMatrix.needsUpdate=true;
 if(broadMesh.instanceColor)broadMesh.instanceColor.needsUpdate=true;
 if(coneMesh.instanceColor)coneMesh.instanceColor.needsUpdate=true;
 scene.add(trunkMesh,broadMesh,coneMesh);
 const bushMesh=new THREE.InstancedMesh(new THREE.SphereGeometry(1.25,6,5),new THREE.MeshStandardMaterial({color:0x4f8748,roughness:1}),bushes.length);
 bushes.forEach((bush,i)=>{dummy.position.set(bush.x,.9,bush.z);dummy.scale.set(bush.scale,.72*bush.scale,bush.scale);dummy.updateMatrix();bushMesh.setMatrixAt(i,dummy.matrix)});
 bushMesh.instanceMatrix.needsUpdate=true;scene.add(bushMesh);
}
function setupAtmosphericFog(){scene.fog=new THREE.FogExp2(0x8899aa,.0011)}
function updateAtmosphericFog(){scene.fog.density=(gameTime>=18||gameTime<=6)?.0022:.0011}
function setupAmbientAirTraffic(){
 const geo=new THREE.ConeGeometry(.5,2,4);geo.rotateX(Math.PI/2);const mat=new THREE.MeshBasicMaterial({color:0xffffff});
 for(let i=0;i<3;i++){const m=new THREE.Mesh(geo,mat);scene.add(m);ambientAircrafts.push({mesh:m,angle:Math.random()*6.28,radius:340+i*150,speed:.04+i*.01})}
}
function updateAmbientAirTraffic(dt){
 for(const a of ambientAircrafts){a.angle+=a.speed*dt*2;a.mesh.position.set(Math.cos(a.angle)*a.radius,90+Math.sin(a.angle*2)*8,Math.sin(a.angle)*a.radius);a.mesh.rotation.y=-a.angle}
}
function setupStreetFurniture(){
 const pole=new THREE.CylinderGeometry(.08,.08,3,5),pm=new THREE.MeshStandardMaterial({color:0x444444,metalness:.7}),sg=new THREE.BoxGeometry(1,1,.1),sm=new THREE.MeshStandardMaterial({color:0xcc0000});
 [{x:22,z:22},{x:-22,z:22},{x:22,z:-22},{x:-22,z:-22}].forEach(p=>{const g=new THREE.Group(),a=new THREE.Mesh(pole,pm),b=new THREE.Mesh(sg,sm);a.position.y=1.5;b.position.y=2.8;g.add(a,b);g.position.set(p.x,0,p.z);scene.add(g)})
}

/* ---------- MASTER ---------- */
function masterInit(){
 createTrafficSystem();
 createExtraTransportFleet();
 setupWantedSystem();
 setupMissionSystem();
 setupWeaponSystem();
 setupWeaponArsenalSystem();
 setupGarageSystem();
 setupEconomyAndStores();
 setupVehicleCustomization();
 setupCameraSwitchSystem();
 setupMinimapSystem();
 setupWeatherSystem();
 setupTimeOfDaySystem();
 setupAchievementSystem();
 setupStatsDashboard();
 setupPauseMenu();
 setupCheatCodeSystem();
 setupHiddenPackages();
 setupTimeTrialSystem();
 setupStreetLights();
 setupNeonSigns();
 setupDistantHorizon();
 setupAmbientDustSystem();
 setupUrbanWaterFountains();
 setupUrbanParksAndTrees();
 setupAtmosphericFog();
 setupAmbientAirTraffic();
 setupStreetFurniture();
 initAudioSystem();
 updateStatsDisplay();
}


/* MULTIPLAYER V3.37 — WebSocket rooms; requires a separately hosted server. */
let mpSocket=null,mpId=null,mpLastSend=0,mpRemotePlayers=new Map(),mpPlayerCount=1;
function mpStatus(message,good=false){const el=$("mp-status");if(el){el.textContent=message;el.style.color=good?'#8dffb0':'#ffd28a';}}
function mpRemovePlayer(id){const entry=mpRemotePlayers.get(id);if(entry){scene.remove(entry.group);mpRemotePlayers.delete(id);}}
function mpEnsurePlayer(data){
 let entry=mpRemotePlayers.get(data.id);
 if(!entry){
  const group=createCharacterGroup({shirt:0x16bde0,pants:0x23395b,skin:0xb98261});
  const canvas=document.createElement('canvas');canvas.width=256;canvas.height=64;const ctx=canvas.getContext('2d');ctx.fillStyle='rgba(3,12,25,.78)';ctx.fillRect(0,0,256,64);ctx.font='bold 28px Arial';ctx.textAlign='center';ctx.fillStyle='#8ff3ff';ctx.fillText(String(data.name||'Jogador').slice(0,18),128,42);
  const texture=new THREE.CanvasTexture(canvas);const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false}));sprite.position.y=2.55;sprite.scale.set(2.5,.62,1);group.add(sprite);scene.add(group);entry={group,name:data.name||'Jogador'};mpRemotePlayers.set(data.id,entry);
 }
 entry.group.position.set(clamp(Number(data.x)||0,-CITY_LIMIT,CITY_LIMIT),Math.max(0,Number(data.y)||0),clamp(Number(data.z)||0,-CITY_LIMIT,CITY_LIMIT));entry.group.rotation.y=Number(data.r)||0;return entry;
}
function mpHandleMessage(msg){
 if(msg.type==='welcome'){mpId=msg.id;mpStatus('Conectado à sala '+msg.room,true);}
 else if(msg.type==='state'&&Array.isArray(msg.players)){const alive=new Set();for(const pl of msg.players){if(pl.id===mpId)continue;alive.add(pl.id);mpEnsurePlayer(pl);}for(const id of mpRemotePlayers.keys()){if(!alive.has(id))mpRemovePlayer(id);}mpPlayerCount=msg.players.length;const count=$("mp-count");if(count)count.textContent='Jogadores: '+mpPlayerCount;}
 else if(msg.type==='notice'){mpStatus(msg.message||'Servidor enviou uma mensagem',true);}
 else if(msg.type==='error'){mpStatus(msg.message||'Erro no servidor');}
}
function mpConnect(){
 mpSaveSettings();
 const url=($("mp-url")?.value||'').trim();const name=(($("mp-name")?.value||'Jogador').trim().slice(0,18)||'Jogador');const room=(($("mp-room")?.value||'alta-vista').trim().slice(0,24)||'alta-vista');
 if(!url){mpStatus('Abra ⚙️ Configurar servidor e informe o endereço WebSocket.');const details=document.querySelector('#multiplayer-panel details');if(details)details.open=true;return;}if(!/^wss?:\/\//i.test(url)){mpStatus('A URL precisa começar com ws:// ou wss://');return;}
 try{if(mpSocket)mpSocket.close();mpStatus('Conectando…');mpSocket=new WebSocket(url);mpSocket.onopen=()=>{mpSocket.send(JSON.stringify({type:'join',name,room}));mpStatus('Conectado; entrando na sala…',true);};mpSocket.onmessage=(ev)=>{try{mpHandleMessage(JSON.parse(ev.data));}catch(e){console.warn('Mensagem multiplayer inválida',e);}};mpSocket.onerror=()=>mpStatus('Não conectou. Confira o endereço e se o servidor está ligado; todos devem usar o mesmo servidor.');mpSocket.onclose=()=>{mpId=null;mpStatus('Desconectado');for(const id of [...mpRemotePlayers.keys()])mpRemovePlayer(id);mpPlayerCount=1;const count=$("mp-count");if(count)count.textContent='Jogadores: 1 (você)';};}catch(e){mpStatus('Não foi possível iniciar conexão: '+e.message);}
}
function mpDisconnect(){if(mpSocket){const old=mpSocket;mpSocket=null;old.close();}mpId=null;for(const id of [...mpRemotePlayers.keys()])mpRemovePlayer(id);mpStatus('Desconectado');}
function mpTick(now){if(!mpSocket||mpSocket.readyState!==WebSocket.OPEN||!player||now-mpLastSend<80)return;mpLastSend=now;const pos=playerPos();try{mpSocket.send(JSON.stringify({type:'move',x:pos.x,y:pos.y,z:pos.z,r:inVehicle&&vehicle?vehicle.rotation.y:player.rotation.y,vehicle:!!inVehicle}));}catch(e){}}
function mpSaveSettings(){try{localStorage.setItem('owm-mp-url',($('mp-url')?.value||'').trim());localStorage.setItem('owm-mp-name',($('mp-name')?.value||'Jogador').trim());localStorage.setItem('owm-mp-room',($('mp-room')?.value||'alta-vista').trim());}catch(e){}}
async function mpCopyInvite(){const url=($('mp-url')?.value||'').trim(),room=(($('mp-room')?.value||'alta-vista').trim()||'alta-vista'),name=(($('mp-name')?.value||'Jogador').trim()||'Jogador');if(!url){mpStatus('Abra ⚙️ Configurar servidor e informe o endereço primeiro.');return;}const invite='Open World Mobile — vamos jogar!\nServidor: '+url+'\nSala: '+room+'\nCada jogador coloca o próprio nome e usa este mesmo servidor e sala.';try{if(navigator.clipboard&&navigator.clipboard.writeText)await navigator.clipboard.writeText(invite);else{const t=document.createElement('textarea');t.value=invite;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();if(!ok)throw new Error('cópia indisponível');}mpStatus('Convite copiado! Envie para seu amigo.',true);}catch(e){mpStatus('Não consegui copiar automaticamente. Servidor: '+url+' · Sala: '+room);}}
function mpSetupUI(){const panel=$("multiplayer-panel");$("btn-multiplayer")?.addEventListener('click',()=>{panel.style.display=panel.style.display==='block'?'none':'block';});$("mp-close")?.addEventListener('click',()=>panel.style.display='none');$("mp-connect")?.addEventListener('click',mpConnect);$("mp-disconnect")?.addEventListener('click',mpDisconnect);$("mp-copy-invite")?.addEventListener('click',mpCopyInvite);try{const saved=localStorage.getItem('owm-mp-url');if(saved&&$("mp-url"))$("mp-url").value=saved;const savedName=localStorage.getItem('owm-mp-name');if(savedName&&$("mp-name"))$("mp-name").value=savedName;const savedRoom=localStorage.getItem('owm-mp-room');if(savedRoom&&$("mp-room"))$("mp-room").value=savedRoom;for(const id of ['mp-url','mp-name','mp-room'])$(id)?.addEventListener('change',mpSaveSettings);$("mp-room")?.addEventListener('keydown',e=>{if(e.key==='Enter')mpConnect();});$("mp-name")?.addEventListener('keydown',e=>{if(e.key==='Enter')mpConnect();});}catch(e){}}

let lastRenderFrame=0;
const TARGET_FRAME_MS = 1000/60; // Mira 60 FPS; aparelhos lentos podem ficar abaixo disso.
function gameLoop(now){
 requestAnimationFrame(gameLoop);
 if(document.hidden) return;
 if(now-lastRenderFrame<TARGET_FRAME_MS) return;
 lastRenderFrame=now;
 const dt=Math.min((now-lastFrame)/1000,.05);lastFrame=now;
 if(!gameStarted||isGamePaused){return}

 mpTick(now);
 updateGame(dt);
 updateTraffic(dt);
 updateBullets(dt);
 if(now-lastAIUpdate>50){const aiDt=Math.min(.1,(now-lastAIUpdate)/1000);updatePedestrianAI(aiDt);updatePoliceAI(aiDt);lastAIUpdate=now}
 updateMissionSystem();
 updateHiddenPackages(dt);
 updateTimeTrial(dt);
 updateWeather(dt);
 updateSmokeParticles(dt);
 updateTimeOfDay(dt);
 updateStreetLights();
 updateNeonSigns();
 updateAmbientDust(dt);
 updateAtmosphericFog();
 updateAmbientAirTraffic(dt);
 updateSkyClouds(dt);

 if(now-lastHudUpdate>160){updateStatsDisplay();updateMinimap();updateNearbyLocation();lastHudUpdate=now}
 renderer.render(scene,camera);
}

const GRAPHICS_PRESETS={eco:{pixelRatio:.65,renderDistance:"low",fog:.0032,shadows:false,label:"Econômico"},balanced:{pixelRatio:IS_MOBILE_DEVICE?.85:1.0,renderDistance:"medium",fog:.0017,shadows:!IS_MOBILE_DEVICE,label:"Equilibrado"},quality:{pixelRatio:IS_MOBILE_DEVICE?.98:1.2,renderDistance:"high",fog:.00105,shadows:true,label:"Qualidade"}};
let activeGraphicsPreset='balanced';
function setGraphicsPreset(preset,save=true){
 const cfg=GRAPHICS_PRESETS[preset]||GRAPHICS_PRESETS.balanced;
 activeGraphicsPreset=preset;
 if(renderer){renderer.setPixelRatio(Math.min(devicePixelRatio||1,cfg.pixelRatio));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=!!cfg.shadows;}
 if(directionalLight)directionalLight.castShadow=!!cfg.shadows;
 if(scene&&scene.fog)scene.fog.density=cfg.fog;
 setRenderDistancePreset(cfg.renderDistance);
 document.querySelectorAll('[data-graphics-preset]').forEach(btn=>{const active=btn.dataset.graphicsPreset===preset;btn.style.outline=active?'2px solid #fff':'none';btn.setAttribute('aria-pressed',active?'true':'false')});
 const label=document.getElementById('graphics-status');if(label)label.textContent=cfg.label;
 if(save){try{localStorage.setItem('owm-graphics-preset',preset)}catch(e){}}
}
window.setGraphicsPreset=setGraphicsPreset;
window.addEventListener('beforeunload',()=>{try{localStorage.setItem('owm-save-v1',JSON.stringify({money,playerHealth,weaponAmmo,currentWeaponIndex,storyMissionIndex,position:player?{x:player.position.x,z:player.position.z}:null}));}catch(e){}});

function setRenderDistancePreset(preset){
 const distance=RENDER_DISTANCE_PRESETS[preset]||RENDER_DISTANCE_PRESETS.medium;
 activeRenderDistance=distance;
 camera.far=distance;
 camera.updateProjectionMatrix();
 if(scene && scene.fog) scene.fog.density=distance<=300?.0026:(distance>=650?.00105:.0017);
 document.querySelectorAll('[data-render-distance]').forEach(btn=>{
   const active=btn.dataset.renderDistance===preset;
   btn.style.outline=active?'2px solid #fff':'none';
   btn.setAttribute('aria-pressed',active?'true':'false');
 });
 const label=document.getElementById('render-distance-status');
 if(label) label.textContent=distance+' m';
}
window.setRenderDistancePreset=setRenderDistancePreset;
function onWindowResize(){
 camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);const cfg=GRAPHICS_PRESETS[activeGraphicsPreset]||GRAPHICS_PRESETS.balanced;renderer.setPixelRatio(Math.min(devicePixelRatio||1,cfg.pixelRatio))
}
addEventListener("resize",onWindowResize);

function setupMainMenu(){
 const menu=document.getElementById('main-menu');
 const ui=document.getElementById('ui');
 if(ui)ui.style.display='none';
 const play=document.getElementById('menu-play');
 if(play)play.addEventListener('click',()=>{if(menu)menu.style.display='none';if(ui)ui.style.display='block';try{localStorage.setItem('owm-menu-seen','1')}catch(e){}});
 const multi=document.getElementById('menu-multiplayer');
 if(multi)multi.addEventListener('click',()=>{const panel=document.getElementById('multiplayer-panel');if(panel)panel.style.display='block';});
 document.querySelectorAll('[data-menu-graphics]').forEach(btn=>btn.addEventListener('click',()=>{setGraphicsPreset(btn.dataset.menuGraphics);document.querySelectorAll('[data-menu-graphics]').forEach(b=>b.classList.toggle('active',b===btn));}));
 let saved='balanced';try{saved=localStorage.getItem('owm-graphics-preset')||'balanced'}catch(e){}
 document.querySelectorAll('[data-menu-graphics]').forEach(btn=>btn.classList.toggle('active',btn.dataset.menuGraphics===saved));
}

try {
 initEngine();
 setupControls();
 mpSetupUI();
 setupCameraDrag();
 masterInit();
 try{setGraphicsPreset(localStorage.getItem('owm-graphics-preset')||'balanced',false)}catch(e){setGraphicsPreset('balanced',false)}
 setRenderDistancePreset("medium");
 setupMainMenu();
 gameStarted=true;
 const startupOverlay=document.getElementById('startup-overlay'); if(startupOverlay) startupOverlay.remove();
 requestAnimationFrame(gameLoop);
} catch (err) {
 console.error('Falha ao iniciar Open World:', err);
 const startupOverlay=document.getElementById('startup-overlay'); if(startupOverlay) startupOverlay.remove();
 const box=document.createElement('div');
 box.style.cssText='position:fixed;z-index:999999;inset:12px;padding:16px;background:#300;color:#fff;font:14px Arial;white-space:pre-wrap;border-radius:10px;height:max-content';
 box.textContent='Erro ao iniciar o jogo: '+(err && err.message ? err.message : String(err))+'\nRecarregue a página. Se continuar, envie esta mensagem.';
 document.body.appendChild(box);
}

/* Touch/desktop extras */
$("btn-pause").addEventListener("contextmenu",e=>e.preventDefault());

/* Pequeno menu de loja acessível pelo console/JS:
   buyStoreItem("heal"), buyStoreItem("ammo")
   submitCheatCode("HESOYAM")
*/
window.togglePauseGame = togglePauseGame;
window.toggleFullScreen = toggleFullScreen;
window.resetGameSession = resetGameSession;
window.toggleStatsModal = toggleStatsModal;
